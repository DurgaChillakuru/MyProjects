import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import freecell.model.FreecellMultiMoveModel;
import freecell.model.FreecellOperations;
import freecell.model.PileType;

import static org.junit.Assert.assertEquals;

/**
 * This is the Freecell Junit test cases class.
 */
public class FreecellMultiMoveModelTest {
  private FreecellOperations model;
  private FreecellOperations model1;
  private FreecellOperations model2;
  private FreecellOperations model3;
  private FreecellOperations model4;
  private FreecellOperations model5;
  private FreecellOperations model6;
  private FreecellOperations model7;
  private FreecellOperations model8;

  @Before
  public void setup() {
    model = FreecellMultiMoveModel.getBuilder().build();
    model1 = FreecellMultiMoveModel.getBuilder().cascades(8).build();
    model2 = FreecellMultiMoveModel.getBuilder().opens(4).build();
    model3 = FreecellMultiMoveModel.getBuilder().cascades(10).opens(4).build();
    model4 = FreecellMultiMoveModel.getBuilder().cascades(9).opens(4).build();
    model5 = FreecellMultiMoveModel.getBuilder().cascades(13).opens(4).build();
    model6 = FreecellMultiMoveModel.getBuilder().cascades(26).opens(4).build();
    model7 = FreecellMultiMoveModel.getBuilder().cascades(29).opens(10).build();
    model8 = FreecellMultiMoveModel.getBuilder().cascades(29).opens(1).build();
  }

  @Test
  public void checkConstruct() {
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣";
    model.startGame(model.getDeck(), false);
    Assert.assertEquals(def, model.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkDeck() {
    List deck = model.getDeck();
    deck.remove(45);
    model.startGame(deck, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkDeckDuplicateAndMoreThan52() {
    List deck = model.getDeck();
    deck.add(deck.get(5));
    model.startGame(deck, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkDeckInvalid() {
    List deck = model.getDeck();
    deck.add("d");
    model.startGame(deck, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkDeckInvalidSym() {
    List deck = model.getDeck();
    deck.add("5$");
    model.startGame(deck, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkDeckInvalidNum() {
    List deck = model.getDeck();
    deck.add("11");
    model.startGame(deck, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkDeckInvalidNegNum() {
    List deck = model.getDeck();
    deck.add("-11");
    model.startGame(deck, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCascade() {
    FreecellOperations model = FreecellMultiMoveModel.getBuilder().cascades(-1).build();
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidCascadeLess() {
    FreecellOperations model = FreecellMultiMoveModel.getBuilder().cascades(3).build();
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidOpen() {
    FreecellOperations model = FreecellMultiMoveModel.getBuilder().opens(-1).build();
  }

  @Test(expected = IllegalArgumentException.class)
  public void invalidOpenLess() {
    FreecellOperations model = FreecellMultiMoveModel.getBuilder().opens(0).build();
  }

  @Test
  public void checkShuffle() {
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣";
    model.startGame(model.getDeck(), true);
    Assert.assertNotEquals(def, model.getGameState());
  }

  @Test
  public void checkCascadeonly() {
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 9♥, 4♠, Q♠, 7♦, 2♣, 10♣\n" +
            "C2: 2♥, 10♥, 5♠, K♠, 8♦, 3♣, J♣\n" +
            "C3: 3♥, J♥, 6♠, A♦, 9♦, 4♣, Q♣\n" +
            "C4: 4♥, Q♥, 7♠, 2♦, 10♦, 5♣, K♣\n" +
            "C5: 5♥, K♥, 8♠, 3♦, J♦, 6♣\n" +
            "C6: 6♥, A♠, 9♠, 4♦, Q♦, 7♣\n" +
            "C7: 7♥, 2♠, 10♠, 5♦, K♦, 8♣\n" +
            "C8: 8♥, 3♠, J♠, 6♦, A♣, 9♣";
    model1.startGame(model1.getDeck(), false);
    Assert.assertEquals(def, model1.getGameState());
  }

  @Test
  public void checkOpenonly() {
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣";
    model2.startGame(model2.getDeck(), false);
    Assert.assertEquals(def, model2.getGameState());
  }

  @Test
  public void checkOpenAndCascade() {
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, J♥, 8♠, 5♦, 2♣, Q♣\n" +
            "C2: 2♥, Q♥, 9♠, 6♦, 3♣, K♣\n" +
            "C3: 3♥, K♥, 10♠, 7♦, 4♣\n" +
            "C4: 4♥, A♠, J♠, 8♦, 5♣\n" +
            "C5: 5♥, 2♠, Q♠, 9♦, 6♣\n" +
            "C6: 6♥, 3♠, K♠, 10♦, 7♣\n" +
            "C7: 7♥, 4♠, A♦, J♦, 8♣\n" +
            "C8: 8♥, 5♠, 2♦, Q♦, 9♣\n" +
            "C9: 9♥, 6♠, 3♦, K♦, 10♣\n" +
            "C10: 10♥, 7♠, 4♦, A♣, J♣";
    model3.startGame(model3.getDeck(), false);
    Assert.assertEquals(def, model3.getGameState());
  }

  @Test
  public void checkNestedOpenAndCascade() {
    model3 = FreecellMultiMoveModel.getBuilder().cascades(5).opens(2)
            .cascades(10).opens(4)
            .build();
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, J♥, 8♠, 5♦, 2♣, Q♣\n" +
            "C2: 2♥, Q♥, 9♠, 6♦, 3♣, K♣\n" +
            "C3: 3♥, K♥, 10♠, 7♦, 4♣\n" +
            "C4: 4♥, A♠, J♠, 8♦, 5♣\n" +
            "C5: 5♥, 2♠, Q♠, 9♦, 6♣\n" +
            "C6: 6♥, 3♠, K♠, 10♦, 7♣\n" +
            "C7: 7♥, 4♠, A♦, J♦, 8♣\n" +
            "C8: 8♥, 5♠, 2♦, Q♦, 9♣\n" +
            "C9: 9♥, 6♠, 3♦, K♦, 10♣\n" +
            "C10: 10♥, 7♠, 4♦, A♣, J♣";
    model3.startGame(model3.getDeck(), false);
    Assert.assertEquals(def, model3.getGameState());
  }

  @Test
  public void checkGameState() {
    List deck = model.getDeck();
    model.startGame(deck, false);
    Assert.assertEquals(false, model.isGameOver());
  }

  @Test
  public void checkGameStateOverAndFinalOutput() {
    String finalOutput = "F1: A♣, 2♣, 3♣, 4♣, 5♣, 6♣, 7♣, 8♣, 9♣, 10♣, J♣, Q♣, K♣\n" +
            "F2: A♦, 2♦, 3♦, 4♦, 5♦, 6♦, 7♦, 8♦, 9♦, 10♦, J♦, Q♦, K♦\n" +
            "F3: A♠, 2♠, 3♠, 4♠, 5♠, 6♠, 7♠, 8♠, 9♠, 10♠, J♠, Q♠, K♠\n" +
            "F4: A♥, 2♥, 3♥, 4♥, 5♥, 6♥, 7♥, 8♥, 9♥, 10♥, J♥, Q♥, K♥\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1:\n" +
            "C2:\n" +
            "C3:\n" +
            "C4:\n" +
            "C5:\n" +
            "C6:\n" +
            "C7:\n" +
            "C8:\n" +
            "C9:\n" +
            "C10:\n" +
            "C11:\n" +
            "C12:\n" +
            "C13:";
    model3 = FreecellMultiMoveModel.getBuilder().cascades(13).opens(4).build();
    model3.startGame(model3.getDeck(), false);
    for (int i = 0; i < 13; i++) {
      model3.move(PileType.CASCADE, i, 3, PileType.FOUNDATION, 0);
    }
    for (int i = 0; i < 13; i++) {
      model3.move(PileType.CASCADE, i, 2, PileType.FOUNDATION, 1);
    }
    for (int i = 0; i < 13; i++) {
      model3.move(PileType.CASCADE, i, 1, PileType.FOUNDATION, 2);
    }
    for (int i = 0; i < 13; i++) {
      model3.move(PileType.CASCADE, i, 0, PileType.FOUNDATION, 3);
    }
    Assert.assertEquals(true, model.isGameOver());
    Assert.assertEquals(finalOutput, model3.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkInvalidMove() {
    model.startGame(model.getDeck(), false);
    model.move(PileType.OPEN, 0, 0, PileType.FOUNDATION, 2);
  }

  @Test(expected = IllegalStateException.class)
  public void checkInvalidMoveOpen() {
    model.startGame(model.getDeck(), false);
    model.move(PileType.OPEN, 1, 0, PileType.FOUNDATION, 2);
  }

  @Test(expected = IllegalStateException.class)
  public void checkInvalidMoveCascade() {
    model.startGame(model.getDeck(), false);
    model.move(PileType.OPEN, 9, 0, PileType.FOUNDATION, 2);
  }

  @Test
  public void checkEmptyOutputBeforeStart() {
    Assert.assertEquals("", model.getGameState());
  }

  @Test
  public void checkDealSize() {
    model3.startGame(model3.getDeck(), true);
    Assert.assertEquals(52, model3.getDeck().size());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveFromCascadeToCascadeWithSameColor() {
    model.startGame(model.getDeck(), false);
    model.move(PileType.CASCADE, 2, 12, PileType.CASCADE, 0);
  }

  @Test
  public void testValidMoveFromCascadeToOpen() {
    model4.startGame(model4.getDeck(), false);
    model4.move(PileType.CASCADE, 1, 5, PileType.OPEN, 0);
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 8♣\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, 10♥, 6♠, 2♦, J♦, 7♣\n" +
            "C2: 2♥, J♥, 7♠, 3♦, Q♦\n" +
            "C3: 3♥, Q♥, 8♠, 4♦, K♦, 9♣\n" +
            "C4: 4♥, K♥, 9♠, 5♦, A♣, 10♣\n" +
            "C5: 5♥, A♠, 10♠, 6♦, 2♣, J♣\n" +
            "C6: 6♥, 2♠, J♠, 7♦, 3♣, Q♣\n" +
            "C7: 7♥, 3♠, Q♠, 8♦, 4♣, K♣\n" +
            "C8: 8♥, 4♠, K♠, 9♦, 5♣\n" +
            "C9: 9♥, 5♠, A♦, 10♦, 6♣";
    assertEquals(def, model4.getGameState());
  }

  @Test
  public void testValidMoveFromCascadeToFoundation() {
    model5.startGame(model5.getDeck(), false);
    model5.move(PileType.CASCADE, 0, 3, PileType.FOUNDATION, 0);
    String def = "F1: A♣\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♠, A♦\n" +
            "C2: 2♥, 2♠, 2♦, 2♣\n" +
            "C3: 3♥, 3♠, 3♦, 3♣\n" +
            "C4: 4♥, 4♠, 4♦, 4♣\n" +
            "C5: 5♥, 5♠, 5♦, 5♣\n" +
            "C6: 6♥, 6♠, 6♦, 6♣\n" +
            "C7: 7♥, 7♠, 7♦, 7♣\n" +
            "C8: 8♥, 8♠, 8♦, 8♣\n" +
            "C9: 9♥, 9♠, 9♦, 9♣\n" +
            "C10: 10♥, 10♠, 10♦, 10♣\n" +
            "C11: J♥, J♠, J♦, J♣\n" +
            "C12: Q♥, Q♠, Q♦, Q♣\n" +
            "C13: K♥, K♠, K♦, K♣";
    assertEquals(def, model5.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveToFoundationWithFirstCardNotA() {
    model4.startGame(model4.getDeck(), false);
    model4.move(PileType.CASCADE, 2, 4, PileType.FOUNDATION, 0);
  }

  @Test
  public void testValidMoveFromCascadeToCascade() {
    model6.startGame(model6.getDeck(), false);
    model6.move(PileType.CASCADE, 16, 1, PileType.CASCADE, 4);
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♦\n" +
            "C2: 2♥, 2♦\n" +
            "C3: 3♥, 3♦\n" +
            "C4: 4♥, 4♦\n" +
            "C5: 5♥, 5♦, 4♣\n" +
            "C6: 6♥, 6♦\n" +
            "C7: 7♥, 7♦\n" +
            "C8: 8♥, 8♦\n" +
            "C9: 9♥, 9♦\n" +
            "C10: 10♥, 10♦\n" +
            "C11: J♥, J♦\n" +
            "C12: Q♥, Q♦\n" +
            "C13: K♥, K♦\n" +
            "C14: A♠, A♣\n" +
            "C15: 2♠, 2♣\n" +
            "C16: 3♠, 3♣\n" +
            "C17: 4♠\n" +
            "C18: 5♠, 5♣\n" +
            "C19: 6♠, 6♣\n" +
            "C20: 7♠, 7♣\n" +
            "C21: 8♠, 8♣\n" +
            "C22: 9♠, 9♣\n" +
            "C23: 10♠, 10♣\n" +
            "C24: J♠, J♣\n" +
            "C25: Q♠, Q♣\n" +
            "C26: K♠, K♣";
    assertEquals(def, model6.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMoveFromCascadeToCascade() {
    model6.startGame(model6.getDeck(), false);
    model6.move(PileType.CASCADE, 16, 1, PileType.CASCADE, 15);
  }

  @Test
  public void testValidMoveFromOpenToCascade() {
    model6.startGame(model6.getDeck(), false);
    model6.move(PileType.CASCADE, 16, 1, PileType.OPEN, 0);
    model6.move(PileType.OPEN, 0, 0, PileType.CASCADE, 4);
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♦\n" +
            "C2: 2♥, 2♦\n" +
            "C3: 3♥, 3♦\n" +
            "C4: 4♥, 4♦\n" +
            "C5: 5♥, 5♦, 4♣\n" +
            "C6: 6♥, 6♦\n" +
            "C7: 7♥, 7♦\n" +
            "C8: 8♥, 8♦\n" +
            "C9: 9♥, 9♦\n" +
            "C10: 10♥, 10♦\n" +
            "C11: J♥, J♦\n" +
            "C12: Q♥, Q♦\n" +
            "C13: K♥, K♦\n" +
            "C14: A♠, A♣\n" +
            "C15: 2♠, 2♣\n" +
            "C16: 3♠, 3♣\n" +
            "C17: 4♠\n" +
            "C18: 5♠, 5♣\n" +
            "C19: 6♠, 6♣\n" +
            "C20: 7♠, 7♣\n" +
            "C21: 8♠, 8♣\n" +
            "C22: 9♠, 9♣\n" +
            "C23: 10♠, 10♣\n" +
            "C24: J♠, J♣\n" +
            "C25: Q♠, Q♣\n" +
            "C26: K♠, K♣";
    assertEquals(def, model6.getGameState());
  }

  @Test
  public void testMoveFromOpenToFoundation() {
    model6.startGame(model6.getDeck(), false);
    model6.move(PileType.CASCADE, 13, 1, PileType.OPEN, 0);
    model6.move(PileType.OPEN, 0, 0, PileType.FOUNDATION, 0);
    String def = "F1: A♣\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♦\n" +
            "C2: 2♥, 2♦\n" +
            "C3: 3♥, 3♦\n" +
            "C4: 4♥, 4♦\n" +
            "C5: 5♥, 5♦\n" +
            "C6: 6♥, 6♦\n" +
            "C7: 7♥, 7♦\n" +
            "C8: 8♥, 8♦\n" +
            "C9: 9♥, 9♦\n" +
            "C10: 10♥, 10♦\n" +
            "C11: J♥, J♦\n" +
            "C12: Q♥, Q♦\n" +
            "C13: K♥, K♦\n" +
            "C14: A♠\n" +
            "C15: 2♠, 2♣\n" +
            "C16: 3♠, 3♣\n" +
            "C17: 4♠, 4♣\n" +
            "C18: 5♠, 5♣\n" +
            "C19: 6♠, 6♣\n" +
            "C20: 7♠, 7♣\n" +
            "C21: 8♠, 8♣\n" +
            "C22: 9♠, 9♣\n" +
            "C23: 10♠, 10♣\n" +
            "C24: J♠, J♣\n" +
            "C25: Q♠, Q♣\n" +
            "C26: K♠, K♣";
    assertEquals(def, model6.getGameState());
  }

  @Test
  public void testValidMoveFromCascadeToFoundationWithAAnd2() {
    model5.startGame(model5.getDeck(), false);
    model5.move(PileType.CASCADE, 0, 3, PileType.FOUNDATION, 0);
    String def = "F1: A♣\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♠, A♦\n" +
            "C2: 2♥, 2♠, 2♦, 2♣\n" +
            "C3: 3♥, 3♠, 3♦, 3♣\n" +
            "C4: 4♥, 4♠, 4♦, 4♣\n" +
            "C5: 5♥, 5♠, 5♦, 5♣\n" +
            "C6: 6♥, 6♠, 6♦, 6♣\n" +
            "C7: 7♥, 7♠, 7♦, 7♣\n" +
            "C8: 8♥, 8♠, 8♦, 8♣\n" +
            "C9: 9♥, 9♠, 9♦, 9♣\n" +
            "C10: 10♥, 10♠, 10♦, 10♣\n" +
            "C11: J♥, J♠, J♦, J♣\n" +
            "C12: Q♥, Q♠, Q♦, Q♣\n" +
            "C13: K♥, K♠, K♦, K♣";
    assertEquals(def, model5.getGameState());
    model5.move(PileType.CASCADE, 1, 3, PileType.FOUNDATION, 0);
    String expected = "F1: A♣, 2♣\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♠, A♦\n" +
            "C2: 2♥, 2♠, 2♦\n" +
            "C3: 3♥, 3♠, 3♦, 3♣\n" +
            "C4: 4♥, 4♠, 4♦, 4♣\n" +
            "C5: 5♥, 5♠, 5♦, 5♣\n" +
            "C6: 6♥, 6♠, 6♦, 6♣\n" +
            "C7: 7♥, 7♠, 7♦, 7♣\n" +
            "C8: 8♥, 8♠, 8♦, 8♣\n" +
            "C9: 9♥, 9♠, 9♦, 9♣\n" +
            "C10: 10♥, 10♠, 10♦, 10♣\n" +
            "C11: J♥, J♠, J♦, J♣\n" +
            "C12: Q♥, Q♠, Q♦, Q♣\n" +
            "C13: K♥, K♠, K♦, K♣";
    assertEquals(expected, model5.getGameState());
  }

  @Test
  public void testValidMoveFromCascadeToFoundationHavingMultipleCards() {
    model5.startGame(model5.getDeck(), false);
    model5.move(PileType.CASCADE, 0, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 1, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 2, 3, PileType.FOUNDATION, 0);
    String expected = "F1: A♣, 2♣, 3♣\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♠, A♦\n" +
            "C2: 2♥, 2♠, 2♦\n" +
            "C3: 3♥, 3♠, 3♦\n" +
            "C4: 4♥, 4♠, 4♦, 4♣\n" +
            "C5: 5♥, 5♠, 5♦, 5♣\n" +
            "C6: 6♥, 6♠, 6♦, 6♣\n" +
            "C7: 7♥, 7♠, 7♦, 7♣\n" +
            "C8: 8♥, 8♠, 8♦, 8♣\n" +
            "C9: 9♥, 9♠, 9♦, 9♣\n" +
            "C10: 10♥, 10♠, 10♦, 10♣\n" +
            "C11: J♥, J♠, J♦, J♣\n" +
            "C12: Q♥, Q♠, Q♦, Q♣\n" +
            "C13: K♥, K♠, K♦, K♣";
    assertEquals(expected, model5.getGameState());
  }

  @Test
  public void testValidMoveFromCascadeToFoundationHavingFullSet() {
    model5.startGame(model5.getDeck(), false);
    model5.move(PileType.CASCADE, 0, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 1, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 2, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 3, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 4, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 5, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 6, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 7, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 8, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 9, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 10, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 11, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 12, 3, PileType.FOUNDATION, 0);
    String expected = "F1: A♣, 2♣, 3♣, 4♣, 5♣, 6♣, 7♣, 8♣, 9♣, 10♣, J♣, Q♣, K♣\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♠, A♦\n" +
            "C2: 2♥, 2♠, 2♦\n" +
            "C3: 3♥, 3♠, 3♦\n" +
            "C4: 4♥, 4♠, 4♦\n" +
            "C5: 5♥, 5♠, 5♦\n" +
            "C6: 6♥, 6♠, 6♦\n" +
            "C7: 7♥, 7♠, 7♦\n" +
            "C8: 8♥, 8♠, 8♦\n" +
            "C9: 9♥, 9♠, 9♦\n" +
            "C10: 10♥, 10♠, 10♦\n" +
            "C11: J♥, J♠, J♦\n" +
            "C12: Q♥, Q♠, Q♦\n" +
            "C13: K♥, K♠, K♦";
    assertEquals(expected, model5.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMoveFromCascadeToOpenAttemptingToAddMultipleCardsInOnePile() {
    model6.startGame(model6.getDeck(), false);
    model6.move(PileType.CASCADE, 16, 1, PileType.OPEN, 0);
    model6.move(PileType.CASCADE, 17, 1, PileType.OPEN, 0);
  }

  @Test(expected = IllegalStateException.class)
  public void testInValidMoveFromCascadeToFoundationAttemptingToAddMoreThan13() {
    model5.startGame(model5.getDeck(), false);
    model5.move(PileType.CASCADE, 0, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 1, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 2, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 3, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 4, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 5, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 6, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 7, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 8, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 9, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 10, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 11, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 12, 3, PileType.FOUNDATION, 0);
    model5.move(PileType.CASCADE, 13, 3, PileType.FOUNDATION, 0);
  }

  @Test
  public void testValidMoveFromFoundationToCascade() {
    model6.startGame(model6.getDeck(), false);
    model6.move(PileType.CASCADE, 0, 1, PileType.FOUNDATION, 0);
    model6.move(PileType.FOUNDATION, 0, 0, PileType.CASCADE, 14);
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥\n" +
            "C2: 2♥, 2♦\n" +
            "C3: 3♥, 3♦\n" +
            "C4: 4♥, 4♦\n" +
            "C5: 5♥, 5♦\n" +
            "C6: 6♥, 6♦\n" +
            "C7: 7♥, 7♦\n" +
            "C8: 8♥, 8♦\n" +
            "C9: 9♥, 9♦\n" +
            "C10: 10♥, 10♦\n" +
            "C11: J♥, J♦\n" +
            "C12: Q♥, Q♦\n" +
            "C13: K♥, K♦\n" +
            "C14: A♠, A♣\n" +
            "C15: 2♠, 2♣, A♦\n" +
            "C16: 3♠, 3♣\n" +
            "C17: 4♠, 4♣\n" +
            "C18: 5♠, 5♣\n" +
            "C19: 6♠, 6♣\n" +
            "C20: 7♠, 7♣\n" +
            "C21: 8♠, 8♣\n" +
            "C22: 9♠, 9♣\n" +
            "C23: 10♠, 10♣\n" +
            "C24: J♠, J♣\n" +
            "C25: Q♠, Q♣\n" +
            "C26: K♠, K♣";
    assertEquals(def, model6.getGameState());
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidMoveFromCascadeToOpenForPileNumGreater() {
    model.startGame(model.getDeck(), false);
    model.move(PileType.CASCADE, 2, 12, PileType.OPEN, 4);
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidMoveFromCascadeToFoundationForPileNumGreater() {
    model.startGame(model.getDeck(), false);
    model.move(PileType.CASCADE, 2, 12, PileType.FOUNDATION, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveFromFoundationToCascadeForPileNumGreater() {
    model.startGame(model.getDeck(), false);
    model.move(PileType.FOUNDATION, 2, 12, PileType.CASCADE, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMoveWithInvalidCardIndex() {
    model.startGame(model.getDeck(), false);
    model.move(PileType.CASCADE, 2, 100, PileType.OPEN, 0);
  }

  @Test
  public void testRoundRobbinFashion() {
    String def = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣";
    model.startGame(model.getDeck(), false);
    Assert.assertEquals(def, model.getGameState());
  }

  @Test
  public void testValidMultiMoveFromCascadeToCascade() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 12, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 14, 1, PileType.CASCADE, 2);
    String result = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "O5:\n" +
            "O6:\n" +
            "O7:\n" +
            "O8:\n" +
            "O9:\n" +
            "O10:\n" +
            "C1: A♥\n" +
            "C2: 2♥, 5♦\n" +
            "C3: 3♥, 6♦, 5♣, 4♦, 3♣\n" +
            "C4: 4♥, 7♦\n" +
            "C5: 5♥, 8♦\n" +
            "C6: 6♥, 9♦\n" +
            "C7: 7♥, 10♦\n" +
            "C8: 8♥, J♦\n" +
            "C9: 9♥, Q♦\n" +
            "C10: 10♥, K♦\n" +
            "C11: J♥, A♣\n" +
            "C12: Q♥, 2♣\n" +
            "C13: K♥\n" +
            "C14: A♠, 4♣\n" +
            "C15: 2♠\n" +
            "C16: 3♠, 6♣\n" +
            "C17: 4♠, 7♣\n" +
            "C18: 5♠, 8♣\n" +
            "C19: 6♠, 9♣\n" +
            "C20: 7♠, 10♣\n" +
            "C21: 8♠, J♣\n" +
            "C22: 9♠, Q♣\n" +
            "C23: 10♠, K♣\n" +
            "C24: J♠\n" +
            "C25: Q♠\n" +
            "C26: K♠\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦";
    assertEquals(result, model7.getGameState());
  }

  @Test
  public void testValidMultiMoveFromCascadeToCascadeHavingMultipleCards() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 12, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 14, 1, PileType.CASCADE, 2);
    model7.move(PileType.CASCADE, 14, 0, PileType.CASCADE, 28);
    model7.move(PileType.CASCADE, 27, 0, PileType.CASCADE, 2);
    String result = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "O5:\n" +
            "O6:\n" +
            "O7:\n" +
            "O8:\n" +
            "O9:\n" +
            "O10:\n" +
            "C1: A♥\n" +
            "C2: 2♥, 5♦\n" +
            "C3: 3♥, 6♦, 5♣, 4♦, 3♣, 2♦\n" +
            "C4: 4♥, 7♦\n" +
            "C5: 5♥, 8♦\n" +
            "C6: 6♥, 9♦\n" +
            "C7: 7♥, 10♦\n" +
            "C8: 8♥, J♦\n" +
            "C9: 9♥, Q♦\n" +
            "C10: 10♥, K♦\n" +
            "C11: J♥, A♣\n" +
            "C12: Q♥, 2♣\n" +
            "C13: K♥\n" +
            "C14: A♠, 4♣\n" +
            "C15:\n" +
            "C16: 3♠, 6♣\n" +
            "C17: 4♠, 7♣\n" +
            "C18: 5♠, 8♣\n" +
            "C19: 6♠, 9♣\n" +
            "C20: 7♠, 10♣\n" +
            "C21: 8♠, J♣\n" +
            "C22: 9♠, Q♣\n" +
            "C23: 10♠, K♣\n" +
            "C24: J♠\n" +
            "C25: Q♠\n" +
            "C26: K♠\n" +
            "C27: A♦\n" +
            "C28:\n" +
            "C29: 3♦, 2♠";
    assertEquals(result, model7.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMultiMoveFromCascadeToCascadeWithMoreNumberOfMovesWrtoOpen() {
    model8.startGame(model7.getDeck(), false);
    model8.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    model8.move(PileType.CASCADE, 12, 1, PileType.CASCADE, 14);
    model8.move(PileType.CASCADE, 14, 1, PileType.CASCADE, 2);
  }

  @Test
  public void testValidMultiMoveFromCascadeToEmptyCascade() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 12, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 14, 1, PileType.CASCADE, 2);
    model7.move(PileType.CASCADE, 14, 0, PileType.CASCADE, 28);
    model7.move(PileType.CASCADE, 2, 1, PileType.CASCADE, 14);
    String result = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "O5:\n" +
            "O6:\n" +
            "O7:\n" +
            "O8:\n" +
            "O9:\n" +
            "O10:\n" +
            "C1: A♥\n" +
            "C2: 2♥, 5♦\n" +
            "C3: 3♥\n" +
            "C4: 4♥, 7♦\n" +
            "C5: 5♥, 8♦\n" +
            "C6: 6♥, 9♦\n" +
            "C7: 7♥, 10♦\n" +
            "C8: 8♥, J♦\n" +
            "C9: 9♥, Q♦\n" +
            "C10: 10♥, K♦\n" +
            "C11: J♥, A♣\n" +
            "C12: Q♥, 2♣\n" +
            "C13: K♥\n" +
            "C14: A♠, 4♣\n" +
            "C15: 6♦, 5♣, 4♦, 3♣\n" +
            "C16: 3♠, 6♣\n" +
            "C17: 4♠, 7♣\n" +
            "C18: 5♠, 8♣\n" +
            "C19: 6♠, 9♣\n" +
            "C20: 7♠, 10♣\n" +
            "C21: 8♠, J♣\n" +
            "C22: 9♠, Q♣\n" +
            "C23: 10♠, K♣\n" +
            "C24: J♠\n" +
            "C25: Q♠\n" +
            "C26: K♠\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦, 2♠";
    assertEquals(result, model7.getGameState());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMultiMoveFromCascadeToEmptyCascade() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 12, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 14, 1, PileType.CASCADE, 2);
    model7.move(PileType.CASCADE, 14, 0, PileType.CASCADE, 28);
    model7.move(PileType.CASCADE, 2, 0, PileType.CASCADE, 14);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMultiMoveToOpenWithMultipleCard() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 12, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 14, 1, PileType.OPEN, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMultiMoveToFoundationWithMultipleCards() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 12, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 14, 1, PileType.FOUNDATION, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMultiMoveToFoundationWithSingleCardNotA() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 0, 1, PileType.FOUNDATION, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMultiMoveFromCascadeWithCardIndexNotValid() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 2, -1, PileType.CASCADE, 14);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInValidMultiMoveFromCascadeWithCardIndexNotValidWithMultipleCards() {
    model7.startGame(model7.getDeck(), false);
    model7.move(PileType.CASCADE, 0, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 12, 1, PileType.CASCADE, 14);
    model7.move(PileType.CASCADE, 14, 2, PileType.CASCADE, 2);
  }


}
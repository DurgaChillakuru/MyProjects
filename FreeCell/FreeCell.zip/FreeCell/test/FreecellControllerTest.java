import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;

import freecell.controller.FreecellController;
import freecell.controller.IFreecellController;
import freecell.model.FreecellModel;
import freecell.model.FreecellMultiMoveModel;
import freecell.model.FreecellOperations;

/**
 * This is the Freecell Controller JUnit test class. We can have two model for this. One can be
 * multimove model and another can be single move. Following class provide testcase for all the
 * model.
 */
public class FreecellControllerTest {
  private Reader stringReader;
  private StringBuffer out;
  private FreecellOperations model;
  private FreecellOperations modelMulti;
  private IFreecellController controller;

  @Before
  public void setup() {
    stringReader = new StringReader("C1 13 O1 q");
    out = new StringBuffer();
    model = FreecellModel.getBuilder().build();
    modelMulti = FreecellMultiMoveModel.getBuilder().build();
    controller = new FreecellController(stringReader, out);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkNullConstructor() {
    controller = new FreecellController(null, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkNullReadableConstructor() {
    controller = new FreecellController(null, out);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkNullArguableConstructor() {
    controller = new FreecellController(stringReader, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkDeckForController() {
    controller.playGame(model.getDeck().subList(0, 24), model, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkModelForController() {
    controller.playGame(model.getDeck(), null, false);
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkModelForEmptyDeck() {
    controller.playGame(new ArrayList(), model, false);
  }

  @Test
  public void checkInvalidMoveCharacter() {
    stringReader = new StringReader("A1 13 O1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(model.getDeck(), model, false);
    Assert.assertTrue(out.toString().contains("Input invalid. Try again."));
  }

  @Test
  public void checkInvalidIndex() {
    stringReader = new StringReader("C1 15 O1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(model.getDeck(), model, false);
    Assert.assertTrue(out.toString().contains("Invalid move. Try again."));
  }

  @Test
  public void checkInvalidZeroIndex() {
    stringReader = new StringReader("C1 0 O1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, false);
    Assert.assertTrue(out.toString().contains("Input invalid. Try again."));
  }

  @Test
  public void checkInvalidNegIndex() {
    stringReader = new StringReader("C1 -5 O1 Q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, false);
    Assert.assertTrue(out.toString().contains("Input invalid. Try again."));
  }

  @Test
  public void checkQuitAfterSource() {
    String output = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣\n" +
            "Please start the Game with first move: \n" +
            "Game quit prematurely.";
    stringReader = new StringReader("C1 Q O1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, false);
    Assert.assertEquals(output, out.toString());
  }

  @Test
  public void checkQuitAfterIndex() {
    String output = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣\n" +
            "Please start the Game with first move: \n" +
            "Game quit prematurely.";
    stringReader = new StringReader("C1 1 q O1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, false);
    Assert.assertEquals(output, out.toString());
  }

  @Test
  public void checkQuitBeforeSourceCapitalQ() {
    String output = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣\n" +
            "Game quit prematurely.";
    stringReader = new StringReader("Q C1 Q O1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, false);
    Assert.assertEquals(output, out.toString());
  }

  @Test
  public void testMove() {
    String output = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣\n" +
            "Please start the Game with first move: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1: 10♣\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣\n" +
            "Game quit prematurely.";
    controller.playGame(model.getDeck(), model, false);
    Assert.assertEquals(output, out.toString());
  }

  @Test
  public void testMultiMove() {
    String output = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "O5:\n" +
            "O6:\n" +
            "O7:\n" +
            "O8:\n" +
            "O9:\n" +
            "O10:\n" +
            "C1: A♥, 4♦\n" +
            "C2: 2♥, 5♦\n" +
            "C3: 3♥, 6♦\n" +
            "C4: 4♥, 7♦\n" +
            "C5: 5♥, 8♦\n" +
            "C6: 6♥, 9♦\n" +
            "C7: 7♥, 10♦\n" +
            "C8: 8♥, J♦\n" +
            "C9: 9♥, Q♦\n" +
            "C10: 10♥, K♦\n" +
            "C11: J♥, A♣\n" +
            "C12: Q♥, 2♣\n" +
            "C13: K♥, 3♣\n" +
            "C14: A♠, 4♣\n" +
            "C15: 2♠, 5♣\n" +
            "C16: 3♠, 6♣\n" +
            "C17: 4♠, 7♣\n" +
            "C18: 5♠, 8♣\n" +
            "C19: 6♠, 9♣\n" +
            "C20: 7♠, 10♣\n" +
            "C21: 8♠, J♣\n" +
            "C22: 9♠, Q♣\n" +
            "C23: 10♠, K♣\n" +
            "C24: J♠\n" +
            "C25: Q♠\n" +
            "C26: K♠\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "Please start the Game with first move: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "O5:\n" +
            "O6:\n" +
            "O7:\n" +
            "O8:\n" +
            "O9:\n" +
            "O10:\n" +
            "C1: A♥\n" +
            "C2: 2♥, 5♦\n" +
            "C3: 3♥, 6♦\n" +
            "C4: 4♥, 7♦\n" +
            "C5: 5♥, 8♦\n" +
            "C6: 6♥, 9♦\n" +
            "C7: 7♥, 10♦\n" +
            "C8: 8♥, J♦\n" +
            "C9: 9♥, Q♦\n" +
            "C10: 10♥, K♦\n" +
            "C11: J♥, A♣\n" +
            "C12: Q♥, 2♣\n" +
            "C13: K♥, 3♣\n" +
            "C14: A♠, 4♣\n" +
            "C15: 2♠, 5♣, 4♦\n" +
            "C16: 3♠, 6♣\n" +
            "C17: 4♠, 7♣\n" +
            "C18: 5♠, 8♣\n" +
            "C19: 6♠, 9♣\n" +
            "C20: 7♠, 10♣\n" +
            "C21: 8♠, J♣\n" +
            "C22: 9♠, Q♣\n" +
            "C23: 10♠, K♣\n" +
            "C24: J♠\n" +
            "C25: Q♠\n" +
            "C26: K♠\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "Please start the Game with first move: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "O5:\n" +
            "O6:\n" +
            "O7:\n" +
            "O8:\n" +
            "O9:\n" +
            "O10:\n" +
            "C1: A♥\n" +
            "C2: 2♥, 5♦\n" +
            "C3: 3♥, 6♦\n" +
            "C4: 4♥, 7♦\n" +
            "C5: 5♥, 8♦\n" +
            "C6: 6♥, 9♦\n" +
            "C7: 7♥, 10♦\n" +
            "C8: 8♥, J♦\n" +
            "C9: 9♥, Q♦\n" +
            "C10: 10♥, K♦\n" +
            "C11: J♥, A♣\n" +
            "C12: Q♥, 2♣\n" +
            "C13: K♥\n" +
            "C14: A♠, 4♣\n" +
            "C15: 2♠, 5♣, 4♦, 3♣\n" +
            "C16: 3♠, 6♣\n" +
            "C17: 4♠, 7♣\n" +
            "C18: 5♠, 8♣\n" +
            "C19: 6♠, 9♣\n" +
            "C20: 7♠, 10♣\n" +
            "C21: 8♠, J♣\n" +
            "C22: 9♠, Q♣\n" +
            "C23: 10♠, K♣\n" +
            "C24: J♠\n" +
            "C25: Q♠\n" +
            "C26: K♠\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "Please start the Game with first move: \n" +
            "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "O5:\n" +
            "O6:\n" +
            "O7:\n" +
            "O8:\n" +
            "O9:\n" +
            "O10:\n" +
            "C1: A♥\n" +
            "C2: 2♥, 5♦\n" +
            "C3: 3♥, 6♦, 5♣, 4♦, 3♣\n" +
            "C4: 4♥, 7♦\n" +
            "C5: 5♥, 8♦\n" +
            "C6: 6♥, 9♦\n" +
            "C7: 7♥, 10♦\n" +
            "C8: 8♥, J♦\n" +
            "C9: 9♥, Q♦\n" +
            "C10: 10♥, K♦\n" +
            "C11: J♥, A♣\n" +
            "C12: Q♥, 2♣\n" +
            "C13: K♥\n" +
            "C14: A♠, 4♣\n" +
            "C15: 2♠\n" +
            "C16: 3♠, 6♣\n" +
            "C17: 4♠, 7♣\n" +
            "C18: 5♠, 8♣\n" +
            "C19: 6♠, 9♣\n" +
            "C20: 7♠, 10♣\n" +
            "C21: 8♠, J♣\n" +
            "C22: 9♠, Q♣\n" +
            "C23: 10♠, K♣\n" +
            "C24: J♠\n" +
            "C25: Q♠\n" +
            "C26: K♠\n" +
            "C27: A♦\n" +
            "C28: 2♦\n" +
            "C29: 3♦\n" +
            "Game quit prematurely.";
    modelMulti = new FreecellMultiMoveModel(29, 10);
    stringReader = new StringReader("C1 2 C15 C13 2 C15 C15 2 C3 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, false);
    Assert.assertEquals(output, out.toString());
  }

  @Test
  public void checkComplete() {
    StringBuilder s = new StringBuilder();
    for (int i = 1; i < 14; i++) {
      s.append("C").append(i).append(" 4 F1 ");
    }
    for (int i = 1; i < 14; i++) {
      s.append("C").append(i).append(" 3 F2 ");
    }
    for (int i = 1; i < 14; i++) {
      s.append("C").append(i).append(" 2 F3 ");
    }
    for (int i = 1; i < 14; i++) {
      s.append("C").append(i).append(" 1 F4 ");
    }
    modelMulti = new FreecellMultiMoveModel(13, 4);
    stringReader = new StringReader(s.toString());
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, false);
    Assert.assertTrue(out.toString().contains("Game over."));
  }

  @Test
  public void testMoveToFoundation() {
    String output = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♠, A♦, A♣\n" +
            "C2: 2♥, 2♠, 2♦, 2♣\n" +
            "C3: 3♥, 3♠, 3♦, 3♣\n" +
            "C4: 4♥, 4♠, 4♦, 4♣\n" +
            "C5: 5♥, 5♠, 5♦, 5♣\n" +
            "C6: 6♥, 6♠, 6♦, 6♣\n" +
            "C7: 7♥, 7♠, 7♦, 7♣\n" +
            "C8: 8♥, 8♠, 8♦, 8♣\n" +
            "C9: 9♥, 9♠, 9♦, 9♣\n" +
            "C10: 10♥, 10♠, 10♦, 10♣\n" +
            "C11: J♥, J♠, J♦, J♣\n" +
            "C12: Q♥, Q♠, Q♦, Q♣\n" +
            "C13: K♥, K♠, K♦, K♣\n" +
            "Please start the Game with first move: \n" +
            "F1: A♣\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "O2:\n" +
            "O3:\n" +
            "O4:\n" +
            "C1: A♥, A♠, A♦\n" +
            "C2: 2♥, 2♠, 2♦, 2♣\n" +
            "C3: 3♥, 3♠, 3♦, 3♣\n" +
            "C4: 4♥, 4♠, 4♦, 4♣\n" +
            "C5: 5♥, 5♠, 5♦, 5♣\n" +
            "C6: 6♥, 6♠, 6♦, 6♣\n" +
            "C7: 7♥, 7♠, 7♦, 7♣\n" +
            "C8: 8♥, 8♠, 8♦, 8♣\n" +
            "C9: 9♥, 9♠, 9♦, 9♣\n" +
            "C10: 10♥, 10♠, 10♦, 10♣\n" +
            "C11: J♥, J♠, J♦, J♣\n" +
            "C12: Q♥, Q♠, Q♦, Q♣\n" +
            "C13: K♥, K♠, K♦, K♣\n" +
            "Game quit prematurely.";
    model = new FreecellMultiMoveModel(13, 4);
    stringReader = new StringReader("C1 4 F1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(model.getDeck(), model, false);
    Assert.assertEquals(output, out.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void checkEmptyDeck() {
    stringReader = new StringReader("C1 15 O1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(null, model, false);
  }

  @Test
  public void testShuffle() {
    String output = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣\n" +
            "Please start the Game with first move: \n" +
            "Game quit prematurely.";
    stringReader = new StringReader("C1 Q O1 q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, true);
    Assert.assertNotEquals(output,out.toString());
  }

  @Test
  public void checkQuitBeforeSourceSmallQ() {
    String output = "F1:\n" +
            "F2:\n" +
            "F3:\n" +
            "F4:\n" +
            "O1:\n" +
            "C1: A♥, 5♥, 9♥, K♥, 4♠, 8♠, Q♠, 3♦, 7♦, J♦, 2♣, 6♣, 10♣\n" +
            "C2: 2♥, 6♥, 10♥, A♠, 5♠, 9♠, K♠, 4♦, 8♦, Q♦, 3♣, 7♣, J♣\n" +
            "C3: 3♥, 7♥, J♥, 2♠, 6♠, 10♠, A♦, 5♦, 9♦, K♦, 4♣, 8♣, Q♣\n" +
            "C4: 4♥, 8♥, Q♥, 3♠, 7♠, J♠, 2♦, 6♦, 10♦, A♣, 5♣, 9♣, K♣\n" +
            "Game quit prematurely.";
    stringReader = new StringReader("q");
    controller = new FreecellController(stringReader, out);
    controller.playGame(modelMulti.getDeck(), modelMulti, false);
    Assert.assertEquals(output,out.toString());
  }

}
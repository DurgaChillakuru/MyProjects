package freecell.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import freecell.model.FreecellOperations;
import freecell.model.PileType;

/**
 * This is the controller class of Freecell Implementation. This provide controller functionality
 * for the Freecell Game. This class gets the input from user and transmit it to Free cell model.
 * And this class gets the response from the user as Gamestate and displays it to the User. If the
 * Game is won, then it will notify user about the victory. If the user quit the game early, then it
 * just stops the Game.
 */
public class FreecellController<K> implements IFreecellController<K> {

  private Readable rd;
  private Appendable ap;

  /**
   * This is the constructor for Freecell Controller. This will initializes the class variable
   * readable and appendable object.
   *
   * @param rd is the readable object.
   * @param ap is the appendable object.
   */
  public FreecellController(Readable rd, Appendable ap) {
    if (rd == null || ap == null) {
      throw new IllegalArgumentException("Readable and appendable cannot be null");
    }
    this.rd = rd;
    this.ap = ap;
  }

  @Override
  public void playGame(List<K> deck, FreecellOperations<K> model,
                       boolean shuffle) throws IllegalArgumentException, IllegalStateException {

    // Check the Deck is valid or not.
    if (deck == null || deck.size() != 52 || model == null) {
      throw new IllegalArgumentException("Deck or Model is not properly Initialized.");
    }

    try {
      model.startGame(deck, shuffle);
    } catch (IllegalArgumentException e) {
      this.displayToUser("Cannot start the Game. Please try again.");
      return;
    }
    // Ask for the input.
    getUserInput(model);
  }

  /**
   * This Method is responsible for getting user input. This will wait till the user input. If an
   * input is unexpected (i.e. something other than 'q' or 'Q' to quit the game; a letter other than
   * 'C', 'F', 'O' to name a pile; anything that cannot be parsed to a valid number after the pile
   * letter; anything that is not a number for the card index) This method will ask the user to
   * input it again.If the user entered the source pile correctly but the card index incorrectly,
   * the controller will ask for the card index again, not the source pile and likewise for the
   * destination pile. If the move was invalid as signaled by the model, the controller will
   * transmit a message to the Appendable object Invalid move. Try again.
   *
   * @param model The model this game represent.
   */
  private void getUserInput(FreecellOperations<K> model) {
    Scanner scanner = new Scanner(rd);
    PileType source = null;
    Integer sourcePileNumber = null;
    Integer cardIndex = null;
    PileType destination;
    Integer destinationPileNumber;

    // Now display the Game state to user.
    displayToUser(model.getGameState() + "\n");

    while (!model.isGameOver()) {
      try {

        if (scanner.hasNext("q") || scanner.hasNext("Q")) {
          displayToUser("Game quit prematurely.");
          return;
        }
        // inform user about the required input.
        informUserInputRequired(source, sourcePileNumber, cardIndex);

        // map Parameters now
        if (source == null || sourcePileNumber == null) {
          List parseValue = mapParameter(scanner);
          source = (PileType) parseValue.get(0);
          sourcePileNumber = (Integer) parseValue.get(1);
        }
        // Again check for Quit
        if (scanner.hasNext("q") || scanner.hasNext("Q")) {
          displayToUser("Game quit prematurely.");
          return;
        }

        if (cardIndex == null) {
          String input = scanner.next();
          int index = Integer.parseInt(input);
          if (index <= 0) {
            throw new IllegalArgumentException("Index cannot be negative or zero");
          }
          cardIndex = index - 1;
        }

        // Again check for Quit
        if (scanner.hasNext("q") || scanner.hasNext("Q")) {
          displayToUser("Game quit prematurely.");
          return;
        }
        ArrayList parse = (ArrayList) mapParameter(scanner);
        destination = (PileType) parse.get(0);
        destinationPileNumber = (Integer) parse.get(1);
      } catch (IllegalArgumentException e) {
        displayToUser("Input invalid. Try again.\n");
        continue;
      }
      // We got all the Values Try move now.
      try {
        model.move(source, sourcePileNumber, cardIndex, destination, destinationPileNumber);
        displayToUser(model.getGameState() + "\n");
      } catch (Exception exception) {
        displayToUser("Invalid move. Try again.\n");
      }
      // Before proceeding reset all again.
      source = null;
      sourcePileNumber = null;
      cardIndex = null;
    }
    displayToUser("Game over.\n");
  }

  /**
   * This is a helper method which retrieve the Pile and pile number from the scanner.
   *
   * @param scanner the scanner from which we will get the next value.
   * @return the list containing pile and pile number.
   * @throws IllegalArgumentException if the pile number provided is 0 or negative.
   */
  private List<Object> mapParameter(Scanner scanner) throws IllegalArgumentException {
    ArrayList list = new ArrayList();
    String scannerValue = scanner.next();
    list.add(getPile(scannerValue.charAt(0)));
    int pileNum = Integer.parseInt(scannerValue.substring(1));
    if (pileNum <= 0) {
      throw new IllegalArgumentException("Pile Number cannot be less than 1");
    }
    list.add(pileNum - 1);
    return list;
  }

  /**
   * This is a helper method which identify the character and return corresponding pile. There can
   * be only 4 valid character O,C,F,q or Q. Since we are already checking the q before, we are
   * considering the remaining character in here. Based on the switch statement, we can get the
   * corresponding pile type.
   *
   * @param pile is the pile code from which we will retrieve the pile Name.
   * @return the pile type corresponding to the character which user inputted.
   * @throws IllegalArgumentException if the character is not one of the predefined character for
   *                                  pile type.
   */
  private PileType getPile(char pile) throws IllegalArgumentException {
    switch (pile) {
      case 'O':
        return PileType.OPEN;
      case 'C':
        return PileType.CASCADE;
      case 'F':
        return PileType.FOUNDATION;
      default:
        throw new IllegalArgumentException("The input provided is not a valid Pile.");
    }
  }

  /**
   * This method is responsible to show which input it is waiting for the Freecell Game. This method
   * inform the user about what input model game is expecting. Since initially we initializes
   * everything to null, we are checking the same here and based on that we are displaying message.
   *
   * @param source           the source pile from which card needs to be moved.
   * @param sourcePileNumber the source pile number from which card needs to be moved.
   * @param cardIndex        the index of the card in the source pile.
   */
  private void informUserInputRequired(PileType source, Integer sourcePileNumber,
                                       Integer cardIndex) {
    if (source == null || sourcePileNumber == null) {
      displayToUser("Please start the Game with first move: \n");
    } else if (cardIndex == null) {
      displayToUser("Enter a card number and Destination :\n");
    } else {
      displayToUser("Enter the destination pile and pileNumber :\n");
    }
  }

  /**
   * This method is responsible to display the output to the user.This will append the User message
   * to appendable object. Which in turn shows the message to the User.
   *
   * @param message The message to be displayed to user.
   */
  private void displayToUser(String message) {

    if (null != message && !message.equals("")) {

        try {
          ap.append(message);
        } catch (IOException e) {
          // Not sure if the IO exception corrects in time. So not sending error message.
          //this.displayToUser("IO Exception occurred and so returning");
        }
      }
  }
}
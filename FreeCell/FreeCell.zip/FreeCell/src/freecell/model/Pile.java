package freecell.model;

/**
 * This is the interface for piles. This interface contain method which are common for cascade, open
 * and foundation piles.
 */
public interface Pile {

  /**
   * This method will add the card to corresponding piles. This will check for all the rules of game
   * and if there is any mismatch then it will throw exception. Following are the condition which is
   * consider as invalid while adding any card to pile. 1. If the first card in foundation we are
   * adding is not A 2. If in the foundation pile we are not adding card in increment order. 3. If
   * in the cascade pile we are adding card of same colour. 4. If in the cascade pile we are trying
   * to add card which is not less than one rank. 5. If any of the card Index doesn't exist in any
   * of the pile. 6. If we are trying to move card from Empty pile.
   *
   * @param card is the card which needs to be added to piles.
   * @throws IllegalArgumentException if any of the game rules are broken.
   */
  void addCardCheck(Card card) throws IllegalArgumentException;

  /**
   * This method gives the size of the pile.
   *
   * @return the size of the Pile.
   */
  int size();

}
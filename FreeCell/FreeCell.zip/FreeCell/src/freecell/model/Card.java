package freecell.model;

/**
 * This class represent the card class in a deck.
 * This class is used to generate a card in the deck to play Freecell game. Each card has attributes
 * like card suit(either heart, diamond, spade or clover) and has a rank ranging from 2 to 10 along
 * with Ace, Jack, Queen and King.
 */
public class Card {

  private final String cardSymbol;
  private final String rank;

  /**
   * This is the constructor of class card. This will store the card symbol as well as the rank of
   * the card. If the card is 10 club it will store 10 and club symbol i.e ♣.
   *
   * @param cardSymbol The symbol of the card. For ex club will be ♣.
   * @param rank       The rank of the card. For ex 10.
   */
  public Card(String cardSymbol, String rank) {
    this.cardSymbol = cardSymbol;
    this.rank = rank;
  }


  /**
   * Two cards are equal if the rank and card symbol are same. So we have overridden the equals
   * method such that it returns true if both matches else false.
   *
   * @param other The other card object to compare with.
   * @return True if the card is same. i.e card has same symbol and same rank.
   */
  @Override
  public boolean equals(Object other) {
    if (!(other instanceof Card)) {
      return false;
    }
    Card otherCard = (Card) other;
    return this.rank.equals(otherCard.rank) && this.cardSymbol.equals(otherCard.cardSymbol);
  }

  /**
   * This method over rides the hash code of the card. We are taking the card symbol and card rank
   * hashcode and combining both of them to give a new hashcode.
   *
   * @return the new hash code of the card.
   */
  @Override
  public int hashCode() {
    return (this.rank.hashCode() + this.cardSymbol.hashCode());
  }

  /**
   * Overriden toString method for display purpose. If we want to display 10 of clubs then it will
   * display as 10♣.
   */
  public String toString() {
    return this.rank + this.cardSymbol;
  }

  /**
   * This method gives the colour of the card. We are deciding based on the symbol.
   * @return the cardColour of this card.
   */
  public String getCardColour() {
    if ( this.cardSymbol.equals("♥") || this.cardSymbol.equals("♦") ) {
      return "red";
    } else {
      return "black";
    }
  }

  /**
   * This method gives the card symbol.
   * @return the symbol of the card this card represent.
   */
  public String getCardSymbol() {
    return this.cardSymbol;
  }

  /**
   * This Method gives the rank of the card. Here we are considering A as 1, J=11 and so on.
   * @return the rank of the card.
   */
  public String getRank() {
    switch (rank) {
      case "A" :
        return "1";
      case "J" :
        return "11";
      case "Q" :
        return "12";
      case "K" :
        return "13";
      default:
        return this.rank;
    }
  }

}


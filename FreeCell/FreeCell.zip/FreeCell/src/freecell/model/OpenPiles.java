package freecell.model;

import java.util.ArrayDeque;

/**
 * This class represent the Open piles of free cell game. This class implements Pile interface
 * and it extends the ArrayDeque. This class represent the array of card in the open piles. This
 * class adds the card to the piles only if the open pile size is zero.
 */

public class OpenPiles extends ArrayDeque<Card> implements Pile {
  @Override
  public void addCardCheck(Card card) throws IllegalArgumentException {

    if (this.size() == 0) {
      this.addFirst(card);
    }
    else {
      throw new IllegalArgumentException("Open piles cannot hold more than one");
    }

  }
}

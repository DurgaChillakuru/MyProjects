package freecell.model;

import java.util.ArrayDeque;

/**
 * This class represent the cascade piles of free cell game. This class implements Pile interface
 * and it extends the ArrayDeque. This class represent the array of card in the cascade piles. This
 * class adds the card to the piles only if the card which is getting added has a different colour
 * and rank of the card is exactly one less than the card which is in top of the pile.
 */
public class CascadePiles extends ArrayDeque<Card> implements Pile {
  @Override
  public void addCardCheck(Card card) throws IllegalArgumentException {

    if (this.size() != 0) {
      Card firstCard = this.peekFirst();
      int lastRank = Integer.parseInt(firstCard.getRank());
      int currentRank = Integer.parseInt(card.getRank());
      if (lastRank - 1 == currentRank && !firstCard.getCardColour().equals(card.getCardColour())) {
        this.addFirst(card);
      } else {
        throw new IllegalArgumentException("Either colour is same or rank is not exactly less " +
                "than one");
      }
    } else {
      this.addFirst(card);
    }
  }
}

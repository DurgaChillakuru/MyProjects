package freecell.model;

/**
 * This is the FreeCell operations builder Interface. This Interface will help in customizing the
 * Freecell Build constructor.
 */
public interface FreecellOperationsBuilder<K> {
  FreecellOperationsBuilder cascades(int c);

  FreecellOperationsBuilder opens(int o);

  FreecellOperations<K> build();
}

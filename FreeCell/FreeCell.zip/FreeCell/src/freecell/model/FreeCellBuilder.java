package freecell.model;

/**
 * This is a Builder class which help in creating the Freecell Model object. This class can modify
 * the cascade and open pile size to user wish pile size. There is restriction on this, cascade
 * cannot be less than 4 and opens piles cannot be less than 1. This class facilitates these values
 * to be initialized and create a object of type FreeCell Model.
 */
public class FreeCellBuilder implements FreecellOperationsBuilder<Card> {
  private int cascades;
  private int opens;
  private GameModel gameType;

  /**
   * This is Enum for Single move or MultiMove model.
   */
  public enum GameModel {
    SINGLEMOVEMODEL, MULTIMOVEMODEL;
  }

  /**
   * This is a constructor class which initializes the value of cascade piles to 4 and opens to 1.
   * We are assuming these are the default values.
   */
  public FreeCellBuilder() {
    cascades = 4;
    opens = 1;
    gameType = GameModel.SINGLEMOVEMODEL;
  }

  /**
   * This is a constructor class which initializes the value of cascade and open piles. This also
   * sets the game model whether it is multimove or single move model.
   *
   * @param gameModel is the gamemodel which we will set for multimove.
   */
  public FreeCellBuilder(GameModel gameModel) {
    cascades = 4;
    opens = 1;
    gameType = gameModel;
  }

  /**
   * This method help in changing the cascade pile length.
   *
   * @param cascadeNum size of the cascade piles length.
   * @return returns the FreeCellBuilder object.
   */
  @Override
  public FreecellOperationsBuilder cascades(int cascadeNum) {
    this.cascades = cascadeNum;
    return this;
  }

  /**
   * This method help in changing the opens pile length.
   *
   * @param openNum size of the opens piles length.
   * @return returns the FreeCellBuilder object.
   */
  @Override
  public FreecellOperationsBuilder opens(int openNum) {
    this.opens = openNum;
    return this;
  }

  /**
   * This is a build Method which creates the FreeCell Model object using the cascade and opens
   * parameter. These are set by the client before calling the build object, else this will set the
   * default values. Default values are mentioned in the constructor of this class.
   *
   * @return the FreecellModel object with the specified cascade and opens piles length.
   */
  @Override
  public FreecellOperations<Card> build() {
    if (gameType.equals(GameModel.MULTIMOVEMODEL)) {
      return new FreecellMultiMoveModel(cascades, opens);
    } else {
      return new FreecellModel(cascades, opens);
    }
  }

}
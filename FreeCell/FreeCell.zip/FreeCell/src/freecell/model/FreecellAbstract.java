package freecell.model;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * This is the FreeCell Model Abstract Class. This class helps in building the Model of Free cell
 * game. There are 3 card piles in Freecell game and this class facilitates these variable to be
 * initialized and allow them to modify as well. This class implements all the common methods
 * required for single move and multi move model.
 */
public abstract class FreecellAbstract implements FreecellOperations<Card> {
  private final int FOUNDATION = 4;
  protected int cascades;
  protected int opens;
  protected ArrayList<Pile> cascadePiles = new ArrayList<>();
  protected ArrayList<Pile> openPiles = new ArrayList<>();
  protected ArrayList<Pile> foundationPiles = new ArrayList<>();
  protected boolean isGameStarted = false;

  /**
   * This is a constructor class of FreeCell. This will accept how many cascade and open piles
   * required for the Free Cell Game. This class will throw exception if the cascade piles size is
   * less than 4 and open pile size is less than 1.
   *
   * @param cascade Number of cascade piles in the free cell game.
   * @param open    Number of open piles in the Free cell game.
   */
  public FreecellAbstract(int cascade, int open) {
    if (cascade < 4 || open < 1) {
      throw new IllegalArgumentException(" Cascade cannot be less than 4 and open piles " +
              "cannot be less than 1");
    }
    cascades = cascade;
    opens = open;
  }

  @Override
  public List<Card> getDeck() {
    List<Card> deck = new ArrayList<>();
    String[] suits = {"♥", "♠", "♦", "♣"};
    String[] ranks = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
    String cardSymbol;
    String rank;
    Card card;
    for (int i = 0; i < suits.length; i++) {
      for (int j = 0; j < ranks.length; j++) {
        cardSymbol = suits[i];
        rank = ranks[j];
        card = new Card(cardSymbol, rank);
        if (!(deck.contains(card))) {
          deck.add(card);
        }
      }
    }
    return deck;
  }

  @Override
  public void startGame(List deck, boolean shuffle) throws IllegalArgumentException {
    isGameStarted = true;
    if (deck.size() != 52) {
      isGameStarted = false;
      throw new IllegalArgumentException("card size is not proper");
    }

    validateDeck(deck);
    if (cascadePiles.size() != 0 || openPiles.size() != 0 || foundationPiles.size() != 0) {
      cascadePiles = new ArrayList<>();
      openPiles = new ArrayList<>();
      foundationPiles = new ArrayList<>();
    }

    if (shuffle) {
      Collections.shuffle(deck);
    }

    List deckCopy = new ArrayList<>();
    for (int i = 0; i < deck.size(); i++) {
      deckCopy.add(deck.get(i));
    }

    for (int i = 0; i < cascades; i++) {
      cascadePiles.add(new CascadePiles());
    }
    for (int i = 0; i < opens; i++) {
      openPiles.add(new OpenPiles());
    }
    for (int i = 0; i < FOUNDATION; i++) {
      foundationPiles.add(new FoundationPiles());
    }
    int count = deck.size();
    for (int i = 0; i < count; i++) {
      CascadePiles j = (CascadePiles) cascadePiles.get(i % cascades);
      if (deckCopy.size() != 0) {
        j.addFirst((Card) deckCopy.get(0));
        deckCopy.remove(0);
      }
    }
  }

  /**
   * This Method validates whether deck of card is valid or not. This method will throw exception in
   * the following cases. Deck contain additional card or duplicate card. Deck contain less number
   * of card. Deck contain illegal character.
   *
   * @param deck is the deck of card which needs to be validated.
   */
  private void validateDeck(List<Card> deck) {
    List<String> cards = new ArrayList<>(Arrays.asList(
            "A♥", "A♦", "A♣", "A♠", "2♥", "2♦", "2♣", "2♠", "3♥", "3♦", "3♣", "3♠",
            "4♥", "4♦", "4♣", "4♠", "5♥", "5♦", "5♣", "5♠", "6♥", "6♦", "6♣", "6♠", "7♥",
            "7♦", "7♣", "7♠", "8♥", "8♦", "8♣", "8♠", "9♥", "9♦", "9♣", "9♠", "10♥", "10♦",
            "10♣", "10♠", "J♥", "J♦", "J♣", "J♠", "Q♥", "Q♦", "Q♣", "Q♠", "K♥", "K♦", "K♣", "K♠"));
    for (Card card : deck) {
      if (!cards.contains(card.toString())) {
        isGameStarted = false;
        throw new IllegalArgumentException("Deck is not valid");
      }
      cards.remove(card.toString());
    }
    if (cards.size() != 0) {
      throw new IllegalArgumentException("Duplicate card is present");
    }
  }

  /**
   * This Method returns the  exact pile in the list of piles. Based on the user input pile type it
   * will return the corresponding Arraylist of pile. This method will throw exception if pile
   * requested doesn't exist. This method throw IllegalArgument exception if the pile type is not
   * any of the predefined pile type.
   *
   * @param type is the pile type.
   * @return the pile which is required for the operation.
   */
  protected Pile getPile(PileType type, int pileNum) throws IllegalStateException,
          IllegalArgumentException {

    Pile destPile;

    switch (type) {
      case CASCADE:
        if (pileNum > this.cascadePiles.size() - 1) {
          throw new IllegalStateException("pilenumber cannot be greater than cascadePiles size.");
        }
        destPile = this.cascadePiles.get(pileNum);
        break;
      case FOUNDATION:
        if (pileNum > this.foundationPiles.size() - 1) {
          throw new IllegalStateException("pilenum cannot be greater than foundationPiles size.");
        }
        destPile = this.foundationPiles.get(pileNum);
        break;
      case OPEN:
        if (pileNum > this.openPiles.size() - 1) {
          throw new IllegalStateException("pilenumber cannot be greater than openPile size.");
        }
        destPile = this.openPiles.get(pileNum);
        break;
      default:
        throw new IllegalArgumentException("Pile type is not one of the supported type");
    }
    return destPile;
  }

  @Override
  public boolean isGameOver() {
    for (Pile cascadePile : cascadePiles) {
      if ((cascadePile.size() != 0)) {
        return false;
      }
    }
    for (Pile foundationPile : foundationPiles) {
      if ((foundationPile.size() != 13)) {
        return false;
      }
    }
    for (Pile openPile : openPiles) {
      if ((openPile.size() != 0)) {
        return false;
      }
    }
    return true;
  }

  @Override
  public String getGameState() {
    if (!isGameStarted) {
      return "";
    }
    if (openPiles.size() == 0 && cascadePiles.size() == 0 && foundationPiles.size() == 0) {
      return "";
    } else {
      String output = "";
      output += getOutput(foundationPiles, "F");
      output += getOutput(openPiles, "O");
      output += getOutput(cascadePiles, "C");
      return output.trim();
    }

  }

  /**
   * This is a helper method for the string representation of the Game state. This method will loop
   * through all the piles and fetch all the card details and prints in order defined by interface.
   *
   * @param piles  Piles from which the String representation of card should be taken.
   * @param prefix The Prefix for each pile.
   * @return the String representation of all the card.
   */
  private String getOutput(ArrayList<Pile> piles, String prefix) {
    int count = 1;
    String output = "";
    for (Pile pile : piles) {
      output = output + (prefix) + (count++) + ": ";
      Iterator it = ((ArrayDeque<Card>) pile).descendingIterator();
      while (it.hasNext()) {
        output += it.next().toString() + ", ";
      }
      if (output.charAt(output.trim().length() - 1) == ',') {
        output = output.trim().substring(0, output.length() - 2);
      }
      output = output.trim();
      output += "\n";
    }
    return output;
  }
}

package freecell.model;

import java.util.ArrayDeque;

/**
 * This is the FreeCell Model Class. This class acts as Model in Free cell game. There are 3 card
 * piles in Freecell game and this class facilitates these variable to be initialized and allow them
 * to modify as well.
 */
public class FreecellModel extends FreecellAbstract {
  /**
   * This is a constructor class of FreeCellModel. This will accept how many cascade and open piles
   * required for the Free Cell Game. This class will throw exception if the cascade piles size is
   * less than 4 and open pile size is less than 1.
   *
   * @param cascade Number of cascade piles in the free cell game.
   * @param open    Number of open piles in the Free cell game.
   */
  public FreecellModel(int cascade, int open) {
    super(cascade,open);
  }

  /**
   * This is a static builder class which will return the free cell builder object. This class is
   * made static so that this can be called without instantiating the object in caller class.
   *
   * @return the new Builder object for the freecell game.
   */
  public static FreeCellBuilder getBuilder() {
    return new FreeCellBuilder();
  }

  @Override
  public void move(PileType source, int pileNumber, int cardIndex,
                   PileType destination, int destPileNumber) throws IllegalArgumentException,
          IllegalStateException {

    Card card;
    Pile currentPile;

    if (!this.isGameStarted) {
      throw new IllegalStateException("Game is yet to be started");
    }

    currentPile = getPile(source, pileNumber);

    if ((cardIndex != currentPile.size() - 1) || currentPile.size() == 0) {
      throw new IllegalArgumentException("Card is not the first card in the pile or pile is " +
              "empty");
    }

    card = ((ArrayDeque<Card>) currentPile).removeFirst();
    // Now we have to add it to destination card.
    currentPile = getPile(destination, destPileNumber);
    currentPile.addCardCheck(card);
  }
}

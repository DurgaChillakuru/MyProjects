package freecell.model;

import java.util.ArrayDeque;
import java.util.ArrayList;

/**
 * This is FreecellMultiMove model class. This class extends the FreecellModel and so all the
 * methods are inherited from FreeCellModel. In this class we are overriding the move method only,
 * since move allows multimove from cascade to cascade. A multi-card move is basically several
 * single-card moves, using free open piles and empty cascade piles as “intermediate slots” Thus a
 * multi-card move may not be feasible even though it obeys the above two conditions, if there
 * aren’t enough of these intermediate slots. More specifically, it can be proved that the maximum
 * number of cards that can be moved when there are 𝑁 free open piles and 𝐾 empty cascade piles is
 * (𝑁+1)∗2𝐾
 */
public class FreecellMultiMoveModel extends FreecellAbstract {

  /**
   * This is a constructor class of FreeCellModel. This will accept how many cascade and open piles
   * required for the Free Cell Game. This class will throw exception if the cascade piles size is
   * less than 4 and open pile size is less than 1.
   *
   * @param cascade Number of cascade piles in the free cell game.
   * @param open    Number of open piles in the Free cell game.
   */
  public FreecellMultiMoveModel(int cascade, int open) {
    super(cascade,open);
  }

  /**
   * This is a static builder class which will return the free cell builder object. This class is
   * made static so that this can be called without instantiating the object in caller class.
   *
   * @return the new Builder object for the freecell game.
   */
  public static FreeCellBuilder getBuilder() {
    return new FreeCellBuilder(FreeCellBuilder.GameModel.MULTIMOVEMODEL);
  }

  @Override
  public void move(PileType source, int pileNumber, int cardIndex, PileType destination,
                   int destPileNumber) throws IllegalArgumentException, IllegalStateException {

    Pile sourcePile;
    Pile destPile;
    ArrayList<Card> tempCard = new ArrayList<Card>();
    sourcePile = getPile(source, pileNumber);

    if (sourcePile.size() == 0) {
      throw new IllegalArgumentException("Pile is Empty");
    }
    // Maximum number of card moved can be given by formula  (𝑁+1)∗2𝐾
    // where 𝑁 - > free open piles and 𝐾 ->  empty cascade piles
    long freeOpenPiles = getEmptyPile(openPiles);
    long emptyCascadePiles = getEmptyPile(cascadePiles);
    double cascadeValue = Math.pow(2.0, (double) emptyCascadePiles);
    int maxNumberOfMove = (int) ((freeOpenPiles + 1) * cascadeValue);
    int currentMoveNumber = sourcePile.size() - cardIndex;
    if (currentMoveNumber < 0 || cardIndex < 0) {
      throw new IllegalArgumentException("Cannot move card as Index is not valid");
    }
    if (currentMoveNumber >= 2 && !destination.equals(PileType.CASCADE)) {
      throw new IllegalArgumentException("Multiple card move is allowed only for cascade.");
    }
    if (currentMoveNumber <= maxNumberOfMove) {
      for (int i = 0; i < currentMoveNumber; i++) {
        tempCard.add(((ArrayDeque<Card>) sourcePile).removeFirst());
      }
      destPile = getPile(destination, destPileNumber);
      int size = tempCard.size();
      for (int i = 0; i < size; i++) {
        destPile.addCardCheck(tempCard.remove(tempCard.size() - 1));
      }
    } else {
      throw new IllegalArgumentException("Cannot move that many cards.");
    }
  }

  /**
   * Returns the number of empty piles in the current list of piles.
   *
   * @param piles The array list of pile for which we need to calculate the empty piles.
   * @return the number of empty piles in the given list of piles
   */
  protected long getEmptyPile(ArrayList<Pile> piles) {
    long num = 0;
    num = piles.stream().filter(x -> x.size() == 0).count();
    return num;
  }
}

package portfoliooperation;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import view.ViewInterface;

/**
 * This is portfolio Operation view. This class present the user with different portfolio
 * operation.
 */
public class PortfolioOperationView extends JFrame implements ViewInterface {
  private JButton costBasis;
  private JButton valueBasis;
  private JButton portfolioTransaction;
  private static final String HEADING = "Portfolio Operation ";
  private JPanel portfolioOperation;

  /**
   * This is the constructor of portfolio view operation.
   */
  public PortfolioOperationView() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void initButton() {
    costBasis = new JButton("Portfolio Cost Basis");
    costBasis.setActionCommand("PCostBasis");
    portfolioOperation.add(costBasis);

    valueBasis = new JButton("Portfolio Value");
    valueBasis.setActionCommand("PValue");
    portfolioOperation.add(valueBasis);

    portfolioTransaction = new JButton("Complete Portfolio");
    portfolioTransaction.setActionCommand("CompletePort");
    portfolioOperation.add(portfolioTransaction);

    this.add(portfolioOperation, BorderLayout.CENTER);
    this.pack();
    this.setVisible(true);
  }

  private void configureLayout() {
    portfolioOperation = new JPanel();
    portfolioOperation.setPreferredSize(new Dimension(300, 300));
    GridLayout gridLayout = new GridLayout(3, 1);
    gridLayout.setVgap(20);
    gridLayout.setHgap(10);
    portfolioOperation.setLayout(gridLayout);
    portfolioOperation.setBorder(new TitledBorder("PortfolioOperation"));
  }

  @Override
  public void setActionListener(ActionListener listener) {
    costBasis.addActionListener(listener);
    valueBasis.addActionListener(listener);
    portfolioTransaction.addActionListener(listener);
  }
}

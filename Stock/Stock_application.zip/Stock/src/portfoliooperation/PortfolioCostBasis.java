package portfoliooperation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is costBasis view of the portfolio.
 */
public class PortfolioCostBasis extends JFrame implements ViewTextInterface {

  private static final String HEADING = "Cost Basis View";
  private String datePanelText;
  private JTextField[] textField = new JTextField[4];
  private JPanel mainPanel;
  private JButton query;
  private JButton back;
  private String buttaction;
  private Boolean datepanel;

  /**
   * This is the constructor class of Portfolio Cost Basis.
   */
  public PortfolioCostBasis(String datePanelText, String action, Boolean datePanel) {
    super();
    this.datePanelText = datePanelText;
    this.buttaction = action;
    this.datepanel = datePanel;
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void initButton() {
    JPanel button = new JPanel();
    query = new JButton("Query");
    query.setActionCommand(buttaction);

    back = new JButton("Back");
    back.setActionCommand("CostBasisBack");
    button.add(query);
    button.add(back);
    mainPanel.add(button);
  }

  private void configureLayout() {
    mainPanel = new JPanel();
    mainPanel.setPreferredSize(new Dimension(400, 200));
    JLabel portfolioName = new JLabel("Porfolio Name:");
    mainPanel.add(portfolioName);
    textField[3] = new JTextField(10);
    portfolioName.setLabelFor(textField[3]);
    mainPanel.add(textField[3]);
    if (datepanel) {
      mainPanel.add(getDatePanel());
    }
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.add(mainPanel, BorderLayout.CENTER);
    this.pack();
    this.setVisible(true);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    query.addActionListener(listener);
    back.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    StringBuilder sb = new StringBuilder();
    for (JTextField field : textField) {
      if (null != field) {
        sb.append(field.getText());
        sb.append(";");
      }
    }
    return sb.toString();
  }

  /**
   * This method gives the date panel.
   *
   * @return the date panel to be added to main panel.
   */
  private JPanel getDatePanel() {

    JPanel datePanel = new JPanel();
    datePanel.setBorder(BorderFactory.createTitledBorder(datePanelText));
    datePanel.setBackground(Color.lightGray);
    datePanel.setLayout(new FlowLayout());

    JLabel month = new JLabel("Month(MM):");
    datePanel.add(month);
    textField[0] = new JTextField(2);
    month.setLabelFor(textField[0]);

    datePanel.add(textField[0]);

    JLabel day = new JLabel("Day(DD):");
    datePanel.add(day);
    textField[1] = new JTextField(2);
    datePanel.add(textField[1]);
    day.setLabelFor(textField[1]);

    JLabel year = new JLabel("Year(YYYY):");
    datePanel.add(year);
    textField[2] = new JTextField(4);
    datePanel.add(textField[2]);
    year.setLabelFor(textField[2]);

    return datePanel;
  }

}

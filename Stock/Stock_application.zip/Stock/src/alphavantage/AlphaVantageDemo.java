package alphavantage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * This is a helper class to get the price of stock.
 */
public class AlphaVantageDemo {
  private String stockSymbol; //ticker symbol
  private Map inputList = new HashMap<>();
  private String apiKey = "N3DLE67YLDA723UC";

  /**
   * This is the constructor class which will initiate the stock symbol.
   *
   * @param sym This is the stock symbol for which we are querying for price.
   */
  public AlphaVantageDemo(String sym) {
    if (null == sym || "".equals(sym)) {
      throw new IllegalArgumentException("Stock symbol cannot be empty or null");
    }
    this.stockSymbol = sym.toUpperCase();
  }

  /**
   * This method will give the price map of a share with date as key and price as value.
   *
   * @return the price map in the format date : price.
   */
  public Map getPriceMap() {

    URL url;
    try {
      url = new URL("https://www.alphavantage"
              + ".co/query?function=TIME_SERIES_DAILY"
              + "&outputsize=full"
              + "&symbol"
              + "=" + stockSymbol + "&apikey=" + apiKey + "&datatype=csv");
    } catch (MalformedURLException e) {
      throw new RuntimeException("the alpha vantage API has either changed or "
              + "no longer works");
    }
    try (InputStream is = url.openStream();
         BufferedReader br = new BufferedReader(
                 new InputStreamReader(is))) {

      br.lines().forEach(e -> {
        if (e.contains("{")) {
          throw new IllegalArgumentException("API Limitation or stock doesn't exist");
        }
        String[] test = e.split(",");
        inputList.put(test[0], test[4]);
      });
    } catch (IOException e) {
      throw new IllegalArgumentException("No price data found for " + stockSymbol);
    }
    return inputList;
  }
}

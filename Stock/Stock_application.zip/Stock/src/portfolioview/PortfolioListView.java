package portfolioview;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import view.ViewInterface;

/**
 * This is the Portfolio list class. This class will list the Name of the existing portfolio.
 */
public class PortfolioListView extends JFrame implements ViewInterface {
  private final String HEADING = "List Portfolio";
  private JPanel portfolioListViewPanel;
  private JButton exit;
  private JLabel head;

  /**
   * This is the constructor class for the porfolio view. This class help in initializing the panel.
   * And Display the portfolio view panel.
   */
  public PortfolioListView(String list) {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton(list);
  }

  private void configureLayout() {
    portfolioListViewPanel = new JPanel();
    portfolioListViewPanel.setPreferredSize(new Dimension(400, 200));
    head = new JLabel();
    head.setText("List of Portfolio:");
    head.setForeground(Color.BLUE);
    head.setHorizontalTextPosition(JLabel.CENTER);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

  private void initButton(String list) {
    JPanel listPanel = new JPanel();
    list = list.replaceAll("\\n", "<br/>");
    JLabel listOfPortfolio = new JLabel("<html>" + list + "</html>");
    listPanel.add(listOfPortfolio);
    portfolioListViewPanel.add(head);
    portfolioListViewPanel.add(listPanel);

    exit = new JButton("Return");
    exit.setActionCommand("ExitListPortfolio");
    exit.setFont(new Font("Courier New", Font.ITALIC, 12));
    exit.setForeground(Color.green);
    portfolioListViewPanel.add(exit);

    add(portfolioListViewPanel);
    portfolioListViewPanel.setLayout(new BoxLayout(portfolioListViewPanel, BoxLayout.Y_AXIS));
    this.pack();
    this.setVisible(true);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    exit.addActionListener(listener);
  }
}

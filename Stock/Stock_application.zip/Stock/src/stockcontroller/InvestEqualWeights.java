package stockcontroller;

import java.time.DateTimeException;
import java.time.LocalDate;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * This class is used to represent the command to invest a fixed amount in a portfolio with equal
 * weight to all the stocks in that portoflio. This class implements the StocksCommands interface.
 * Overrides the method command to pass the necessary parameters to the model for execution of the
 * command.
 */
public class InvestEqualWeights implements StockCommands {

  private String pf_name;
  private double commissionAmt;
  private double investAmt;
  private int dd;
  private int mm;
  private int yyyy;

  /**
   * A public parametrized constructor to initialise the class varaibles.
   *
   * @param pfName  Represents the portfolio name to which the amount will be invested.
   * @param invAmt  Represents the amount to be invested in the portfolio.
   * @param commAmt Represents the commission amount, if the user says yes. Otherwise this amount
   *                would be 0.
   * @param dd      Represents the date of the month at which the amount has to be invested.
   * @param mm      Represents the month at which the amount has to be invested.
   * @param yyyy    Represents the year at which the amount has to be invested.
   */
  public InvestEqualWeights(String pfName, double invAmt, double commAmt, int dd, int mm,
                            int yyyy) {
    this.pf_name = pfName;
    this.commissionAmt = commAmt;
    this.investAmt = invAmt;
    this.dd = dd;
    this.mm = mm;
    this.yyyy = yyyy;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the success message as an output to the controller to display to the user.
   *
   * @param m model of the stock implementation.
   * @return gives the success message along with remaining amount, in case if any.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    double remAmt;
    try {
      LocalDate date = LocalDate.of(yyyy, mm, dd);
      remAmt = m.investFixedAmountEqualWeight(date, investAmt, pf_name, commissionAmt);
    } catch (DateTimeException e) {
      return e.getMessage();
    }
    return "Successfully, the amount has been invested in the portfolio with equal weightage on " +
            "all stocks and the remaninig amount " + remAmt + " has been transferred back !!\n";
  }
}

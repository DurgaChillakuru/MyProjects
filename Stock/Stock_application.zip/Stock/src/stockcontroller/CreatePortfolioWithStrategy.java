package stockcontroller;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * A class to represent a command to create a portfolio with an already saved strategy. The strategy
 * contains the list of stocks along with their corresponding weightage, start date, end date,
 * interval at which the stocks has to be regularly bought.
 */
public class CreatePortfolioWithStrategy implements StockCommands {

  private String portfolio_name;
  private String strategy_name;

  /**
   * A public constructor to initialize the class variables.
   *
   * @param pfName Represents the portfolio name.
   * @param sName  Represents the strategy name.
   */
  public CreatePortfolioWithStrategy(String pfName, String sName) {
    this.portfolio_name = pfName;
    this.strategy_name = sName;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the success message as an output string if model perfectly executes the command.
   *
   * @param m model of the stock implementation.
   * @return Returns the output passed by the model as a string.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    m.retrieveStrategy(strategy_name,portfolio_name);
    return "Portfolio has been created successfully with the retrieved strategy \n";
  }
}

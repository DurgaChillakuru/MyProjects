package stockcontroller;

import stockmodel.PortfolioWrapper;
import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. It has a method "go" that is used to invoke
 * the model's viewFullPortfolio method to retrieve the full information about the portfolio, like
 * how many stocks are there, what is their today's price and also at what price and date they have
 * been bought.
 */
public class ViewFullPortfolio implements StockCommands {

  private String portfolioName;

  /**
   * A public constructor to initialise the class variables(portfolio name).
   *
   * @param portfolioName refers to the name of the portfolio that has to be viewed with detailed
   *                      information.
   */
  public ViewFullPortfolio(String portfolioName) {
    this.portfolioName = portfolioName;

  }

  /**
   * A method that overrides the go method in the stockCommand interface that takes in a model as an
   * argument. This method contains a method call to the viewFullPortfolio method of the
   * model(StockExchange).
   *
   * @param m refers to the model object that contains the base implementation of the
   *          viewFullPortfolio method.
   * @return the full information about the portfolio, displaying all the stocks in the portfolio
   *         along with the information when they have been bought and at what price.
   */
  @Override
  public String command(StockExchange m) {
    String result;
    StringBuilder sb = new StringBuilder();
    PortfolioWrapper wrapper = m.viewFullPortfolio(this.portfolioName);
    result = wrapper.toString();
    String[] values = result.split(", ");
    if (values.length > 1) {
      for (int i = 0; i < values.length; i = i + 4) {
        sb.append(values[i + 1] + " Stock of " + values[i] + " was purchased on " + values[i + 2] +
                " with per share value of $" + values[i + 3] + "\n");
      }
    } else {
      sb.append("There is no stock in portfolio");
    }
    return sb.toString();
  }
}

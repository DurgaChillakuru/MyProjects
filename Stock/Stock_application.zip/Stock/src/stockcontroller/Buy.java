package stockcontroller;


import java.time.DateTimeException;
import java.time.LocalDate;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. It has a method "command" to pass the input
 * parameters to the model that will be used to buy a particular stock and add it to a particular
 * portfolio at a particular date.
 */
public class Buy implements StockCommands {

  private String stockName;
  private String portfolioName;
  private int quantity;
  private int dd;
  private int mm;
  private int yyyy;

  /**
   * A public constructor to initialise the class variables (input parameters) that has to be passed
   * to the model.
   *
   * @param portfolioName refers to the portfolio to which the stock bought has to be added.
   * @param stockName     refers to the stock(ticker symbol) that has to be bought.
   * @param quantity      refers to the quantity of stock that has to be bought.
   * @param dd            represents the date(dd) at which the stock has to be bought.
   * @param mm            represents the month(mm) of the date at which the stock has to be bought.
   * @param yyyy          represents the year(yyyy) at which the stock has to be bought.
   */
  public Buy(String portfolioName, String stockName, int quantity, int dd, int mm, int yyyy) {
    this.portfolioName = portfolioName;
    this.stockName = stockName;
    this.quantity = quantity;
    this.dd = dd;
    this.mm = mm;
    this.yyyy = yyyy;
  }

  /**
   * A method that overrides the command method in the stockCommand interface that takes in a model
   * as an argument. This method contains a method call to the buy method of the
   * model(StockExchange). This method parses the input date, month and year values to a LocalDate
   * object while passing to the model. If the date is of invalid format, then this method returns
   * the exception thrown by the model to the controller.
   *
   * @param m refers to the model object that contains the base implementation of the buy method.
   * @return Returns the String saying "Shares has been bought successfully" if the buy method has
   *         been successfully executed in the model.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    try {
      LocalDate date = LocalDate.of(yyyy, mm, dd);
      m.buy(this.portfolioName, this.stockName, this.quantity, date);
    } catch (DateTimeException e) {
      return e.getMessage();
    }
    return "Shares has been bought successfully";
  }
}




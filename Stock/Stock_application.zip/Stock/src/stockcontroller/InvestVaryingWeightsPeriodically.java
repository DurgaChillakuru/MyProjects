package stockcontroller;

import java.time.LocalDate;
import java.util.Map;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * This is the controller for Invest Varying weights. This takes input from cli and pass it to
 * model.
 */
public class InvestVaryingWeightsPeriodically implements StockCommands {

  private String portfolio_name;
  private LocalDate startDate;
  private LocalDate endDate;
  private int interval;
  private double amount;
  private double commissionAmt;
  private Map<String, Double> mapOfStocks;

  /**
   * This is the constructor for Invest varying weights.
   *
   * @param pfName   is the portfolio name.
   * @param sDate    is the start date.
   * @param eDate    is the end date.
   * @param interval is the interval.
   * @param amt      is the total amount.
   * @param cAmt     is the commission amount.
   * @param sStocks  is the map of stock.
   */
  public InvestVaryingWeightsPeriodically(String pfName, LocalDate sDate, LocalDate eDate,
                                          int interval,
                                          double amt, double cAmt, Map<String, Double> sStocks) {
    this.portfolio_name = pfName;
    this.startDate = sDate;
    this.endDate = eDate;
    this.interval = interval;
    this.amount = amt;
    this.commissionAmt = cAmt;
    this.mapOfStocks = sStocks;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the output passed by the model as a string.
   *
   * @param m model of the stock implementation.
   * @return Returns the output passed by the model as a string.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    m.investFixedAmountVaryingWeightPeriodically(startDate, endDate, amount, portfolio_name,
            commissionAmt, interval, mapOfStocks);
    return "Amount has been invested in the stocks with mentioned varying weightage at specified" +
            "frequency successfully \n";
  }
}

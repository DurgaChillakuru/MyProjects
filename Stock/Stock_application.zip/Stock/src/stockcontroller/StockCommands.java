package stockcontroller;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * An interface that is used to represents a high level command: a set of operations that must be
 * executed.This is an example of the command design pattern. This pattern unifies different sets of
 * operations under one umbrella, so that they can be treated uniformly.
 */
public interface StockCommands {

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the output passed by the model as a string.
   *
   * @param m model of the stock implementation.
   * @return Returns the output passed by the model as a string.
   */
  String command(StockExchange<Stock> m);
}

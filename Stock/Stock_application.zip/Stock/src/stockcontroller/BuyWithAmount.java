package stockcontroller;

import java.time.DateTimeException;
import java.time.LocalDate;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. It has a method "command" to pass the input
 * parameters to the model that will be used to buy a particular stock with money and add it to a
 * particular portfolio at a particular date.
 */
public class BuyWithAmount implements StockCommands {

  private String pfName;
  private String stockSym;
  private double amount;
  private int dd;
  private int mm;
  private int yyyy;

  /**
   * A public constructor to intialise the class variables.
   *
   * @param pfName   Represents the portfolio name to which the stock has to be added.
   * @param stockSym refers to the stock(ticker symbol) that has to be bought.
   * @param dd       represents the date(dd) at which the stock has to be bought.
   * @param mm       represents the month(mm) of the date at which the stock has to be bought.
   * @param yyyy     represents the year(yyyy) of the date at which the stock has to be bought.
   * @param amount   represents the money for which the stocks has to be bought.
   */
  public BuyWithAmount(String pfName, String stockSym, int dd, int mm, int yyyy, double amount) {
    this.pfName = pfName;
    this.stockSym = stockSym;
    this.dd = dd;
    this.mm = mm;
    this.yyyy = yyyy;
    this.amount = amount;
  }

  /**
   * A method that overrides the command method in the stockCommand interface that takes in a model
   * as an argument. This method contains a method call to the buyStockWithMoney method of the
   * model. This method parses the input date, month and year values to a LocalDate object while
   * passing to the model. If the date is of invalid format, then this method returns the exception
   * thrown by the model to the controller.
   *
   * @param m model of the stock implementation.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    double remainingAmt;
    try {
      LocalDate date = LocalDate.of(yyyy, mm, dd);
      remainingAmt = m.buyStockWithMoney(this.pfName, this.stockSym, date, this.amount);
    } catch (DateTimeException e) {
      return e.getMessage();
    }
    return "Stocks has been bought successfully and the remaining amount " + remainingAmt +
            " transferred back";
  }
}

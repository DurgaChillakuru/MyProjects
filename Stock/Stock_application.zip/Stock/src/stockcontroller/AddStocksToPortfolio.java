package stockcontroller;

import java.util.List;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * A class that implements the StockCommands. This class represents the command to add stocks to a
 * portfolio that has been already created. It just adds stocks to the portfolio, doesn't buy. This
 * class contains a method "command" that is used to pass parameters to the model for adding stocks
 * to a portfolio.
 */
public class AddStocksToPortfolio implements StockCommands {

  private String pf_name;
  private List<String> listOfStocks;

  /**
   * A public constructor to initialise the class variables.
   *
   * @param portfolioName Represents the name of the portfolio to which the stocks have to be
   *                      added.
   * @param listOfStocks  Represents the list of stocks to be added to a particular portfolio.
   */
  public AddStocksToPortfolio(String portfolioName, List listOfStocks) {
    this.pf_name = portfolioName;
    this.listOfStocks = listOfStocks;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the output passed by the model as a string.
   *
   * @param m model of the stock implementation.
   * @return Returns the success message as a string, if the stocks has been added successfully.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    m.addStockToPortfolio(pf_name, listOfStocks);
    return "Successfully added stocks to the portfolio \n";
  }
}

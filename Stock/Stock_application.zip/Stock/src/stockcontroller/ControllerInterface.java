package stockcontroller;

import java.util.InputMismatchException;

import stockmodel.StockExchange;
import view.StockView;

/**
 * This is the stock controller Interface which has command method which controls the Model.
 */
public interface ControllerInterface {

  /**
   * This method is responsible for getting the inputs from the view and passing those to the model
   * class, and also getting outputs from the model class and passing it to view to display. This
   * method provides a menu of commands that the user wishes to execute like viewing a portfolio,
   * buying stocks etc. Based on the user's input the corresponding command will be executed. If
   * there is an input mismatch, then InputMismatch Exception is being thrown.
   *
   * @param model the model of the Stock exchange implementation.
   * @param view  the view object of the Model.
   * @throws InputMismatchException if there is any mismatch in the inputs.
   */
  void command(StockExchange model, StockView view) throws InputMismatchException;
}

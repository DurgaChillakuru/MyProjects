package stockcontroller;

import stockmodel.PortfolioWrapper;
import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. It has a method "go" that is used to invoke
 * the model's viewPortfolio method to retrieve a high level information about the portfolio, like
 * how many stocks are there, what is their today's price.
 */
public class ViewPortfolio implements StockCommands {

  private String portfolioName;

  /**
   * A public constructor to initialise the class variables(portfolio name).
   *
   * @param portfolioName refers to the name of the portfolio that has to be viewed, not displaying
   *                      the information to an extend about the purchase dates of stocks.
   */
  public ViewPortfolio(String portfolioName) {
    this.portfolioName = portfolioName;
  }

  /**
   * A method that overrides the go method in the stockCommand interface that takes in a model as an
   * argument. This method contains a method call to the viewPortfolio method of the
   * model(StockExchange).
   *
   * @param m refers to the model object that contains the base implementation of the viewPortfolio
   *          method.
   * @return Returns the information about the portfolio, displaying all the stocks in the portfolio
   *         and their prices, but excluding about the purchase dates of stocks.
   */
  @Override
  public String command(StockExchange m) {
    String result;
    StringBuilder sb = new StringBuilder();
    PortfolioWrapper wrapper = m.viewPortfolio(this.portfolioName);
    result = wrapper.toString();
    String[] values = result.split(", ");
    if (values.length > 1) {
      for (int i = 0; i < values.length; i = i + 3) {
        sb.append("The Total number of Stock: " + values[i] + " is " + values[i + 1] +
                " and invested " +
                "amount is $" + values[i + 2] + "\n");
      }
    } else {
      sb.append("No stock in portfolio");
    }
    return sb.toString();
  }
}

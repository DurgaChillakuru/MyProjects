package stockcontroller;


import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. It has a method "go" to pass the input
 * parameters to the model that will be used to create a portfolio.
 */
public class CreatePortfolio implements StockCommands {

  private String portfolioName;

  /**
   * A public constructor to initialise the class variables(portfolio name).
   *
   * @param portfolioName refers to the name of the portfolio that has to be created.
   */
  public CreatePortfolio(String portfolioName) {
    this.portfolioName = portfolioName;
  }

  /**
   * A method that overrides the go method in the stockCommand interface that takes in a model as an
   * argument. This method contains a method call to the createPortfolio method of the
   * model(StockExchange).
   *
   * @param m refers to the model object that contains the base implementation of the create
   *          method.
   * @return gives the String saying "Portfolio created successfully" if the create portfolio
   *         method has been successfully executed in the model.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    m.createPortfolio(this.portfolioName);
    return "Portfolio created successfully";
  }
}




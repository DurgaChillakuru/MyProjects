package stockcontroller;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.Map;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * This class is used to represent the command to invest a fixed amount in a portfolio with varying
 * weight to all the stocks in that portoflio. This class implements the StocksCommands interface.
 * Overrides the method command to pass the necessary parameters to the model for execution of the
 * command.
 */
public class InvestVaryingWeights implements StockCommands {

  private String portfolio_name;
  private double investAmt;
  private Map<String, Double> mapOfWeights;
  private int dd;
  private int mm;
  private int yyyy;
  private double commissionAmt;

  /**
   * A public constructor to initialize the class variables.
   *
   * @param pfName  Represents the portfolio name to which the amount will be invested.
   * @param amt     Represents the amount to be invested in the portfolio.
   * @param weights Represents the ratio's(weightages) of each stock in the portfolio.
   * @param dd      Represents the date of the month at which the amount has to be invested.
   * @param mm      Represents the date of the month at which the amount has to be invested.
   * @param yyyy    Represents the date of the month at which the amount has to be invested.
   * @param commAmt Represents the commission amount if the user says yes. Otherwise it is 0
   */
  public InvestVaryingWeights(String pfName, double amt, Map weights, int dd, int mm,
                              int yyyy, double commAmt) {
    this.portfolio_name = pfName;
    this.investAmt = amt;
    this.mapOfWeights = weights;
    this.dd = dd;
    this.mm = mm;
    this.yyyy = yyyy;
    this.commissionAmt = commAmt;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the success message as an output to the controller to display to the user.
   *
   * @param m model of the stock implementation.
   * @return gives the success message along with remaining amount, in case if any.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    double remAmt;
    try {
      LocalDate date = LocalDate.of(yyyy, mm, dd);
      remAmt = m.investFixedAmountVaryingWeight(date, investAmt, portfolio_name,
              commissionAmt, mapOfWeights);
    } catch (DateTimeException e) {
      return e.getMessage();
    }
    return "Successfully, the amount has been invested in the portfolio with varying weightage " +
            "on all stocks and the remaninig amount " + remAmt + " has been transferred back !!\n";
  }
}

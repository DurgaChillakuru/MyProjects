package stockcontroller;

import java.util.List;

import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. This class is responsible for invoking the
 * model to perform the command to list all operations.
 */
public class ListPortfolio implements StockCommands {

  /**
   * A method that overrides the go method in the stockCommand interface that takes in a model as an
   * argument. This method contains a method call to the listPortfolio method of the
   * model(StockExchange) which generates the list of portfolio's and returns it as a string.
   *
   * @param m refers to the model object that contains the base implementation of the listPortfolio
   *          method.
   * @return Returns the list of portfolios that has been created thus far as a string.
   */
  @Override
  public String command(StockExchange m) {
    List<String> temp = m.listPortfolio();
    String output = "";
    for (String list : temp) {
      output = output + list + "\n";
    }
    return output;
  }
}

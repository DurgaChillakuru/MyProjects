package stockcontroller;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;

import stockmodel.StockExchange;
import view.StockView;

/**
 * This is the controller class for stock implementation. This provides controller functionalities
 * for handling stocks like buying shares, creating a portfolio etc. It takes the input from the
 * view and passes it to the model, and then gets the output from the model and gives it to view to
 * display. This class delegates the tasks between the model and view. This class also receives
 * exceptions thrown by the model and sends to view to display.
 */
public class Controller implements ControllerInterface {

  /**
   * This method is responsible for getting the inputs from the view and passing those to the model
   * class, and also getting outputs from the model class and passing it to view to display. This
   * method provides a menu of commands that the user wishes to execute like viewing a portfolio,
   * buying stocks etc. Based on the user's input the corresponding command will be executed. If
   * there is an input mismatch, then InputMismatchExcetion is being thrown.
   *
   * @param model the model of the Stock exchange implementation.
   * @throws InputMismatchException if there is any mismatch in the inputs.
   */
  @Override
  public void command(StockExchange model, StockView view) throws InputMismatchException {
    String menu = "---------------MENU------------\n" +
            "Press 1 for Creating a portfolio\n" +
            "Press 2 to buy stocks\n" +
            "Press 3 to view portfolio\n" +
            "Press 4 to view full portfolio\n" +
            "Press 5 to list portfolios\n" +
            "Press 6 to get the total cost basis of a portfolio\n" +
            "Press 7 to get the total value of a portfolio\n" +
            "Press 8 to buy Stocks with money\n" +
            "Press 9 to Save the portfolio\n" +
            "Press 10 to Retrieve the portfolio\n" +
            "Press 11 to Add stocks to existing portfolio\n" +
            "Press 12 to Invest in a portfolio with varying weights\n" +
            "Press 13 to Invest in a portfolio with equal weights\n" +
            "Press 14 to Create and save a Strategy\n" +
            "Press 15 to Retrieve a strategy\n" +
            "Press 16 to Invest in a portfolio with varying weights periodically\n" +
            "Press q/Q to exit";
    String stock_name;
    String portfolio_name;
    String strategy_name;
    Map<String, Double> stockWeights;
    int dd;
    int mm;
    int yyyy;
    int quantity;
    double commissionAmt;
    StockCommands cmd = null;
    while (true) {
      view.displayOutput(menu);
      view.displayOutput("Please enter the command:\n");
      String in = view.getUserInput();
      try {
        switch (in) {
          case "1":
            portfolio_name = getPortfolioName(view);
            cmd = new CreatePortfolio(portfolio_name);
            break;
          case "2":
            stock_name = getStockName(view);
            portfolio_name = getPortfolioName(view);
            quantity = getQuantity(view);
            dd = getDay(view);
            mm = getMonth(view);
            yyyy = getYear(view);
            cmd = new Buy(stock_name, portfolio_name, quantity, dd, mm, yyyy);
            break;
          case "3":
            view.displayOutput("Enter the portfolio name to view:\n");
            cmd = new ViewPortfolio(view.getUserInput());
            break;
          case "4":
            view.displayOutput("Enter the portfolio name to view with detailed info:\n");
            cmd = new ViewFullPortfolio(view.getUserInput());
            break;
          case "5":
            cmd = new ListPortfolio();
            break;
          case "6":
            portfolio_name = getPortfolioName(view);
            dd = getDay(view);
            mm = getMonth(view);
            yyyy = getYear(view);
            cmd = new PortfolioCostBasis(portfolio_name, dd, mm, yyyy);
            break;
          case "7":
            portfolio_name = getPortfolioName(view);
            dd = getDay(view);
            mm = getMonth(view);
            yyyy = getYear(view);
            cmd = new PortfolioValue(portfolio_name, dd, mm, yyyy);
            break;
          case "8":
            stock_name = getStockName(view);
            portfolio_name = getPortfolioName(view);
            double amount = calculateAmount(view);
            dd = getDay(view);
            mm = getMonth(view);
            yyyy = getYear(view);
            cmd = new BuyWithAmount(portfolio_name, stock_name, dd, mm, yyyy, amount);
            break;
          case "9":
            portfolio_name = getPortfolioName(view);
            cmd = new SavePortfolio(portfolio_name);
            break;
          case "10":
            portfolio_name = getPortfolioName(view);
            cmd = new RetrievePortfolio(portfolio_name);
            break;
          case "11":
            portfolio_name = getPortfolioName(view);
            List<String> listOfStocks = getStocks(view);
            cmd = new AddStocksToPortfolio(portfolio_name, listOfStocks);
            break;
          case "12":
            portfolio_name = getPortfolioName(view);
            amount = investAmount(view);
            commissionAmt = commissionAmount(view);
            dd = getDay(view);
            mm = getMonth(view);
            yyyy = getYear(view);
            stockWeights = getWeights(portfolio_name, view, model);
            cmd = new InvestVaryingWeights(portfolio_name, amount, stockWeights,
                    dd, mm, yyyy, commissionAmt);
            break;
          case "13":
            portfolio_name = getPortfolioName(view);
            amount = investAmount(view);
            commissionAmt = commissionAmount(view);
            dd = getDay(view);
            mm = getMonth(view);
            yyyy = getYear(view);
            cmd = new InvestEqualWeights(portfolio_name, amount, commissionAmt, dd, mm, yyyy);
            break;
          case "14":
            strategy_name = getStrategyName(view);
            int interval = getInterval(view);
            amount = investAmount(view);
            commissionAmt = commissionAmount(view);
            stockWeights = getListOfStocksToBeInStrategy(view);
            LocalDate startDate = getStartDate(view);
            LocalDate endDate = getEndDate(view);
            cmd = new CreateStrategy(strategy_name, startDate, endDate, interval, amount,
                    commissionAmt, stockWeights);
            break;
          case "15":
            portfolio_name = getPortfolioName(view);
            strategy_name = getStrategyName(view);
            cmd = new CreatePortfolioWithStrategy(portfolio_name, strategy_name);
            break;
          case "16":
            portfolio_name = getPortfolioName(view);
            interval = getInterval(view);
            amount = investAmount(view);
            commissionAmt = commissionAmount(view);
            startDate = getStartDate(view);
            endDate = getEndDate(view);
            stockWeights = getListOfStocksToBeInStrategy(view);
            cmd = new InvestPeriodically(portfolio_name, startDate, endDate, interval,
                    amount, commissionAmt, stockWeights);
            break;
          case "q":
          case "Q":
            return;
          default:
            view.displayOutput(String.format("Unknown command %s\n", in));
            cmd = null;
            break;
        }
      } catch (InputMismatchException | IllegalArgumentException | DateTimeException ie) {
        view.displayOutput("Invalid Input. Please check the input and try again!\n");
      }
      if (cmd != null) {
        try {
          String output = cmd.command(model);
          cmd = null;
          view.displayOutput(output);
        } catch (IllegalArgumentException | InputMismatchException e) {
          view.displayOutput(e.getMessage());
        }
      }
    }
  }

  /**
   * A private helper method to return the integer value of the string representation of date.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the integer value of the date.
   */
  private int getInt(StockView view) {
    return Integer.parseInt(view.getUserInput());
  }

  /**
   * A private helper method to get the day of the date at which the stocks has to be bought.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input.
   */
  private int getDay(StockView view) {
    view.displayOutput("Enter the date(dd) of the month at which the stock has to " +
            "be bought:\n");
    return getInt(view);
  }

  /**
   * A private helper method to get the month of the date at which the stocks has to be bought.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input.
   */
  private int getMonth(StockView view) {
    view.displayOutput("Enter the month(mm) of the date at which the stock has " +
            "to be bought:\n");
    return getInt(view);
  }

  /**
   * A private helper method to get the year of the date at which the stocks has to be bought.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input.
   */
  private int getYear(StockView view) {
    view.displayOutput("Enter the year(yyyy) of the date at which the stock has " +
            "to be bought:\n");
    return getInt(view);
  }

  /**
   * A private helper to get the portfolio name.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input.
   */
  private String getPortfolioName(StockView view) {
    view.displayOutput("Enter the portfolio name :\n");
    return view.getUserInput();
  }

  /**
   * A private helper to get the stock name.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input.
   */
  private String getStockName(StockView view) {
    view.displayOutput("Enter the ticker symbol:\n");
    return view.getUserInput();
  }

  /**
   * A private helper to get the quantity of the stocks to be bought.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input.
   */
  private int getQuantity(StockView view) {
    view.displayOutput("Enter the quantity: \n");
    return getInt(view);
  }

  /**
   * A private helper method to calculate the buying amount inclusive of commission amount if user
   * wants. The maximum commission amount(charge per transaction) is assumed to be 9$ per
   * transaction.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input.
   * @throws IllegalArgumentException if commission amount is less than 0 or greater than 10.
   */
  private double calculateAmount(StockView view) throws IllegalArgumentException {
    view.displayOutput("Enter the amount in dollars: \n");
    double amount = Double.parseDouble(view.getUserInput());
    view.displayOutput("Press y/Y to buy with commission or any other key apart from y/Y " +
            "to exclude commission:\n");
    String temp = view.getUserInput();
    if (temp.equalsIgnoreCase("yes") || temp.startsWith("y")) {
      view.displayOutput("Enter the commission amount in dollars less than 10 dollars: \n");
      double commAmt = Double.parseDouble(view.getUserInput());
      if (commAmt >= 10 || commAmt < 0) {
        throw new IllegalArgumentException("Invalid commission amount. Please try again!");
      }
      return amount - commAmt;
    } else {
      return amount;
    }
  }

  /**
   * A private helper method to return the map of stocks along with the weights/ ratios associated
   * with it in an existing portfolio.
   *
   * @param portfolioName Represents the portfolio name.
   * @param view          object that is used to get the inputs from the user(only weights).
   * @param model         Model object is used to query the stocks in an existing portfolio.
   * @return Returns the user's input.
   */
  private Map<String, Double> getWeights(String portfolioName, StockView view,
                                         StockExchange model) {
    Map<String, Double> stockWeights = new HashMap<>();
    List<String> listOfStocks = model.getStockInPortfolio(portfolioName);
    double sum = 0.0;
    view.displayOutput("The list of stocks in the portfolio are: ");
    view.displayOutput(listOfStocks.toString());
    for (String stockName : listOfStocks) {
      view.displayOutput("Enter the ratio for " + stockName + "(Format: 40 for 40%, 25 " +
              "for 25%): \n");
      double ratio = Double.valueOf(view.getUserInput());
      stockWeights.put(stockName, ratio / 100);
    }
    for (double wt : stockWeights.values()) {
      sum += wt;
    }
    if (sum <= 0.996) {
      throw new IllegalArgumentException("Sum of ratio's should be 100. Please check the weights!");
    }
    return stockWeights;
  }

  /**
   * A private helper method to get the list of stocks to be in the strategy from the user.
   *
   * @param view object that is used to get the inputs from the user.
   * @return returns the user's input as a List of strings.
   */
  private List<String> getStocks(StockView view) {
    List<String> listOfStocks = new ArrayList<>();
    String out = "";
    do {
      view.displayOutput("Enter the Stock to be added: \n");
      listOfStocks.add(view.getUserInput());
      view.displayOutput("Press Y/y to add another stock or any other key apart from Y/y: \n");
      out = view.getUserInput();
    }
    while (out.equalsIgnoreCase("yes") || out.startsWith("y"));
    return listOfStocks;
  }

  /**
   * A private helper method to get the invest amount from the user.
   *
   * @param view object that is used to get the inputs from the user.
   * @return returns the user's input as a double.
   * @throws IllegalArgumentException if the invest amount is negative.
   */
  private double investAmount(StockView view) {
    view.displayOutput("Enter the amount in dollars to be invested: \n");
    String temp = view.getUserInput();
    if (Double.parseDouble(temp) <= 0) {
      throw new IllegalArgumentException("Invalid Input, Amount can't be negative!!");
    }
    return Double.parseDouble(temp);
  }

  /**
   * A private helper method to get the commission amount from the user.
   *
   * @param view object that is used to get the inputs from the user.
   * @return returns the user's input as a double.
   * @throws IllegalArgumentException if the commission amount is negative or greater than 9.
   */
  private double commissionAmount(StockView view) {
    double commAmt = 0.0;
    view.displayOutput("Press y/Y to buy with commission or any other key apart from y/Y " +
            "to exclude commission:\n");
    String temp = view.getUserInput();
    if (temp.equalsIgnoreCase("Y")) {
      view.displayOutput("Enter the commission amount in dollars less than 10 dollars: \n");
      commAmt = Double.parseDouble(view.getUserInput());
      if (commAmt >= 10 || commAmt < 0) {
        throw new IllegalArgumentException("Invalid commission amount. Please try again!");
      }
    }
    return commAmt;
  }

  /**
   * A private helper method to get the strategy name from the user.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input as a string.
   */
  private String getStrategyName(StockView view) {
    view.displayOutput("Enter the strategy name: \n");
    return view.getUserInput();
  }

  /**
   * A private helper method to get the inputs from the user on the frequency at which the stocks
   * have to be bought.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input as an integer.
   */
  private int getInterval(StockView view) {
    view.displayOutput("Enter the frequency at which the stocks has to be bought: \n");
    String temp = view.getUserInput();
    if (Integer.valueOf(temp) <= 0) {
      throw new IllegalArgumentException("Invalid Input !!");
    }
    return Integer.parseInt(temp);
  }

  /**
   * A private helper method to return the map of stocks along with the weights/ ratios associated
   * with it.
   *
   * @param view object that is used to get the inputs from the user(Stocks and weights).
   * @return Returns the user's input.
   */
  private Map<String, Double> getListOfStocksToBeInStrategy(StockView view) {
    Map<String, Double> strategyStocks = new HashMap<>();
    String cont;
    String ss_name;
    double weight;
    double sum = 0.0;
    view.displayOutput("Press Y/y to split equally or any other key if " +
            "you don't want to split equally \n");
    String temp = view.getUserInput();
    if (temp.equalsIgnoreCase("y")) {
      view.displayOutput("How many stocks to be added in this strategy \n");
      int numOfStocks = getInt(view);
      weight = (100.0 / numOfStocks) / 100;
      int i = 0;
      while (i < numOfStocks) {
        view.displayOutput("Enter the stock to be added in strategy: \n");
        ss_name = view.getUserInput();
        strategyStocks.put(ss_name, weight);
        i++;
      }
      for (double val : strategyStocks.values()) {
        sum += val;
      }
    } else {
      do {
        sum = 0.0;
        view.displayOutput("Enter the stock to be added in strategy: \n");
        ss_name = view.getUserInput();
        view.displayOutput("Enter the weight of the stock to be added: \n");
        weight = Double.parseDouble(view.getUserInput());
        if (weight <= 0) {
          throw new IllegalArgumentException("Invalid Input");
        }
        strategyStocks.put(ss_name, weight / 100);
        for (double val : strategyStocks.values()) {
          sum += val;
        }
        if (sum >= 1.0) {
          break;
        }
        view.displayOutput("Press Y/y to add one more stock or any other key to add " +
                "no more stocks:\n");
        cont = view.getUserInput();
      }
      while (cont.equalsIgnoreCase("Y"));
    }
    if (sum <= 0.996) {
      throw new IllegalArgumentException("Sum of weights should be 100. Please check " +
              "the input! \n");
    }
    return strategyStocks;
  }

  /**
   * A private helper method to get the start date of a strategy. The date at which the user wises
   * to initiate the strategy.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input in the form of a date.
   */
  private LocalDate getStartDate(StockView view) {
    LocalDate startDate;
    view.displayOutput("Enter the day(dd) of the month at which the strategy " +
            "has to be initiated: \n");
    int s_dd = getInt(view);
    view.displayOutput("Enter the month(mm) at which the strategy " +
            "has to be initiated: \n");
    int s_mm = getInt(view);
    view.displayOutput("Enter the year(yyyy) at which the strategy " +
            "has to be initiated: \n");
    int s_yyyy = getInt(view);
    startDate = LocalDate.of(s_yyyy, s_mm, s_dd);
    return startDate;
  }

  /**
   * A private helper method to get the end date of a strategy. The date at which the user wises to
   * end the strategy.
   *
   * @param view object that is used to get the inputs from the user.
   * @return Returns the user's input in the form of a date.
   */
  private LocalDate getEndDate(StockView view) {
    LocalDate endDate;
    view.displayOutput("Press Y/y if you want to enter the end date for this strategy: \n");
    String temp = view.getUserInput();
    if (temp.equalsIgnoreCase("Y")) {
      view.displayOutput("Enter the day(dd) of the month at which the strategy " +
              "has to be ended: \n");
      int s_dd = getInt(view);
      view.displayOutput("Enter the month(mm) at which the strategy " +
              "has to be ended: \n");
      int s_mm = getInt(view);
      view.displayOutput("Enter the year(yyyy) at which the strategy " +
              "has to be ended: \n");
      int s_yyyy = getInt(view);
      endDate = LocalDate.of(s_yyyy, s_mm, s_dd);
      return endDate;
    } else {
      return LocalDate.now();
    }
  }
}

package stockcontroller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

/**
 * This is a button listener class for the GUI model.
 */
public class ButtonListener implements ActionListener {
  Map<String, Runnable> buttonAction;

  @Override
  public void actionPerformed(ActionEvent e) {
    if (buttonAction.containsKey(e.getActionCommand())) {
      buttonAction.get(e.getActionCommand()).run();
    }
  }

  /**
   * This method set the map which contain command action.
   *
   * @param action The list of command action for the GUI model.
   */
  public void setButtonAction(Map action) {
    this.buttonAction = action;
  }
}

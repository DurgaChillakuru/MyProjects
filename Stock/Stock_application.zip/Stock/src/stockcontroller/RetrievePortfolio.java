package stockcontroller;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. It has a method "command" to pass the input
 * parameters to the model that will be used to retrieve a particular portfolio to a file at a
 * particular location.
 */
public class RetrievePortfolio implements StockCommands {

  private String portfolioName;

  /**
   * A public constructor to initialise the class variables.
   *
   * @param portfolioName represents the name of the portfolio to be retrieved.
   */
  public RetrievePortfolio(String portfolioName) {
    this.portfolioName = portfolioName;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the output passed by the model as a string.
   *
   * @param m model of the stock implementation.
   * @return Returns the output passed by the model as a string.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    try {
      m.retrieve(portfolioName);
    } catch (IllegalArgumentException e) {
      return e.getMessage();
    }
    return "Portfolio has been retrieved successfully";
  }
}

package stockcontroller;

import java.time.LocalDate;
import java.util.Map;

import stockmodel.Stock;
import stockmodel.StockExchange;


/**
 * A class that implements the Stock commands interface. This class represents a command to invest a
 * fixed amount on a portfolio periodically. The user can wish to buy the stocks on a time frame
 * basis, neglecting the stock market fluctuations. Overrides the method command to pass the
 * necessary parameters to the model for execution of the command.
 */
public class InvestPeriodically implements StockCommands {

  private String portfolio_name;
  private LocalDate startDate;
  private LocalDate endDate;
  private int interval;
  private double amount;
  private double commissionAmt;
  private Map<String, Double> mapOfStocks;

  /**
   * A public constructor to initialise the class varaibles.
   *
   * @param pfName   Represents the portfolio name to which the amount will be invested.
   * @param sDate    Represents the start date at when the amount has to be invested.
   * @param eDate    Represents the end date at when the amount should no longer be invested.
   * @param interval Represents the frequenct at which the amount has to be invested.
   * @param amt      Represents the amount that has to be invested.
   * @param cAmt     Represents the commission amount if user says yes, otherwise 0.
   * @param sStocks  Represents the list of stocks.
   */
  public InvestPeriodically(String pfName, LocalDate sDate, LocalDate eDate, int interval,
                            double amt, double cAmt, Map<String, Double> sStocks) {
    this.portfolio_name = pfName;
    this.startDate = sDate;
    this.endDate = eDate;
    this.interval = interval;
    this.amount = amt;
    this.commissionAmt = cAmt;
    this.mapOfStocks = sStocks;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the output passed by the model as a string.
   *
   * @param m model of the stock implementation.
   * @return Returns the output passed by the model as a string.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    double remAmt;
    remAmt = m.investFixedAmountVaryingWeightPeriodically(startDate, endDate, amount,
            portfolio_name, commissionAmt, interval, mapOfStocks);
    return "Amount has been invested in the stocks with mentioned varying weightage at specified" +
            "frequency successfully and " + remAmt + " has been transferred back!!\n";
  }
}

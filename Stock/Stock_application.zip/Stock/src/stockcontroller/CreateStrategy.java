package stockcontroller;

import java.time.LocalDate;
import java.util.Map;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * A class to represent a command to create a strategy. A strategy will represent a strategy name,
 * start date , end date, the frequency at which the stocks has to be bought, list of stocks along
 * with their ratios. Strategy is usually refers to a schema or plan.
 */
public class CreateStrategy implements StockCommands {

  private String strategy_name;
  private LocalDate startDate;
  private LocalDate endDate;
  private int interval;
  private double amount;
  private double commissionAmt;
  private Map<String, Double> mapOfStocksInStrategy;


  /**
   * A public constructor to initialise the class variables.
   *
   * @param sName   Represents the name of the strategy.
   * @param sDate   Represents the start date at which the strategy has to be initiated.
   * @param eDate   Represents the end date at which the strategy has to be ended. The user is
   *                 provided with an option to not mention end date. In that case, today's date
   *                 will be taken as end date.
   * @param interval Represents the frequency at which the stocks has to be bought.
   * @param amt      Represents the amount to be invested.
   * @param cAmt    Represents the commission amout, in case if user provides or else it would be
   *                 0.0.
   * @param sStocks Represents the list of stocks that has to be added in the strategy.
   */
  public CreateStrategy(String sName, LocalDate sDate, LocalDate eDate, int interval,
                        double amt, double cAmt, Map<String, Double> sStocks) {
    this.strategy_name = sName;
    this.startDate = sDate;
    this.endDate = eDate;
    this.interval = interval;
    this.amount = amt;
    this.commissionAmt = cAmt;
    this.mapOfStocksInStrategy = sStocks;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the success message as an output to the user.
   *
   * @param m model of the stock implementation.
   * @return Returns the success message as an output, if model is able to execute the command.
   */
  @Override
  public String command(StockExchange<Stock> m) {
    try {
      m.saveStrategy(strategy_name, startDate, endDate, interval, amount,
              mapOfStocksInStrategy, commissionAmt);
    } catch (IllegalArgumentException e) {
      return e.getMessage();
    }
    return "Strategy has been saved successfully \n";
  }
}

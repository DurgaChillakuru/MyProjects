package stockcontroller;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;

import stockmodel.PortfolioWrapper;
import stockmodel.StockExchange;
import view.StockGUIView;


/**
 * This is the GUI controller. This class is responsible for controlling the operation between model
 * and view. This class implements the action listener for the button pressed and redirects page
 * accordingly.
 */
public class GuiController implements GuiControllerInterface {
  private StockExchange model;

  @Override
  public void start(StockExchange model, StockGUIView view) throws InputMismatchException {
    StockGUIView view1 = view;
    this.model = model;
    view1.setController(this);
    view1.setVisible();
  }

  @Override
  public PortfolioWrapper viewPortfolio(String portfolio) {
    return model.viewPortfolio(portfolio);
  }

  @Override
  public PortfolioWrapper viewFullPortfolio(String portfolio) {
    return model.viewFullPortfolio(portfolio);
  }

  @Override
  public void buy(String stockName, String portfolioName,
                  int volume, LocalDate date) throws IllegalArgumentException {
    model.buy(stockName, portfolioName, volume, date);

  }

  @Override
  public double getTotalPortfolioCostBasis(String portfolio, LocalDate date) {
    return model.getTotalPortfolioCostBasis(portfolio, date);
  }

  @Override
  public double getTotalPortfolioValue(String portfolio, LocalDate date) {
    return model.getTotalPortfolioValue(portfolio, date);
  }

  @Override
  public void createPortfolio(String portfolio) throws IllegalArgumentException {
    model.createPortfolio(portfolio);
  }

  @Override
  public List listPortfolio() {
    return model.listPortfolio();
  }

  @Override
  public double buyStockWithMoney(String portfolioName, String tickerId, LocalDate date,
                                  double money) {
    double rem = model.buyStockWithMoney(portfolioName, tickerId, date, money);
    return rem;
  }

  @Override
  public void save(String portfolioName) {
    model.save(portfolioName);

  }

  @Override
  public void retrieve(String portfolioFile) {
    model.retrieve(portfolioFile);
  }

  @Override
  public double investFixedAmountEqualWeight(LocalDate date, double amount, String portfolioName,
                                             double commission) throws IllegalArgumentException {
    return model.investFixedAmountEqualWeight(date,amount,portfolioName,commission);
  }

  @Override
  public double investFixedAmountVaryingWeight(LocalDate date, double amount, String portfolioName,
                                               double commission, Map<String, Double> weightRatio)
          throws IllegalArgumentException {
    return model.investFixedAmountVaryingWeight(date,amount,portfolioName,commission,weightRatio);
  }

  @Override
  public List<String> getStockInPortfolio(String portfolioName) {
    return model.getStockInPortfolio(portfolioName);
  }

  @Override
  public void addStockToPortfolio(String portfolioName, List<String> stock) throws
          IllegalArgumentException {
    model.addStockToPortfolio(portfolioName,stock);
  }

  @Override
  public double investFixedAmountVaryingWeightPeriodically(LocalDate startdate, LocalDate endDate,
                                                           double amount, String portfolioName,
                                                           double commission, int interval,
                                                           Map<String, Double> weightRatio)
          throws IllegalArgumentException {
    return model.investFixedAmountVaryingWeightPeriodically(startdate,endDate,amount,portfolioName,
            commission,interval,weightRatio);
  }

  @Override
  public void saveStrategy(String strategyName, LocalDate startDate, LocalDate endDate,
                           int interval, double amount, Map<String, Double> weightRatio,
                           double commision) {
    model.saveStrategy(strategyName,startDate,endDate,interval,amount,weightRatio,commision);

  }

  @Override
  public void retrieveStrategy(String strategyName, String portfolioName) {
    model.retrieveStrategy(strategyName,portfolioName);

  }
}

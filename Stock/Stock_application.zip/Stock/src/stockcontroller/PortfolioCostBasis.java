package stockcontroller;

import java.time.DateTimeException;
import java.time.LocalDate;

import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. It has a method "go" that is used to invoke
 * the model's TotalPortfolioCostBasis method to retrieve the portfolio's overall cost.
 */
public class PortfolioCostBasis implements StockCommands {

  private String portfolioName;
  private int dd;
  private int mm;
  private int yyyy;

  /**
   * A public constructor to initialize the class variables.
   *
   * @param portfolioName the portfolio name for which the overall cost basis has to be calculated.
   * @param dd            the date of the month at which the portfolio's overall cost basis has to
   *                      be calculated.
   * @param mm            the month at which the portfolio's overall cost basis has to be
   *                      calculated.
   * @param yyyy          the year at which the portfolio's overall cost basis has to be
   *                      calculated.
   */
  public PortfolioCostBasis(String portfolioName, int dd, int mm, int yyyy) {
    this.portfolioName = portfolioName;
    this.dd = dd;
    this.mm = mm;
    this.yyyy = yyyy;
  }

  /**
   * A method that takes in a model object as a parameter and contains a method call to the model
   * where the overall cost basis of a portfolio is calculated and returns the total portfolio cost
   * basis as a string. This method parses the input date, month and year values to a LocalDate
   * object while passing to the model. If the date is of invalid format, then this method returns
   * the exception thrown by the model to the controller.
   *
   * @param m refers to the model object that contains the base implementation to determine the cost
   *          value of a portfolio at a certain date.
   * @return gives the total cost basis of a particular portfolio at a particular date as a string.
   */
  @Override
  public String command(StockExchange m) {
    String output;
    try {
      LocalDate date = LocalDate.of(yyyy, mm, dd);
      output = "$ " + m.getTotalPortfolioCostBasis(this.portfolioName, date);
    } catch (DateTimeException e) {
      return e.getMessage();
    }
    return output;
  }
}

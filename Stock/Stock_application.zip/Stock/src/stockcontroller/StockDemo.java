package stockcontroller;

import stockmodel.Stock;
import stockmodel.StockExchange;
import stockmodel.StockExchangeImpl;
import view.StockGUIView;
import view.StockView;

/**
 * This is the Main method of Stock class. The program starts from here.
 */
public class StockDemo {

  /**
   * This the main method of stock class from where the program starts.
   *
   * @param args the args for the main class.
   */
  public static void main(String[] args) {
    if (args.length < 1) {
      System.out.println("Please use \"java -jar Stock.jar gui\" for GUI and \"java -jar " +
              "Stock.jar cli\" for CLI ");
      return;
    }
    StockExchange<Stock> model = StockExchangeImpl.getBuilder().portfolio(10).build();
    String viewOption = args[0];
    if (viewOption.equals("gui")) {
      GuiControllerInterface controller = new GuiController();
      StockGUIView view = new StockGUIView();
      controller.start(model, view);
    } else if (viewOption.equals("cli")) {
      Controller controller = new Controller();
      StockView view = new StockView();
      controller.command(model, view);
    } else {
      System.out.println("Please use \"java -jar Stock.jar gui\" for GUI and \"java -jar " +
              "Stock.jar cli\" for CLI ");
    }
  }
}


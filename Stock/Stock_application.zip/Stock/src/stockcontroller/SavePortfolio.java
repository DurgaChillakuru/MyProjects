package stockcontroller;

import stockmodel.Stock;
import stockmodel.StockExchange;

/**
 * A class that implements the interface StockCommands. It has a method "command" to pass the input
 * parameters to the model that will be used to save a particular portfolio to a file at a
 * particular location.
 */

public class SavePortfolio implements StockCommands {

  private String portfolioName;

  /**
   * A public constructor to initialise the class variable.
   *
   * @param portfolioName Represents the portfolio to be save to a JSON file
   */
  public SavePortfolio(String portfolioName) {
    this.portfolioName = portfolioName;
  }

  /**
   * This method is common amongst all the commands. This takes a model as a parameter and returns
   * the output passed by the model as a string.
   *
   * @param m model of the stock implementation.
   * @return Returns a string mentioning portfolio has been saved successfully or exception message.
   */

  @Override
  public String command(StockExchange<Stock> m) {
    try {
      m.save(portfolioName);
    } catch (IllegalArgumentException e) {
      return e.getMessage();
    }
    return "Portfolio has been saved successfully";
  }
}

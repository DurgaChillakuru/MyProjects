package view;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import addstock.AddStockView;
import buyoperation.BuyStockView;
import portfoliooperation.PortfolioCostBasis;
import portfoliooperation.PortfolioOperationView;
import portfolioview.CreateView;
import portfolioview.PortfolioListView;
import saveportfolio.SaveView;
import stockcontroller.ButtonListener;
import stockcontroller.GuiControllerInterface;
import stockmodel.PortfolioWrapper;
import strategy.GetPortfolio;
import strategy.InvestFixedView;
import strategy.InvestStratView;
import strategy.InvestVariableView;
import strategy.RetrieveStrategyView;
import strategy.SaveStrategy;

/**
 * This is helper class of Stock GUI View. This class helps in mapping button action and
 * corresponding action.
 */
public class StockGUIViewHelper implements ControllerInterface {
  private GuiControllerInterface controller;
  private ViewInterface portfolioView;
  private ViewTextInterface createPortfolioView;
  private ViewInterface listPortfolioView;
  private ViewTextInterface buyStockView;
  private ViewTextInterface addStockView;
  private ViewInterface view;
  private ViewInterface portfolioOperationView;
  private ViewTextInterface costBasisView;
  private ViewTextInterface saveView;
  private ViewInterface investStratView;
  private ViewTextInterface investFixedView;
  private ViewTextInterface investVariableView;
  private ViewTextInterface investVariable;
  private ViewTextInterface saveStrategyView;
  private ViewTextInterface retrieveStartegyView;
  private boolean buy = true;

  /**
   * This is the constructor class of GUI helper class.
   *
   * @param view The view object of this session.
   */
  public StockGUIViewHelper(ViewInterface view) {
    this.view = view;
    configureButtonListener();
  }

  @Override
  public void setController(GuiControllerInterface controlRedirect) {
    this.controller = controlRedirect;
  }

  private void configureButtonListener() {
    Map<String, Runnable> buttonMap = new HashMap<>();
    ButtonListener buttonListener = new ButtonListener();
    buttonMap.put("Portfolio", () -> {
      portfolioView = new PortfolioView();
      portfolioView.setActionListener(buttonListener);
    });

    // Create Portfolio Panel
    buttonMap.put("CreatePortfolio", () -> {
      createPortfolioView = new CreateView();
      createPortfolioView.setActionListener(buttonListener);
      ((JFrame) portfolioView).dispose();
    });

    buttonMap.put("CreateNewPortfolio", () -> {
      String name = createPortfolioView.getInputText();
      try {
        controller.createPortfolio(name);
        JOptionPane.showMessageDialog((StockGUIView) view, "Portfolio created successfully",
                "Success", JOptionPane.INFORMATION_MESSAGE);
      } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
                "Failure", JOptionPane.ERROR_MESSAGE);
      }
      createPortfolioView.setActionListener(buttonListener);
      ((JFrame) this.createPortfolioView).dispose();
    });

    buttonMap.put("ExitNewPortfolio", () -> {
      ((JFrame) this.createPortfolioView).dispose();
    });

    buttonMap.put("ViewPortfolio", () -> {
      String portfolioName = "";
      List<String> temp = controller.listPortfolio();
      for (String list : temp) {
        portfolioName = portfolioName + list + "\n";
      }
      listPortfolioView = new PortfolioListView(portfolioName);
      listPortfolioView.setActionListener(buttonListener);
      ((JFrame) portfolioView).dispose();
    });

    buttonMap.put("ExitListPortfolio", () -> {
      ((JFrame) this.listPortfolioView).dispose();
    });

    buttonMap.put("BuyStock", () -> {
      buyStockView = new BuyStockView();
      buyStockView.setActionListener(buttonListener);
    });

    buttonMap.put("BuyStockSym", this::buyStockSymMeth);

    buttonMap.put("Exit", () -> System.exit(0));

    buttonMap.put("PortfolioOperation", () -> {
      portfolioOperationView = new PortfolioOperationView();
      portfolioOperationView.setActionListener(buttonListener);
    });

    buttonMap.put("PCostBasis", () -> {
      costBasisView = new PortfolioCostBasis("Enter the Date to show Cost Basis:",
              "CostBasisQuery", true);
      costBasisView.setActionListener(buttonListener);
      ((JFrame) this.portfolioOperationView).dispose();
    });


    buttonMap.put("CostBasisQuery", this::getCostBasis);

    buttonMap.put("CostBasisBack", () -> {
      ((JFrame) this.costBasisView).dispose();
    });

    buttonMap.put("ExitBuyPanel", () -> {
      ((JFrame) this.buyStockView).dispose();
    });

    buttonMap.put("PValue", () -> {
      costBasisView = new PortfolioCostBasis("Enter the Date to show Value Basis:",
              "ValueBasisQuery", true);
      costBasisView.setActionListener(buttonListener);
      ((JFrame) this.portfolioOperationView).dispose();
    });

    buttonMap.put("ValueBasisQuery", this::getTotalValue);

    buttonMap.put("CompletePort", () -> {
      costBasisView = new PortfolioCostBasis("", "CompletePortQuery", false);
      costBasisView.setActionListener(buttonListener);
      ((JFrame) this.portfolioOperationView).dispose();
    });

    buttonMap.put("CompletePortQuery", () -> {
      String text = costBasisView.getInputText();
      String[] tokens = text.split(";");
      if (tokens.length < 1) {
        return;
      }
      String portfolio = tokens[0];
      try {
        String result;
        StringBuilder sb = new StringBuilder();
        PortfolioWrapper wrapper = controller.viewFullPortfolio(portfolio);
        result = wrapper.toString();
        String[] values = result.split(", ");
        if (values.length > 1) {
          for (int i = 0; i < values.length; i = i + 4) {
            sb.append(values[i + 1] + " Stock of " + values[i] + " was purchased on "
                    + values[i + 2] +
                    " with per share value of $" + values[i + 3] + "\n");
          }
        } else {
          sb.append("There is no stock in portfolio");
        }
        JOptionPane.showMessageDialog(((StockGUIView) view),
                sb.toString(), "Success",
                JOptionPane.INFORMATION_MESSAGE);
      } catch (IllegalArgumentException ex) {
        JOptionPane.showMessageDialog(((StockGUIView) view), ex.getMessage(),
                "Failure", JOptionPane.ERROR_MESSAGE);
      }
    });

    buttonMap.put("Save", () -> {
      saveView = new SaveView("Save");
      saveView.setActionListener(buttonListener);
    });

    buttonMap.put("Retrieve", () -> {
      saveView = new SaveView("Retrieve");
      saveView.setActionListener(buttonListener);
    });

    buttonMap.put("ExitSavePortfolio", () -> {
      ((JFrame) this.saveView).dispose();
    });

    buttonMap.put("SavePortfolio", () -> {
      String text = saveView.getInputText();
      String[] texttokens = text.split(";");
      if (texttokens.length < 1) {
        return;
      }
      String portfolioName = texttokens[0];
      try {
        controller.save(portfolioName);
        JOptionPane.showMessageDialog(((StockGUIView) view), "Saved portfolio", "Success",
                JOptionPane.INFORMATION_MESSAGE);
      } catch (IllegalArgumentException ex) {
        JOptionPane.showMessageDialog(((StockGUIView) view), ex.getMessage(),
                "Failure", JOptionPane.ERROR_MESSAGE);
      }
    });

    buttonMap.put("RetrievePortfolio", () -> {
      String fileName = saveView.getInputText();
      String[] texttokens = fileName.split(";");
      if (texttokens.length < 1) {
        return;
      }
      String portfolioName = texttokens[0];
      try {
        controller.retrieve(portfolioName);
        JOptionPane.showMessageDialog(((StockGUIView) view), "Retrieved portfolio", "Success",
                JOptionPane.INFORMATION_MESSAGE);
      } catch (IllegalArgumentException ex) {
        JOptionPane.showMessageDialog(((StockGUIView) view), ex.getMessage(),
                "Failure", JOptionPane.ERROR_MESSAGE);
      }
    });

    buttonMap.put("AddStock", () -> {
      addStockView = new AddStockView();
      addStockView.setActionListener(buttonListener);
    });

    buttonMap.put("ExitAddStockPanel", () -> {
      ((JFrame) this.addStockView).dispose();
    });

    buttonMap.put("AddStockSym", () -> {
      String addStockText = addStockView.getInputText();
      String[] tokens = addStockText.split(";");
      if (tokens.length < Integer.parseInt(tokens[0])) {
        return;
      }
      String portfolio = tokens[1];
      try {
        List<String> stock = new ArrayList<>();
        for (int i = 2; i <= tokens.length - 1; i++) {
          stock.add(tokens[i]);
        }
        controller.addStockToPortfolio(portfolio, stock);
        JOptionPane.showMessageDialog(((StockGUIView) view),
                "Sucessfully added stock", "Success",
                JOptionPane.INFORMATION_MESSAGE);
        ((JFrame) this.addStockView).dispose();
      } catch (Exception ex) {
        JOptionPane.showMessageDialog(((StockGUIView) view), ex.getMessage(),
                "Failure", JOptionPane.ERROR_MESSAGE);
      }
    });

    // Invest
    buttonMap.put("StrategyInvest", () -> {
      investStratView = new InvestStratView();
      investStratView.setActionListener(buttonListener);
    });

    buttonMap.put("InvestFixed", () -> {
      ((JFrame) this.investStratView).dispose();
      investFixedView = new InvestFixedView();
      investFixedView.setActionListener(buttonListener);
    });

    buttonMap.put("InvestFixedBuy", () -> {
      String text = investFixedView.getInputText();
      String[] tokens = text.split(";");
      if (tokens.length < 5) {
        return;
      }
      String portfolioName = tokens[0];
      String money = tokens[1];
      String date = tokens[3];
      String month = tokens[2];
      String year = tokens[4];
      if (Double.parseDouble(money) <= 0) {
        JOptionPane.showMessageDialog(((StockGUIView) view), "Please enter correct amount",
                "Failure", JOptionPane.ERROR_MESSAGE);
        return;
      }
      String commision = tokens[5];
      double commisionAmount = checkCommision(commision, investFixedView);
      if (buy) {
        try {
          LocalDate dateNow = LocalDate.of(Integer.parseInt(year), Integer.parseInt(month),
                  Integer.parseInt(date));
          Double rem = controller.investFixedAmountEqualWeight(dateNow, Double.parseDouble(money),
                  portfolioName, commisionAmount);
          JOptionPane.showMessageDialog((StockGUIView) view, "Stock Purchased successfully" +
                          "and remaining amount " + rem + " Transferred back",
                  "Success", JOptionPane.INFORMATION_MESSAGE);
          ((JFrame) this.investFixedView).dispose();
        } catch (IllegalArgumentException | DateTimeException e) {
          JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
                  "Failure", JOptionPane.ERROR_MESSAGE);
        }
      }
    });

    buttonMap.put("ExitInvestFix", () -> {
      ((JFrame) this.investFixedView).dispose();
    });

    buttonMap.put("InvestVariable", () -> {
      ((JFrame) this.investStratView).dispose();
      investVariableView = new GetPortfolio();
      investVariableView.setActionListener(buttonListener);
    });

    buttonMap.put("FetchPortfolioInfo", () -> {
      String name = investVariableView.getInputText();
      List stock;
      try {
        stock = controller.getStockInPortfolio(name);
      } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
                "Failure", JOptionPane.ERROR_MESSAGE);
        return;
      }
      if (stock.size() < 1) {
        JOptionPane.showMessageDialog(((StockGUIView) view), "Please add stock first",
                "Failure", JOptionPane.ERROR_MESSAGE);
        ((JFrame) this.investVariableView).dispose();
        return;
      }
      investVariableView.setActionListener(buttonListener);
      investVariable = new InvestVariableView(stock, name);
      investVariable.setActionListener(buttonListener);
      ((JFrame) this.investVariableView).dispose();
    });

    buttonMap.put("InvestStockVariable", () -> {
      String text = investVariable.getInputText();
      String[] tokens = text.split(";");
      int token = Integer.parseInt(tokens[0]);
      int len = tokens.length;
      if (tokens.length < token) {
        return;
      }
      String money = tokens[1];
      String port = tokens[len - 1];
      List<String> stock;
      stock = controller.getStockInPortfolio(port);
      Map<String, Double> map = new HashMap<>();
      int count = 2;
      double count1 = 0.0;
      for (String str : stock) {
        count1 += Double.parseDouble(tokens[count]);
        map.put(str, Double.parseDouble(tokens[count]) / 100.0);
        count++;
      }
      if (Double.parseDouble(money) <= 0) {
        JOptionPane.showMessageDialog(((StockGUIView) view), "Please provide valid input " +
                "for Money", "Failure", JOptionPane.ERROR_MESSAGE);
        buy = false;
        ((JFrame) this.investVariable).dispose();
      }
      if (count1 <= 99.6) {
        JOptionPane.showMessageDialog(((StockGUIView) view), "Please provide valid weight",
                "Failure", JOptionPane.ERROR_MESSAGE);
        buy = false;
        ((JFrame) this.investVariable).dispose();
      }
      String date = tokens[len - 5];
      String month = tokens[len - 4];
      String year = tokens[len - 3];
      String commision = tokens[len - 2];
      double commisionAmount = checkCommision(commision, investFixedView);
      if (buy) {
        try {
          LocalDate dateNow = LocalDate.of(Integer.parseInt(year), Integer.parseInt(month),
                  Integer.parseInt(date));
          Double rem = controller.investFixedAmountVaryingWeight(dateNow, Double.parseDouble(money),
                  port, commisionAmount, map);
          JOptionPane.showMessageDialog((StockGUIView) view, "Stock Purchased successfully" +
                          "and remaining amount " + rem + " Transferred back",
                  "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IllegalArgumentException | DateTimeException e) {
          JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
                  "Failure", JOptionPane.ERROR_MESSAGE);
        }
      }
    });

    buttonMap.put("ExitInvestVariPanel", () -> {
      ((JFrame) this.investVariable).dispose();
    });

    buttonMap.put("SaveStrategy", () -> {
      saveStrategyView = new SaveStrategy();
      saveStrategyView.setActionListener(buttonListener);
    });

    buttonMap.put("SaveStrategyButExit", () -> {
      ((JFrame) this.saveStrategyView).dispose();
    });

    buttonMap.put("SaveStrategyButton", () -> {
      String text = saveStrategyView.getInputText();
      String[] tokens = text.split(";");
      if (tokens.length < 15) {
        return;
      }
      String stratName = tokens[0];
      String money = tokens[1];
      Map<String, Double> map = new HashMap<>();
      double count = 0.0;
      for (int i = 10; i < 16; i += 2) {
        count += Double.parseDouble(tokens[i + 1]);
        map.put(tokens[i], Double.parseDouble(tokens[i + 1]) / 100.0);
      }
      if (count <= 99.6) {
        JOptionPane.showMessageDialog(((StockGUIView) view), "Please provide valid input " +
                "for Weight", "Failure", JOptionPane.ERROR_MESSAGE);
        buy = false;
      }
      String startdate = tokens[4];
      String startmonth = tokens[3];
      String startyear = tokens[5];
      String commision = tokens[9];
      String endDate = tokens[7];
      String endMonth = tokens[6];
      String endYear = tokens[8];
      int interval = Integer.parseInt(tokens[2]);
      if (interval <= 0) {
        JOptionPane.showMessageDialog(((StockGUIView) view), "Please provide valid input " +
                "for Interval", "Failure", JOptionPane.ERROR_MESSAGE);
        buy = false;
      }
      if (Double.parseDouble(money) <= 0) {
        JOptionPane.showMessageDialog(((StockGUIView) view), "Please provide valid input " +
                "for Money", "Failure", JOptionPane.ERROR_MESSAGE);
        buy = false;
      }
      double commisionAmount = checkCommision(commision, saveStrategyView);
      if (buy) {
        try {
          LocalDate dateNow = LocalDate.of(Integer.parseInt(startyear),
                  Integer.parseInt(startmonth), Integer.parseInt(startdate));
          LocalDate dateend = LocalDate.of(Integer.parseInt(endYear), Integer.parseInt(endMonth),
                  Integer.parseInt(endDate));
          controller.saveStrategy(stratName, dateNow, dateend, interval, Double.parseDouble(money)
                  , map, commisionAmount);
          JOptionPane.showMessageDialog((StockGUIView) view, "Strategy Saved",
                  "Success", JOptionPane.INFORMATION_MESSAGE);
          ((JFrame) this.saveStrategyView).dispose();
        } catch (IllegalArgumentException | DateTimeException e) {
          JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
                  "Failure", JOptionPane.ERROR_MESSAGE);
        }
      }
    });

    buttonMap.put("RetrieveStrategy", () -> {
      retrieveStartegyView = new RetrieveStrategyView();
      retrieveStartegyView.setActionListener(buttonListener);
    });

    buttonMap.put("InvestPeriodic", () -> {
      ((JFrame) this.investStratView).dispose();
      retrieveStartegyView = new RetrieveStrategyView();
      retrieveStartegyView.setActionListener(buttonListener);
    });

    buttonMap.put("ExitRetrievePortfolioInfo", () -> {
      ((JFrame) this.retrieveStartegyView).dispose();
    });

    buttonMap.put("RetrievePortfolioInfo", () -> {
      String text = retrieveStartegyView.getInputText();
      String[] tokens = text.split(";");
      if (tokens.length < 2) {
        return;
      }
      String stratName = tokens[1];
      String portfolio = tokens[0];
      try {
        controller.retrieveStrategy(stratName, portfolio);
        JOptionPane.showMessageDialog((StockGUIView) view, "Invested periodic",
                "Success", JOptionPane.INFORMATION_MESSAGE);
        ((JFrame) this.retrieveStartegyView).dispose();
      } catch (IllegalArgumentException | DateTimeException e) {
        JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
                "Failure", JOptionPane.ERROR_MESSAGE);
      }
    });


    buttonListener.setButtonAction(buttonMap);
    view.setActionListener(buttonListener);
  }

  /**
   * This is a helper method to adjust commision.
   *
   * @param commision the commision specified by user.
   * @return the commision amount.
   */
  private double checkCommision(String commision, ViewTextInterface view) {
    double commisionAmount = 0;
    try {
      commisionAmount = Double.parseDouble(commision);
      if (commisionAmount >= 10 || commisionAmount < 0) {
        throw new Exception();
      }
    } catch (Exception e) {
      JOptionPane.showMessageDialog(((StockGUIView) view), "Commission field is " +
                      "not proper (Accepted 1 - 10),Please check and retry",
              "Failure", JOptionPane.ERROR_MESSAGE);
      buy = false;
      ((JFrame) this.view).dispose();
    }
    return commisionAmount;
  }

  /**
   * this method gives the cost basis.
   */
  private void getCostBasis() {
    String text = costBasisView.getInputText();
    String[] tokens = text.split(";");
    if (tokens.length < 4) {
      return;
    }
    String month = tokens[0];
    String date = tokens[1];
    String year = tokens[2];
    String portfolioName = tokens[3];
    LocalDate dateNow = LocalDate.now();
    try {
      dateNow = LocalDate.of(Integer.parseInt(year), Integer.parseInt(month),
              Integer.parseInt(date));
    } catch (DateTimeException e) {
      JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
              "Failure", JOptionPane.ERROR_MESSAGE);
    }
    try {
      JOptionPane.showMessageDialog(((StockGUIView) view), "Total cost basis of Portfolio " +
                      "is $ " + controller.getTotalPortfolioCostBasis(portfolioName, dateNow),
              "Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (IllegalArgumentException ex) {
      JOptionPane.showMessageDialog(((StockGUIView) view), ex.getMessage(),
              "Failure", JOptionPane.ERROR_MESSAGE);
    }
    ((JFrame) this.costBasisView).dispose();
  }

  private void getTotalValue() {
    String valuemonth;
    String valuedate;
    String valueyear;
    String portfolioName;
    String text = costBasisView.getInputText();
    String[] tokens = text.split(";");
    if (tokens.length < 4) {
      return;
    }
    valuemonth = tokens[0];
    valuedate = tokens[1];
    valueyear = tokens[2];
    portfolioName = tokens[3];
    LocalDate dateNow = LocalDate.now();
    try {
      dateNow = LocalDate.of(Integer.parseInt(valueyear), Integer.parseInt(valuemonth),
              Integer.parseInt(valuedate));
    } catch (DateTimeException e) {
      JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
              "Failure", JOptionPane.ERROR_MESSAGE);
    }
    try {
      JOptionPane.showMessageDialog(((StockGUIView) view),
              "Total value basis of Portfolio " +
                      "is $ " + controller.getTotalPortfolioValue(portfolioName, dateNow),
              "Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (IllegalArgumentException ex) {
      JOptionPane.showMessageDialog(((StockGUIView) view), ex.getMessage(),
              "Failure", JOptionPane.ERROR_MESSAGE);
    }
    ((JFrame) this.costBasisView).dispose();
  }

  private void buyStockSymMeth() {
    String text = buyStockView.getInputText();
    String[] tokens = text.split(";");
    if (tokens.length < 6) {
      return;
    }
    String stock = tokens[0];
    String money = tokens[1];
    String date = tokens[3];
    String month = tokens[4];
    String year = tokens[5];
    String portfolioName = tokens[2];
    String commision = tokens[6];
    double commisionAmount = checkCommision(commision, buyStockView);
    if (buy) {
      try {
        LocalDate dateNow = LocalDate.of(Integer.parseInt(year), Integer.parseInt(month),
                Integer.parseInt(date));
        Double rem = controller.buyStockWithMoney(portfolioName,
                stock, dateNow, Double.parseDouble(money) - commisionAmount);
        JOptionPane.showMessageDialog((StockGUIView) view, "Stock Purchased successfully" +
                        "and remaining amount " + rem + " Transferred back",
                "Success", JOptionPane.INFORMATION_MESSAGE);
      } catch (IllegalArgumentException | DateTimeException e) {
        JOptionPane.showMessageDialog(((StockGUIView) view), e.getMessage(),
                "Failure", JOptionPane.ERROR_MESSAGE);
      }
    }
    ((JFrame) this.buyStockView).dispose();
  }
}

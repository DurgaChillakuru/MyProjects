package view;

import java.awt.event.ActionListener;

/**
 * This is the view interface. This class sets the action listener.
 */
public interface ViewInterface {

  /**
   * This will set the action  listener for each button in stock view.
   *
   * @param listener the action listener name.
   */
  void setActionListener(ActionListener listener);

}

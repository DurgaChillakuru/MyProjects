package view;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * This is the view for the stock implementation. This class is responsible for getting the inputs
 * from user and displaying the results.
 */
public class StockView {

  private Scanner s;
  private Readable rd;
  private Appendable ap;

  /**
   * This is the constructor class of Stock view. This will initialize the readable and appendable.
   *
   */
  public StockView() {
    rd = new InputStreamReader(System.in);
    ap = System.out;
    s = new Scanner(rd);
  }

  /**
   * A parametrized constructor to initialize the class variables.
   *
   * @param rd is the readable object.
   * @param ap is the appendable object.
   * @throws IllegalArgumentException when either of appendable or readable is null.
   */
  public StockView(Readable rd, Appendable ap) throws IllegalArgumentException {
    if (ap == null || rd == null) {
      throw new IllegalArgumentException("Appendable or Readable cannot be null");
    }
    this.rd = rd;
    this.ap = ap;
    s = new Scanner(rd);
  }

  /**
   * This method is responsible for getting the user's inputs. It waits until the user provides an
   * input.
   *
   * @return Returns the user's input as a string.
   */
  public String getUserInput() {
    while (true) {
      if (s.hasNext()) {
        return s.next();
      }
    }
  }

  /**
   * This method is responsible for displaying the output returned by the controller.
   */
  public void displayOutput(String output) {
    try {
      ap.append(output).append("\n");
    } catch (IOException io) {
      System.out.println(io.getMessage());
    }
  }
}

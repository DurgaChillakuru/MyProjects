package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import stockcontroller.GuiControllerInterface;

/**
 * This is the GUI view of the Stock. This provide User interaction for some of the operation to
 * support stock purchase. This is implemented in Java swing.
 */
public class StockGUIView extends JFrame implements ViewInterface, ControllerInterface {
  private static final String HEADING = "Virtual Stock Model";
  private JButton portfolio;
  private JButton buyStock;
  private JButton portfolioOperation;
  private JButton saveOperation;
  private JButton retrieveOperation;
  private JButton addStock;
  private JButton strategyInvest;
  private JButton exit;
  private JButton saveStrategy;
  private JButton retrieveStrategy;
  private JPanel mainPanel;
  private GuiControllerInterface controller;
  private StockGUIViewHelper helper;

  /**
   * This is the constructor class of Stock GUI view.
   */
  public StockGUIView() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
    helper = new StockGUIViewHelper(this);
  }

  private void initButton() {
    JPanel buttonPanel = new JPanel();
    buttonPanel.setPreferredSize(new Dimension(200, 200));
    GridLayout gridLayout = new GridLayout(6, 2);
    gridLayout.setVgap(15);
    gridLayout.setHgap(20);
    buttonPanel.setLayout(gridLayout);
    portfolio = new JButton("Portfolio");
    portfolio.setActionCommand("Portfolio");
    portfolio.setFont(new Font("Courier New", Font.ITALIC, 16));
    buyStock = new JButton("BuyStock");
    buyStock.setActionCommand("BuyStock");
    buyStock.setFont(new Font("Courier New", Font.ITALIC, 16));
    portfolioOperation = new JButton("PortfolioAction");
    portfolioOperation.setActionCommand("PortfolioOperation");
    portfolioOperation.setFont(new Font("Courier New", Font.ITALIC, 16));
    saveOperation = new JButton("Save");
    saveOperation.setActionCommand("Save");
    saveOperation.setFont(new Font("Courier New", Font.ITALIC, 16));
    retrieveOperation = new JButton("Retrieve");
    retrieveOperation.setActionCommand("Retrieve");
    retrieveOperation.setFont(new Font("Courier New", Font.ITALIC, 16));

    saveStrategy = new JButton("SaveStrategy");
    saveStrategy.setActionCommand("SaveStrategy");
    saveStrategy.setFont(new Font("Courier New", Font.ITALIC, 16));

    retrieveStrategy = new JButton("RetrieveStrategy");
    retrieveStrategy.setActionCommand("RetrieveStrategy");
    retrieveStrategy.setFont(new Font("Courier New", Font.ITALIC, 16));


    addStock = new JButton("AddStock");
    addStock.setActionCommand("AddStock");
    addStock.setFont(new Font("Courier New", Font.ITALIC, 16));
    strategyInvest = new JButton("StrategyInvest");
    strategyInvest.setActionCommand("StrategyInvest");
    strategyInvest.setFont(new Font("Courier New", Font.ITALIC, 16));
    exit = new JButton("Exit");
    exit.setActionCommand("Exit");
    exit.setFont(new Font("Courier New", Font.ITALIC, 16));
    portfolio.setForeground(Color.BLUE);
    buttonPanel.add(portfolio);
    buyStock.setForeground(Color.BLUE);
    buttonPanel.add(buyStock);
    addStock.setForeground(Color.BLUE);
    buttonPanel.add(addStock);
    strategyInvest.setForeground(Color.BLUE);
    buttonPanel.add(strategyInvest);
    portfolioOperation.setForeground(Color.BLUE);
    buttonPanel.add(portfolioOperation);
    saveOperation.setForeground(Color.BLUE);
    buttonPanel.add(saveOperation);
    retrieveOperation.setForeground(Color.BLUE);
    buttonPanel.add(retrieveOperation);
    saveStrategy.setForeground(Color.BLUE);
    buttonPanel.add(saveStrategy);
    retrieveStrategy.setForeground(Color.BLUE);
    buttonPanel.add(retrieveStrategy);
    exit.setForeground(Color.RED);
    buttonPanel.add(exit);
    this.getContentPane().add(mainPanel, BorderLayout.NORTH);
    this.getContentPane().add(buttonPanel, BorderLayout.CENTER);
    this.pack();

  }

  /**
   * This will start the GUI.
   */
  public void setVisible() {
    this.setVisible(true);
    helper.setController(this.controller);
  }

  private void configureLayout() {
    this.setPreferredSize(new Dimension(500, 400));
    mainPanel = new JPanel();
    mainPanel.setPreferredSize(new Dimension(200, 100));
    JLabel head = new JLabel();
    head.setText("This is a Simple Virtual Stock Model");
    JLabel next = new JLabel("Please press any action below.");
    next.setFont(new Font("Courier New", Font.BOLD, 15));
    head.setFont(new Font("Courier New", Font.BOLD, 15));
    head.setForeground(Color.red);
    next.setForeground(Color.red);
    head.setHorizontalTextPosition(JLabel.CENTER);
    mainPanel.add(head);
    mainPanel.add(next);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    portfolio.addActionListener(listener);
    buyStock.addActionListener(listener);
    portfolioOperation.addActionListener(listener);
    saveOperation.addActionListener(listener);
    retrieveOperation.addActionListener(listener);
    exit.addActionListener(listener);
    addStock.addActionListener(listener);
    strategyInvest.addActionListener(listener);
    saveStrategy.addActionListener(listener);
    retrieveStrategy.addActionListener(listener);
  }

  @Override
  public void setController(GuiControllerInterface controlRedirect) {
    this.controller = controlRedirect;
  }
}

package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * This is the portfolio view of the Stock class. This class has two options 1. Create a portfolio.
 * 2. View Existing Portfolio.
 */
public class PortfolioView extends JFrame implements ViewInterface {

  private final String HEADING = "Create and View Portfolio";
  private JButton createPortfolio;
  private JButton viewPortfolio;
  private JPanel mainPortfolioPanel;

  /**
   * This is the constructor class of portfolio view. This Method help in building the layout and
   * view of the portfolio view panel.
   */
  public PortfolioView() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void configureLayout() {
    mainPortfolioPanel = new JPanel();
    mainPortfolioPanel.setPreferredSize(new Dimension(400, 300));
    JLabel head = new JLabel();
    head.setText("Please select one of the option below :");
    head.setForeground(Color.red);
    head.setHorizontalTextPosition(JLabel.CENTER);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

  private void initButton() {
    GridLayout gridLayout = new GridLayout(2, 1);
    gridLayout.setHgap(50);
    gridLayout.setVgap(50);
    mainPortfolioPanel.setLayout(gridLayout);
    mainPortfolioPanel.setBorder(new EmptyBorder(new Insets(50, 50, 50, 50)));

    createPortfolio = new JButton("Create Portfolio");
    createPortfolio.setActionCommand("CreatePortfolio");
    createPortfolio.setFont(new Font("Courier New", Font.ITALIC, 16));
    createPortfolio.setForeground(Color.BLUE);
    mainPortfolioPanel.add(createPortfolio);

    viewPortfolio = new JButton("View Portfolio");
    viewPortfolio.setActionCommand("ViewPortfolio");
    viewPortfolio.setFont(new Font("Courier New", Font.ITALIC, 16));
    viewPortfolio.setForeground(Color.BLUE);
    mainPortfolioPanel.add(viewPortfolio);

    this.add(mainPortfolioPanel, BorderLayout.CENTER);
    this.pack();
    this.setVisible(true);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    createPortfolio.addActionListener(listener);
    viewPortfolio.addActionListener(listener);
  }
}

package view;

import java.awt.event.ActionListener;

/**
 * This is the view text interface. This provides additional method to get input text.
 */
public interface ViewTextInterface {

  /**
   * This will set the action  listener for each button in stock view.
   *
   * @param listener the action listener name.
   */
  void setActionListener(ActionListener listener);

  /**
   * This is method which returns the input text.
   *
   * @return the string in the input field.
   */
  String getInputText();
}

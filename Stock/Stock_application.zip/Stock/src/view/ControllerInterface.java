package view;

import stockcontroller.GuiControllerInterface;

/**
 * This Interface will help in redirecting control to and fro.
 */
public interface ControllerInterface {

  /**
   * This will redirect the control to controller.
   *
   * @param controlRedirect the controller object
   */
  void setController(GuiControllerInterface controlRedirect);
}

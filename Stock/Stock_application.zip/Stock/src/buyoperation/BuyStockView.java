package buyoperation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is Buy stock view class. This class provides the User interface for the stock buy
 * operation.
 */
public class BuyStockView extends JFrame implements ViewTextInterface {
  private final String HEADING = "Buy Stock";
  private JPanel buyStockPanel;
  private JTextField[] textField = new JTextField[7];
  private JButton back;
  private JButton buy;
  private JPanel commissionPanel;

  /**
   * This is the constructor of Buy Stock view.
   */
  public BuyStockView() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void configureLayout() {
    JCheckBox checkbox;
    buyStockPanel = new JPanel();
    buyStockPanel.setPreferredSize(new Dimension(400, 300));
    buyStockPanel.add(createContent());
    buyStockPanel.add(getDatePanel());
    checkbox = new JCheckBox("Add commission for this Buy");
    checkbox.setSelected(false);
    ActionListener actionListener = new ActionHandler();
    checkbox.addActionListener(actionListener);
    buyStockPanel.add(checkbox);
    buyStockPanel.add(getCommisionPanel());
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.add(buyStockPanel, BorderLayout.CENTER);
    buyStockPanel.setLayout(new BoxLayout(buyStockPanel, BoxLayout.Y_AXIS));
    this.pack();
    this.setVisible(true);
  }

  private JPanel createContent() {
    JPanel cp = new JPanel(new GridBagLayout());
    String[] text = {"Stock Symbol:", "Amount:", "PortfolioName:"};
    GridBagConstraints g = new GridBagConstraints();
    g.fill = GridBagConstraints.NORTH;
    g.insets = new Insets(1, 1, 2, 1);
    for (int i = 0; i < text.length; ++i) {
      g.gridx = 0;
      g.gridy = i;
      JLabel label = new JLabel(text[i], JLabel.RIGHT);
      textField[i] = new JTextField(20);
      label.setLabelFor(textField[i]);
      cp.add(label, g);
      g.gridx = 1;
      cp.add(textField[i], g);
    }
    return cp;
  }

  private void initButton() {
    JPanel buyPanelButton = new JPanel();
    buy = new JButton("Buy");
    buy.setActionCommand("BuyStockSym");
    buy.setFont(new Font("Courier New", Font.ITALIC, 10));
    buy.setForeground(Color.BLACK);
    buyPanelButton.add(buy);

    back = new JButton("Back");
    back.setActionCommand("ExitBuyPanel");
    back.setFont(new Font("Courier New", Font.ITALIC, 11));
    back.setForeground(Color.BLACK);
    buyPanelButton.add(back);

    buyStockPanel.add(buyPanelButton);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    buy.addActionListener(listener);
    back.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    int count = 0;
    StringBuilder finalText = new StringBuilder();
    for (JTextField text : textField) {
      if (null != text.getText() && !"".equals(text.getText())) {
        finalText.append(text.getText());
        finalText.append(";");
        count++;
      } else {
        if (count != 6) {
          JOptionPane.showMessageDialog(buyStockPanel, "All the fields are mandatory, " +
                  "please check and retry", "Failure", JOptionPane.ERROR_MESSAGE);
          break;
        } else {
          finalText.append(0);
          finalText.append(";");
        }
      }
    }
    return finalText.toString();
  }

  /**
   * This method gives the date panel.
   *
   * @return the date panel to be added to main panel.
   */
  private JPanel getDatePanel() {

    JPanel datePanel = new JPanel();
    datePanel.setBorder(BorderFactory.createTitledBorder("Enter the Date to Buy Stock:"));
    datePanel.setBackground(Color.lightGray);
    datePanel.setLayout(new FlowLayout());

    JLabel month = new JLabel("Month(MM):");
    datePanel.add(month);
    textField[3] = new JTextField(2);
    month.setLabelFor(textField[3]);

    datePanel.add(textField[3]);

    JLabel day = new JLabel("Day(DD):");
    datePanel.add(day);
    textField[4] = new JTextField(2);
    datePanel.add(textField[4]);
    day.setLabelFor(textField[4]);

    JLabel year = new JLabel("Year(YYYY):");
    datePanel.add(year);
    textField[5] = new JTextField(4);
    datePanel.add(textField[5]);
    year.setLabelFor(textField[5]);

    return datePanel;
  }

  private JPanel getCommisionPanel() {
    commissionPanel = new JPanel();
    JLabel commission = new JLabel("Enter commission Amount:");
    textField[6] = new JTextField(5);
    commissionPanel.add(commission);
    commissionPanel.add(textField[6]);
    commission.setLabelFor(textField[6]);
    commissionPanel.setVisible(false);
    return commissionPanel;
  }

  private class ActionHandler implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent event) {
      JCheckBox checkbox = (JCheckBox) event.getSource();
      if (checkbox == checkbox) {
        if (checkbox.isSelected()) {
          commissionPanel.setVisible(true);
        } else {
          commissionPanel.setVisible(false);
          textField[6].setText("0");
        }
      }
    }
  }
}

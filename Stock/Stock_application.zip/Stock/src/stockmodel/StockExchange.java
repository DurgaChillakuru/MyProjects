package stockmodel;

import java.time.LocalDate;
import java.util.List;

/**
 * This class represent the stock exchange. This supports operation like add stock to some portfolio
 * buy a stock, create portfolio and operations relate to portfolio management and stock brokering.
 */
public interface StockExchange<K> extends StockFeatureSupport {

  /**
   * This method gives the portfolio of the user. This gives only the summary of the portfolio like
   * how many share user purchased and what is the amount user invested in that particular share.
   *
   * @param portfolio which user wants to view.
   * @return the string representation of the portfolio. This will give only summary.
   */
  PortfolioWrapper viewPortfolio(String portfolio);

  /**
   * This method gives the full portfolio view of the user. This gives the complete transaction
   * which user made. For ex. if he bought X share on yyyy-mm-dd date and again he bought same share
   * on yyyy-mm-dd+1 date then it will print all the transaction record.
   *
   * @return the complete portfolio as a string.
   */
  PortfolioWrapper viewFullPortfolio(String portfolio);

  /**
   * This method try to buy certain stock on a particular date and it will add to corresponding
   * portfolio. This method will throw illegal-argument exception in two cases: 1. If user try to
   * buy stock on non-trading day. 2. If the symbol doesn't exist.
   *
   * @param stockName     the stockmodel which User needs to purchase.
   * @param portfolioName The Portfolio to which this stock will be added.
   * @param volume        the number of share user wants to buy.
   * @param date          the Date on which the user want to buy.
   * @throws IllegalArgumentException if User try to buy on non-working day.
   */
  void buy(String stockName, String portfolioName, int volume, LocalDate date)
          throws IllegalArgumentException;

  /**
   * This method gives the total cost basis of a portfolio till the date given by user.
   *
   * @param portfolio the name of the portfolio whose value need to be calculated.
   * @param date      the date till which the portfolio value to be calculated.
   * @return the total cost basis of a portfolio.
   */
  double getTotalPortfolioCostBasis(String portfolio, LocalDate date);

  /**
   * This method gives the total value of a portfolio till the date given by user. If the date
   * happen to fall on weekend then the price is calculated for the closing price of previous market
   * open day. For ex. if the portfolio value is asked for sunday, we will calculate the price on
   * Friday closing value. If the portfolio value checked on future date, it will show the present
   * day value.
   *
   * @param portfolio the name of the portfolio whose value needs to be calculated.
   * @param date      the date till which the portfolio value needs to be calculated.
   * @return the total value of a portfolio at a particular date.
   */
  double getTotalPortfolioValue(String portfolio, LocalDate date);

  /**
   * This method will help in creating new portfolio.
   *
   * @param portfolio the name of the new portfolio.
   * @throws IllegalArgumentException if the name of the portfolio already exist.
   */
  void createPortfolio(String portfolio) throws IllegalArgumentException;

  /**
   * This method list all the portfolio in this User stockmodel Exchange.
   *
   * @return the list of portfolio.
   */
  List listPortfolio();
}

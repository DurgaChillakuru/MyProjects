package stockmodel;

/**
 * This is a class which is used to pass the raw data to the controller from the model. The
 * controller will decide how to pass that to view.
 */
public class PortfolioWrapper {

  private String str;

  /**
   * This is a public constructor with a parameter as a string, that is used to contain the various
   * elements like stock name, volume purchased, purchase date and the price per share value.
   *
   * @param str represents tha concatenation of stock name, volume purchased, purchase date and the
   *            price per share value.
   */
  public PortfolioWrapper(String str) {
    this.str = str;
  }

  /**
   * Overrides the default toString method that just returns the string class variable initialised
   * in the first constructor that takes in a argument as a string. This contains the list of stocks
   * in a portfolio, the date when it was purchased and the price at which it had been bought.
   */
  @Override
  public String toString() {
    return this.str;
  }

}

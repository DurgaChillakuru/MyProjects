package stockmodel;

import org.json.simple.JSONObject;

import java.time.LocalDate;
import java.util.Map;

/**
 * This is the Portfolio class. This class represent a portfolio object. Portfolio contain list of
 * Stocks. This has method which provides the Portfolio investment amount and transaction history of
 * the portfolio and summary of portfolio.
 */
public interface Portfolio {

  /**
   * This method gives the name of the portfolio.
   *
   * @return the Name of the portfolio.
   */
  String getPortfolioName();

  /**
   * This method gives the map of stock in this portfolio.
   *
   * @return the stock in the particular portfolio.
   */
  Map<String, Stock> getStock();

  /**
   * This Method gives the total value of the portfolio at a given date. This is the total amount
   * user has invested in this portfolio. This is nothing but sum of quantity * share per price for
   * all the stock.
   *
   * @param date The date at which the total value of the portfolio needs to be checked.
   * @return the total value of the portfolio at a particular date.
   */
  Double getTotalValueAtDate(LocalDate date);

  /**
   * This method will add the given stock to this portfolio.
   *
   * @param stockName     the stockSymbol which needs to be added to this portfolio.
   * @param date          The date at which transaction was made.
   * @param perSharePrice the per share price at a particular date.
   * @param quantity      the number of share purchased.
   */
  void addStockToPortfolio(String stockName, int quantity, LocalDate date, double perSharePrice);

  /**
   * This method gives the summary of portfolio. This is of format : The Total number of Stock: GOOG
   * is 300 and invested amount is $XXXXX.
   *
   * @return the string representation of portfolio summary.
   */
  String printPortfolioSummary();

  /**
   * This method gives the complete history of portfolio. This is the record of all the transaction
   * user has made in this portfolio. This will be of format: 100 Stock of GOOG was purchased on
   * 2018-12-12 with per share value of $100.0  200 Stock of GOOG was purchased on 2017-12-12 with
   * per share value of $200.0
   *
   * @return the string representation of portfolio history.
   */
  String printPortfolioHistory();

  /**
   * get the transaction of the portfolio.
   *
   * @return a string.
   */
  JSONObject readPortfolio();

}

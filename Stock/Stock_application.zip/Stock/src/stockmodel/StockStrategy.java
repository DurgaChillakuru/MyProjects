package stockmodel;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * This is the stock strategy interface this provides method to invest amount strategically as
 * defined below Invest a fixed amount into an existing portfolio containing multiple stocks, using
 * a specified weight for each stock in the portfolio. For example, the user can create a FANG
 * portfolio (Facebook, Apple, Netflix, Google) and then specify to invest $2000 in the portfolio,
 * such that 40% goes towards Facebook, 20% towards Apple, 30% towards Netflix and 10% towards
 * Google). This program offer a more convenient way to use equal weights for all stocks in the
 * portfolio as a preset. For example, “invest $2000 in this portfolio by weighing each stock
 * equally (e.g. 25% each in the FANG portfolio above)”. This program offer higher-level investment
 * strategies. For example, dollar-cost averaging: “create a portfolio of 10 stocks, and invest
 * $2000 in the portfolio every 30 days starting on Jan 1 2012 until Dec 31 2015 using the same,
 * fixed weights”. Note that this is one specific example: the user may use a different amount,
 * different frequency and time range. The strategy may be ongoing, i.e. the user may not specify an
 * end date. Periodic investment strategies may call for executing a transaction on a holiday. In
 * this case, The program will choose the next available day to invest. Since periodic, long-term
 * investment strategies pay little attention to the time of day, The program will buy all stocks
 * using the end-of-day prices.
 */
public interface StockStrategy {

  /**
   * This method will invest the given amount equally among all the shares in portfolio. This will
   * buy integer number of share and the remaining amount is given back to the share holder. If with
   * the given amount it cannot buy atleast one share, then amount will be simply returned back.
   *
   * @param date          the date at which the stock needs to be purchased.
   * @param amount        The total money user asked to invest in the portfolio.
   * @param portfolioName the name of the portfolio to which this amount needs to be invested.
   * @param commission    The commission amount.
   * @return the remaining amount which was returned to user.
   * @throws IllegalArgumentException If the date is not proper or asked to buy on holiday.
   */
  double investFixedAmountEqualWeight(LocalDate date, double amount, String portfolioName,
                                      double commission) throws IllegalArgumentException;

  /**
   * This method will invest the given amount equally among all the shares in portfolio. This will
   * buy integer number of share and the remaining amount is given back to the share holder. If with
   * the given amount it cannot buy atleast one share, then amount will be simply returned back.
   *
   * @param date          the date at which the stock needs to be purchased.
   * @param amount        The total money user asked to invest in the portfolio.
   * @param portfolioName the name of the portfolio to which this amount needs to be invested.
   * @param commission    The commission amount.
   * @param weightRatio   The ratio with which amount needs to be divided among share.
   * @return the remaining amount which was returned to user.
   * @throws IllegalArgumentException If the date is not proper or asked to buy on holiday.
   */
  double investFixedAmountVaryingWeight(LocalDate date, double amount, String portfolioName,
                                        double commission, Map<String, Double> weightRatio)
          throws IllegalArgumentException;

  /**
   * This Method give the list of stock in he portfolio.
   *
   * @param portfolioName The Name of the portfolio.
   * @return the list of stock in that portfolio.
   */
  List<String> getStockInPortfolio(String portfolioName);

  /**
   * This method will help in adding the stock to the portfolio.
   *
   * @param portfolioName The Name of the portfolio to which stock needs to be added.
   * @param stock         the list of stock which needs to be added to portfolio.
   */
  void addStockToPortfolio(String portfolioName, List<String> stock)
          throws IllegalArgumentException;

  /**
   * This method will invest the given amount weighted among all the shares in portfolio. This will
   * buy integer number of share and the remaining amount is given back to the share holder. If with
   * the given amount it cannot buy atleast one share, then amount will be simply given back. If
   * after adding interval it lands in weekend, then it will buy in next working day.
   *
   * @param startdate     the date at which the stock needs to be purchased first.
   * @param endDate       The date till the stock needs to be purchased.
   * @param interval      the interval between which stocks needs to be purchased.
   * @param amount        The total money user asked to invest in the portfolio.
   * @param portfolioName the name of the portfolio to which this amount needs to be invested.
   * @param commission    The commission amount.
   * @param weightRatio   The ratio with which amount needs to be divided among share.
   * @return the remaining amount which was returned to user.
   * @throws IllegalArgumentException If the date is not proper or asked to buy on holiday.
   */
  double investFixedAmountVaryingWeightPeriodically(LocalDate startdate, LocalDate endDate,
                                                    double amount, String portfolioName,
                                                    double commission, int interval,
                                                    Map<String, Double> weightRatio)
          throws IllegalArgumentException;

  /**
   * This method save the strategy in to JSON file. The save operation will create the folder
   * "strategy" under the location where you are running the code and saves the files with the
   * strategy name. JSON files is strictly not to be modified, if JSON cannot be parsed then user
   * need to save the strategy again. There is no chance of recovery unless there is backup.
   *
   * @param strategyName is the name of the strategy.
   * @param startDate    is the start date of the strategy.
   * @param endDate      is the end date of the strategy.
   * @param interval     is the interval of the strategy.
   * @param amount       is the amount of investment for the strategy.
   * @param weightRatio  Map which contain stock and weight ratio.
   */
  void saveStrategy(String strategyName, LocalDate startDate, LocalDate endDate, int interval,
                    double amount, Map<String, Double> weightRatio, double commision);

  /**
   * Retrieves the strategy from strategy file.
   *
   * @param strategyName  The Name of the strategy file.
   * @param portfolioName The Name of the portfolio.
   */
  void retrieveStrategy(String strategyName, String portfolioName);

}

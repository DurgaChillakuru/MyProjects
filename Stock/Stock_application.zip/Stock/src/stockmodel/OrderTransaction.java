package stockmodel;

import java.time.LocalDate;

/**
 * This is the Java pojo class for each transaction. This class contain purchase date, quantity, per
 * price of a stock.
 */
public class OrderTransaction {
  private int quantity;
  private double perSharePrice;
  private LocalDate dateOfPurchase;

  /**
   * This is the constructor class for Order transaction.
   *
   * @param perSharePrice Per share price of stack
   * @param quantity      number of share user purchased
   * @param date          Date on which
   */
  public OrderTransaction(double perSharePrice, int quantity, LocalDate date) {
    this.perSharePrice = perSharePrice;
    this.quantity = quantity;
    this.dateOfPurchase = date;
  }

  /**
   * This will gives the quantity of stock.
   *
   * @return the quantity of share in transaction.
   */
  public int getQuantity() {
    return quantity;
  }

  /**
   * This will give per share price of stock.
   *
   * @return the per share price of the transaction.
   */
  public double getPerSharePrice() {
    return perSharePrice;
  }

  /**
   * This wil give the date of purchase of stock.
   *
   * @return the date of purchase of stock in YYYY-MM-DD format.
   */
  public LocalDate getDateOfPurchase() {
    return dateOfPurchase;
  }
}

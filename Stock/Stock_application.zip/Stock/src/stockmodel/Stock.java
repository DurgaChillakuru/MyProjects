package stockmodel;

import org.json.simple.JSONArray;

import java.time.LocalDate;

/**
 * This is the stock model Interface. This represent stock model object. The stock will have the
 * symbol,Quantity Purchase date and purchase price.
 */
public interface Stock {

  /**
   * This method gives the company symbol which is unique in stock exchange.
   *
   * @return the ticker symbol of the particular stock object.
   */
  String getSymbol();

  /**
   * This method gives the number of stock the user own in this particular company.
   *
   * @return the quantity of stock user has purchased.
   */
  int getQuantity();

  /**
   * This method gives the stock purchase price at a particular date. If user bought 10 shares at
   * $10 and user bought same share at $5 of same quantity on some other day, then this method will
   * give the total purchase price i.e 10*10+5*10 = $150.
   *
   * @return the stock average purchase price at a particular date.
   */
  Double getPurchasePrice(LocalDate date);

  /**
   * This will add the stack transaction.
   *
   * @param perSharePrice the per unit share cose which user bought on a particular date.
   * @param quantity      number of share user bought on the given date.
   * @param date          the Date on which the transaction was made.
   */
  void addTransaction(double perSharePrice, int quantity, LocalDate date);

  /**
   * This method gives the summary of Stock. The Stock summary looks something like this: The Total
   * number of Stock: GOOG is 300 and invested amount is $XXXXX.
   *
   * @return the summary of Stock.
   */
  String printSummary();

  /**
   * This Method returns the history of Stock transaction. This provides information about when was
   * the stock purchased and how much was this stock purchased and the unit price for the same. This
   * stock history will look something like this 100 Stock of GOOG was purchased on 2018-12-12 with
   * per share value of $100.0\n"
   *
   * @return the history of transaction in string format.
   */
  String printHistory();

  /**
   * This method gives the number of stock the user own in this particular company on a particular
   * date.
   *
   * @return the quantity of stock user has purchased till that date.
   */
  int getQuantityDate(LocalDate date);

  /**
   * get the transaction information.
   *
   * @return a json array of object to be saved.
   */
  JSONArray getJsonArray();

}

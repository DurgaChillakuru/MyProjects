package stockmodel;

import org.json.simple.JSONObject;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * This is the portfolio implementation of the stock. The portfolio represent a set of stocks under
 * one category.
 */
public class PortfolioImpl implements Portfolio {
  private String portfolioName;
  private Map<String, Stock> portfolioStocks = new HashMap();

  /**
   * This constructor class will initializes the portfolio name.
   *
   * @param portfolioName The Name of this portfolio.
   */
  public PortfolioImpl(String portfolioName) {
    this.portfolioName = portfolioName;
  }


  @Override
  public String getPortfolioName() {
    return this.portfolioName;
  }

  @Override
  public Map getStock() {
    return this.portfolioStocks;
  }

  @Override
  public Double getTotalValueAtDate(LocalDate date) {
    double totalCostValue = 0.0;
    for (Map.Entry<String, Stock> stocks : portfolioStocks.entrySet()) {
      totalCostValue += stocks.getValue().getPurchasePrice(date);
    }
    return totalCostValue;
  }

  @Override
  public void addStockToPortfolio(String stockName, int quantity, LocalDate date,
                                  double perSharePrice) {
    Stock stock;
    if (portfolioStocks.containsKey(stockName.toUpperCase())) {
      stock = portfolioStocks.get(stockName.toUpperCase());
      stock.addTransaction(perSharePrice, quantity, date);
    } else {
      stock = new StockImpl(stockName.toUpperCase());
      stock.addTransaction(perSharePrice, quantity, date);
    }
    portfolioStocks.put(stockName.toUpperCase(), stock);
  }

  @Override
  public String printPortfolioSummary() {
    StringBuilder sb = new StringBuilder();
    for (Map.Entry<String, Stock> stocks : portfolioStocks.entrySet()) {
      sb.append(stocks.getValue().printSummary());
    }
    return sb.toString();
  }

  @Override
  public String printPortfolioHistory() {
    StringBuilder sb = new StringBuilder();
    for (Map.Entry<String, Stock> stocks : portfolioStocks.entrySet()) {
      sb.append(stocks.getValue().printHistory());
    }
    return sb.toString();
  }

  @Override
  public JSONObject readPortfolio() {
    JSONObject obj = new JSONObject();
    for (Map.Entry entry : portfolioStocks.entrySet()) {
      obj.put(entry.getKey(),((Stock) entry.getValue()).getJsonArray());
    }
    return obj;
  }

}

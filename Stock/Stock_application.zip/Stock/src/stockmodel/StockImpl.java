package stockmodel;

import org.json.simple.JSONArray;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * This is the stock class implementation. This represent one stock in a portfolio. User can buy as
 * many stock as he wishes to buy. It may be in single transaction or in multiple transaction. We
 * are keeping track of multiple transaction, so that when user wishes to see that we can display.
 */
public class StockImpl implements Stock {
  private String stockSym;
  private int quantity;
  private double purchasePrice;
  private List<OrderTransaction> transactionList;

  /**
   * This is the constructor class of Stock. This method will initializes the stock symbol and the
   * transaction list.
   *
   * @param stockSym The symbol of stock.
   */
  public StockImpl(String stockSym) {
    this.stockSym = stockSym;
    this.transactionList = new ArrayList<>();
  }

  @Override
  public String getSymbol() {
    return this.stockSym;
  }

  @Override
  public int getQuantity() {
    return this.quantity;
  }

  @Override
  public Double getPurchasePrice(LocalDate date) {
    if (date.isEqual(LocalDate.now())) {
      return purchasePrice;
    }
    double totalPurchasePrice = 0.0;
    for (int i = 0; i < transactionList.size(); i++) {
      OrderTransaction entry = transactionList.get(i);
      if (entry.getDateOfPurchase().isBefore(date) || entry.getDateOfPurchase().isEqual(date)) {
        totalPurchasePrice += entry.getQuantity() * entry.getPerSharePrice();
      }
    }
    return totalPurchasePrice;
  }

  @Override
  public void addTransaction(double perSharePrice, int quantity, LocalDate date) {
    this.quantity += quantity;
    this.purchasePrice += perSharePrice * quantity;
    OrderTransaction entry = new OrderTransaction(perSharePrice, quantity, date);
    transactionList.add(entry);
  }

  @Override
  public String printSummary() {
    return stockSym.toUpperCase() + ", " + quantity + ", " + purchasePrice + ", ";
  }

  @Override
  public String printHistory() {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < transactionList.size(); i++) {
      OrderTransaction entry = transactionList.get(i);
      sb.append(this.stockSym.toUpperCase() + ", " + entry.getQuantity() + ", "
              + entry.getDateOfPurchase() + ", " + entry.getPerSharePrice() + ", ");
    }
    return sb.toString();
  }

  @Override
  public int getQuantityDate(LocalDate date) {
    int quantity = 0;
    for (int i = 0; i < transactionList.size(); i++) {
      OrderTransaction entry = transactionList.get(i);
      if (entry.getDateOfPurchase().isBefore(date) || entry.getDateOfPurchase().isEqual(date)) {
        quantity += entry.getQuantity();
      }
    }
    return quantity;
  }

  @Override
  public JSONArray getJsonArray() {
    JSONArray list = new JSONArray();
    for (OrderTransaction record : transactionList) {
      list.add(stockSym);
      list.add(record.getQuantity());
      list.add(record.getDateOfPurchase().toString());
      list.add(record.getPerSharePrice());
    }
    return list;
  }

}

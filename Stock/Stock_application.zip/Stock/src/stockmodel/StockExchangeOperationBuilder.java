package stockmodel;

/**
 * This is the builder class of the stock exchange.
 */

public interface StockExchangeOperationBuilder {

  /**
   * This method helps in creating the model view of the stock exchange.
   *
   * @param <K> The type of the stock exchange.
   * @return the stockexchange model for further operation.
   */
  <K> StockExchange<K> build();

  /**
   * This method helps in customizing the portfolio size for a user.
   *
   * @param quantity number of portfolio user wishes to create.
   * @return the builder class after modifying the portfolio size.
   */
  StockExchangeOperationBuilder portfolio(int quantity);
}

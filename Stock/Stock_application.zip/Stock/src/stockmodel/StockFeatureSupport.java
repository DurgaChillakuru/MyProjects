package stockmodel;

import java.time.LocalDate;

/**
 * This is the Interface for additional model operation support.
 */
public interface StockFeatureSupport extends StockStrategy {

  /**
   * Buy shares of some stock in a portfolio worth a certain amount at a certain date.
   *
   * @param portfolioName Name of the portfolio under which this stock will be listed.
   * @param tickerId      The stock symbol which user wants to buy.
   * @param date          Date on which the stock has to be purchased.
   * @param money         The amount user wants to invest on stock.
   */
  double buyStockWithMoney(String portfolioName, String tickerId, LocalDate date
          , double money);

  /**
   * This method save the portfolio in JSON format.The save operation will create the folder
   * "portfolio" under the location where you are running the code and saves the files with the
   * portfolio name. JSON files is strictly not to be modified, if JSON cannot be parsed then user
   * need to save the portfolio again. There is no chance of recovery unless there is backup. If the
   * portfolio doesn't exist, appropriate error will be shown.
   *
   * @param portfolioName the portfolio which needs to be saved.
   */
  void save(String portfolioName);

  /**
   * This method retrieves the portfolio from the given file in JSON format. If the portfolio
   * already exist, then the content will be overriden and so please make sure before retriving the
   * portfolio should not exist. If it not exist then it will create one.
   *
   * @param portfolioFile the portfolio name which needs to be retrieved.
   */

  void retrieve(String portfolioFile);
}

package stockmodel;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import alphavantage.AlphaVantageDemo;

/**
 * This is the Stock Model Implementation. This will help in buying share, create portfolio, view
 * its composition and check the total value and cost basis of portfolio.
 */
public class StockExchangeImpl implements StockExchange<Stock> {
  private int portfolioSize;
  private Map<String, Portfolio> mapOfPortfolio = new HashMap<>();
  private Map<String, Map<String, String>> price = new HashMap<>();

  /**
   * This is the constructor of stockExchange.
   *
   * @param portfolioSize The size of the portfolio.
   */
  public StockExchangeImpl(int portfolioSize) {
    this.portfolioSize = portfolioSize;
  }

  @Override
  public PortfolioWrapper viewPortfolio(String portfolio) {
    String result;
    if (mapOfPortfolio.containsKey(portfolio.trim())) {
      result = mapOfPortfolio.get(portfolio).printPortfolioSummary();
      PortfolioWrapper wrapper = new PortfolioWrapper(result);
      return wrapper;
    } else {
      throw new IllegalArgumentException("Portfolio Name doesn't match with our record.");
    }
  }

  @Override
  public PortfolioWrapper viewFullPortfolio(String portfolio) {
    String result;
    if (mapOfPortfolio.containsKey(portfolio.trim())) {
      result = mapOfPortfolio.get(portfolio).printPortfolioHistory();
      PortfolioWrapper wrapper = new PortfolioWrapper(result);
      return wrapper;
    } else {
      throw new IllegalArgumentException("Portfolio Name doesn't match with our record.");
    }
  }

  @Override
  public void buy(String stockName, String portfolioName, int volume, LocalDate date)
          throws IllegalArgumentException {
    if (volume < 1) {
      throw new IllegalArgumentException("Cannot buy negative number of share");
    }
    if (mapOfPortfolio.containsKey(portfolioName)) {
      DayOfWeek day = date.getDayOfWeek();
      if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
        throw new IllegalArgumentException("Cannot buy stocks on weekend");
      }
      if (!price.containsKey(stockName)) {
        AlphaVantageDemo ad = new AlphaVantageDemo(stockName);
        price.put(stockName, ad.getPriceMap());
      }
      String todayStockPrice = price.get(stockName).get(date.toString());
      if (todayStockPrice == null || "".equals(todayStockPrice)) {
        throw new IllegalArgumentException("Stock is not listed in NASDAQ for the Date !");
      }
      mapOfPortfolio.get(portfolioName).addStockToPortfolio(stockName, volume, date,
              Double.parseDouble(todayStockPrice));
    } else {
      throw new IllegalArgumentException("Portfolio Name doesn't match with our record.");
    }
  }

  @Override
  public double getTotalPortfolioCostBasis(String portfolio, LocalDate date) {
    if (mapOfPortfolio.containsKey(portfolio)) {
      return mapOfPortfolio.get(portfolio).getTotalValueAtDate(date);
    } else {
      throw new IllegalArgumentException("Portfolio Name doesn't match with our record.");
    }
  }

  @Override
  public double getTotalPortfolioValue(String portfolio, LocalDate date) {
    double totalPortfolioValue = 0.0;
    LocalDate priceDate = recalculateExactDate(date);
    if (mapOfPortfolio.containsKey(portfolio)) {
      for (Map.Entry<String, Stock> stockEntry
              : mapOfPortfolio.get(portfolio).getStock().entrySet()) {
        if (!price.containsKey(stockEntry.getKey())) {
          AlphaVantageDemo ad = new AlphaVantageDemo(stockEntry.getKey());
          price.put(stockEntry.getKey().trim(), ad.getPriceMap());
        }
        String todayStockPrice = price.get(stockEntry.getKey()).get(priceDate.toString());
        totalPortfolioValue += stockEntry.getValue().getQuantityDate(date)
                * Double.parseDouble(todayStockPrice);
      }
    } else {
      throw new IllegalArgumentException("Portfolio Name doesn't match with our record.");
    }
    return totalPortfolioValue;
  }

  /**
   * This Method helps in gives the nearest market open date by adjusting one or two days.
   *
   * @param date the Date which user requested for the portfolio value.
   * @return the adjusted date for which the portfolio value needs to be calculated.
   */
  private LocalDate recalculateExactDate(LocalDate date) {
    LocalDate priceDate = date;
    if (priceDate.isAfter(LocalDate.now())) {
      priceDate = LocalDate.now();
    }
    if (priceDate.getDayOfWeek() == DayOfWeek.SUNDAY) {
      priceDate = priceDate.minusDays(2);
    } else if (priceDate.getDayOfWeek() == DayOfWeek.SATURDAY) {
      priceDate = priceDate.minusDays(1);
    }
    return priceDate;
  }

  @Override
  public void createPortfolio(String portfolio) throws IllegalArgumentException {
    if (mapOfPortfolio.size() == portfolioSize) {
      // Ideally should not happen but here we are not restricting.

    }
    if (mapOfPortfolio.containsKey(portfolio)) {
      throw new IllegalArgumentException("Portfolio already exist");
    }
    mapOfPortfolio.put(portfolio, new PortfolioImpl(portfolio));
  }

  @Override
  public List<String> listPortfolio() {
    List<String> list = new ArrayList<>(mapOfPortfolio.keySet());
    return list;
  }

  /**
   * The class provides the builder for stock exchange operations.
   */
  public static StockExchangeOperationBuilder getBuilder() {
    return new StockExchangeBuilder();
  }

  @Override
  public double buyStockWithMoney(String portfolioName, String tickerId, LocalDate date,
                                  double money) {
    String priceToday;
    if (money < 0) {
      throw new IllegalArgumentException("Invest amount cannot be less than 0");
    }
    DayOfWeek day = date.getDayOfWeek();
    if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
      throw new IllegalArgumentException("Cannot buy stocks on weekend");
    }
    priceToday = getStockPriceAtDate(tickerId, date);
    int volume = (int) (money / Double.parseDouble(priceToday));
    this.buy(tickerId, portfolioName, volume, date);
    double rem = (money - (Double.parseDouble(priceToday) * volume));
    return rem;
  }

  @Override
  public void save(String portfolioName) {
    if (!mapOfPortfolio.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Portfolio doesn't exist.Please check name and retry");
    }

    File pathToStore = new File(new File("").getAbsolutePath() + "/portfolio/");
    if (!pathToStore.exists()) {
      pathToStore.mkdir();
    }

    JSONObject obj = mapOfPortfolio.get(portfolioName).readPortfolio();
    try (FileWriter file = new FileWriter(pathToStore + "/" + portfolioName + ".json")) {
      file.write(obj.toJSONString());
      file.flush();
    } catch (IOException e) {
      e.printStackTrace();
      throw new IllegalArgumentException("Some I/O issue please try again " + e.getMessage());
    }

  }

  @Override
  public void retrieve(String portfolioFile) {
    Portfolio addPort = new PortfolioImpl(portfolioFile);
    File portfolioFileName = new File(new File("").getAbsolutePath() +
            "/portfolio/" + portfolioFile + ".json");
    if (!portfolioFileName.exists()) {
      throw new IllegalArgumentException("The portfolio JSON file does not exist");
    }

    JSONParser parser = new JSONParser();
    try {
      Object obj = parser.parse(new FileReader(portfolioFileName));
      JSONObject jsonObject = (JSONObject) obj;
      Iterator iter = jsonObject.keySet().iterator();
      while (iter.hasNext()) {
        JSONArray msg = (JSONArray) jsonObject.get(iter.next());
        Iterator iterator = msg.iterator();
        while (iterator.hasNext()) {
          addPort.addStockToPortfolio(iterator.next().toString()
                  , Integer.parseInt(iterator.next().toString())
                  , LocalDate.parse(iterator.next().toString())
                  , Double.valueOf(iterator.next().toString()));
        }
      }
    } catch (IOException | ParseException ex) {
      throw new IllegalArgumentException("Something wrong happened or file corrupted " +
              "please try again");
    }
    this.mapOfPortfolio.put(portfolioFile, addPort);
  }

  @Override
  public double investFixedAmountEqualWeight(LocalDate date, double amount, String portfolioName,
                                             double commissionAmount)
          throws IllegalArgumentException {
    double rem = 0.0;
    if (!mapOfPortfolio.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Please create portfolio");
    }
    Portfolio port = mapOfPortfolio.get(portfolioName);
    amount = amount - port.getStock().size() * commissionAmount;
    if (amount < 0) {
      if (commissionAmount > 0) {
        throw new IllegalArgumentException("Per transaction charges is more than invest amount");
      }
      throw new IllegalArgumentException("Invest amount cannot be less than 0");
    }
    checkPortfolioExist(portfolioName);
    checkInvestDate(date);
    double investPerStockAmount = amount / port.getStock().size();
    for (Map.Entry<String, Stock> ticker : port.getStock().entrySet()) {
      String price = getStockPriceAtDate(ticker.getKey(), date);
      int volume = (int) (investPerStockAmount / Double.parseDouble(price));
      rem += (investPerStockAmount - (Double.parseDouble(price) * volume));
      if (volume >= 1) {
        port.addStockToPortfolio(ticker.getKey(), volume, date, Double.parseDouble(price));
      }
    }
    mapOfPortfolio.put(portfolioName, port);
    return rem;
  }

  @Override
  public double investFixedAmountVaryingWeight(LocalDate date, double amount, String portfolioName,
                                               double commission, Map<String, Double> weightRatio)
          throws IllegalArgumentException {
    double remainingAmount = 0.0;
    if (!mapOfPortfolio.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Please create portfolio");
    }
    Portfolio port = mapOfPortfolio.get(portfolioName);
    amount = amount - weightRatio.size() * commission;
    if (amount < 0) {
      if (commission > 0) {
        throw new IllegalArgumentException("Per transaction charges is more than invest amount");
      }
      throw new IllegalArgumentException("Invest amount cannot be less than 0");
    }
    checkPortfolioExist(portfolioName);
    checkInvestDate(date);
    for (Map.Entry<String, Double> ticker : weightRatio.entrySet()) {
      String price = getStockPriceAtDate(ticker.getKey(), date);
      double investPerStock = amount * weightRatio.get(ticker.getKey());
      int volume = (int) (investPerStock / Double.parseDouble(price));
      remainingAmount += (investPerStock - (Double.parseDouble(price) * volume));
      if (volume >= 1) {
        port.addStockToPortfolio(ticker.getKey(), volume, date, Double.parseDouble(price));
      }
    }
    mapOfPortfolio.put(portfolioName, port);
    return remainingAmount;
  }

  @Override
  public List<String> getStockInPortfolio(String portfolioName) {
    List<String> stock = new ArrayList<>();
    if (!mapOfPortfolio.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Portfolio doesn't exist");
    }
    Portfolio port = mapOfPortfolio.get(portfolioName);
    if (port.getStock().size() > 0) {
      for (Map.Entry<String, Stock> portstock : port.getStock().entrySet()) {
        stock.add(portstock.getKey());
      }
    }
    return stock;
  }

  @Override
  public void addStockToPortfolio(String portfolioName, List<String> stock)
          throws IllegalArgumentException {
    checkPortfolioExist(portfolioName);
    for (String ticker : stock) {
      try {
        Thread.sleep(1000);
      } catch (Exception e) {
        // Do Nothing
      }
      updatePriceMap(ticker);
      Stock stockobj = new StockImpl(ticker.toUpperCase());
      mapOfPortfolio.get(portfolioName).getStock().put(ticker.toUpperCase(), stockobj);
    }

  }

  @Override
  public double investFixedAmountVaryingWeightPeriodically(LocalDate startdate, LocalDate endDate,
                                                           double amount, String portfolioName,
                                                           double commission, int interval,
                                                           Map<String, Double> weightRatio)
          throws IllegalArgumentException {
    double retAmount = 0.0;
    if (mapOfPortfolio.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Portfolio already exist ");
    }
    for (String ticker : weightRatio.keySet()) {
      try {
        Thread.sleep(100);
      } catch (Exception e) {
        // Do Nothing
        e.printStackTrace();
      }
      updatePriceMap(ticker);
    }
    createPortfolio(portfolioName);
    Portfolio port = mapOfPortfolio.get(portfolioName);
    for (Map.Entry<String, Double> stockSym : weightRatio.entrySet()) {
      String stockname = stockSym.getKey();
      LocalDate start = startdate;
      start = correctDate(stockname, start);
      while (start.isBefore(endDate)) {
        String price = getStockPriceAtDate(stockSym.getKey(), start);
        double investPerStock = amount * weightRatio.get(stockSym.getKey());
        int volume = (int) (investPerStock / Double.parseDouble(price));
        retAmount += (investPerStock - (Double.parseDouble(price) * volume));
        if (volume >= 1) {
          port.addStockToPortfolio(stockSym.getKey(), volume, start, Double.parseDouble(price));
        }
        start = correctDate(stockname, start.plusDays(interval));
      }
    }
    mapOfPortfolio.put(portfolioName, port);
    return retAmount;
  }

  @Override
  public void saveStrategy(String strategyName, LocalDate startDate, LocalDate endDate,
                           int interval, double amount, Map<String, Double> weightRatio,
                           double commision) {
    validateDate(startDate, endDate, interval);
    for (String ticker : weightRatio.keySet()) {
      try {
        Thread.sleep(100);
      } catch (Exception e) {
        // Do Nothing
      }
      updatePriceMap(ticker);
    }
    JSONObject obj = new JSONObject();
    obj.put("strategyName", strategyName);
    obj.put("startDate", startDate.toString());
    obj.put("endDate", endDate.toString());
    obj.put("interval", interval);
    obj.put("amount", amount);
    obj.put("weightRatio", weightRatio);
    obj.put("commision", commision);

    File pathToStore = new File(new File("").getAbsolutePath() + "/strategy/");
    if (!pathToStore.exists()) {
      pathToStore.mkdir();
    }
    try (FileWriter file = new FileWriter(pathToStore + "/" + strategyName + ".json")) {
      file.write(obj.toJSONString());
      file.flush();
    } catch (IOException e) {
      e.printStackTrace();
      throw new IllegalArgumentException("Some I/O issue please try operation again "
              + e.getMessage());
    }
  }

  @Override
  public void retrieveStrategy(String strategyName, String portfolioName) {
    File strategyFileName = new File(new File("").getAbsolutePath() +
            "/strategy/" + strategyName + ".json");
    if (!strategyFileName.exists()) {
      throw new IllegalArgumentException("The strategy JSON file does not exist");
    }
    JSONParser parser = new JSONParser();
    try {
      Object obj = parser.parse(new FileReader(strategyFileName));
      JSONObject jsonObject = (JSONObject) obj;
      String strategy = (String) jsonObject.get("strategyName");
      LocalDate startDate = LocalDate.parse(jsonObject.get("startDate").toString());
      LocalDate endDate = LocalDate.parse(jsonObject.get("endDate").toString());
      int interval = Integer.parseInt(jsonObject.get("interval").toString());
      double amount = Double.parseDouble(jsonObject.get("amount").toString());
      Map<String, Double> weightRatio = (Map) jsonObject.get("weightRatio");
      double commision = (double) jsonObject.get("commision");
      investFixedAmountVaryingWeightPeriodically(startDate, endDate, amount, portfolioName,
              commision, interval, weightRatio);

    } catch (IOException | ParseException ex) {
      ex.printStackTrace();
      throw new IllegalArgumentException("Something wrong happened or file corrupted " +
              "please try again");
    }


  }

  /**
   * This method validates the start and end date.
   *
   * @param startDate The start date of the strategy.
   * @param endDate   the end date of the strategy.
   * @param interval  the interval time.
   */
  private void validateDate(LocalDate startDate, LocalDate endDate, int interval) {
    if (startDate.isAfter(endDate)) {
      throw new IllegalArgumentException("Start date is after end date.");
    }
    if (startDate.isAfter(LocalDate.now())) {
      throw new IllegalArgumentException("Start date cannot be in future");
    }
    if (ChronoUnit.DAYS.between(startDate, endDate) < interval) {
      throw new IllegalArgumentException("Please provide end date little longer.");
    }
  }

  /**
   * This Method helps in determining the date at which we need to purchase the stock. If it fall on
   * weekend then it will add one day and check whether that is valid, if so then it will give
   * date.
   *
   * @param stockname The stockSymbol for which we are searching price.
   * @param start     The start date where we need to find the stock value.
   * @return The day which is valid purchase day.
   */
  private LocalDate correctDate(String stockname, LocalDate start) {
    if (start.isAfter(LocalDate.now())) {
      return start;
    }
    if (!price.containsKey(stockname)) {
      AlphaVantageDemo ad = new AlphaVantageDemo(stockname);
      price.put(stockname, ad.getPriceMap());
    }
    Map temp = price.get(stockname);
    while (null == temp.get(start.toString())) {
      start = start.plusDays(1);
    }
    return start;
  }

  /**
   * This method updated the cache with the price map value.
   *
   * @param ticker The ticker symbol for which the price updates.
   */
  private void updatePriceMap(String ticker) {
    if (!price.containsKey(ticker)) {
      AlphaVantageDemo ad = new AlphaVantageDemo(ticker);
      price.put(ticker, ad.getPriceMap());
    }
  }

  /**
   * This method gives the price of the stock at the specified date.
   *
   * @param tickerId The Ticker symbol which price needs to be checked.
   * @param date     The date at which the price needs to be calculated.
   * @return the price of the stock at the specified date.
   */
  private String getStockPriceAtDate(String tickerId, LocalDate date) {
    String priceAtDate = "";
    if (!price.containsKey(tickerId)) {
      AlphaVantageDemo ad = new AlphaVantageDemo(tickerId);
      price.put(tickerId, ad.getPriceMap());
    }
    priceAtDate = price.get(tickerId).get(date.toString());
    return priceAtDate;
  }

  /**
   * This method helps in determining whether user provided valid date or not.
   *
   * @param date the Date at which the stock needs to be purchased.
   * @throws IllegalArgumentException if the day is holiday or it is future.
   */
  private void checkInvestDate(LocalDate date) throws IllegalArgumentException {
    DayOfWeek day = date.getDayOfWeek();
    if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
      throw new IllegalArgumentException("Cannot buy stocks on weekend");
    }
    if (date.isAfter(LocalDate.now())) {
      throw new IllegalArgumentException("Cannot invest in future.");
    }
  }

  /**
   * This method helps in checking whether the portfolio exist or not.
   *
   * @param portfolioName The portfolio name to be checked whether exist or not.
   * @throws IllegalArgumentException if the name doesn't exist.
   */
  private void checkPortfolioExist(String portfolioName) throws IllegalArgumentException {
    if (!mapOfPortfolio.containsKey(portfolioName)) {
      throw new IllegalArgumentException("Portfolio doesn't exist.Please check name and retry");
    }
  }

  /**
   * The class implements the StockExchangeBuilder, which represents a builder. In this model we are
   * restricting the portfolio size to 10. We can change this size anytime, but we are not
   * supporting this feature in this release.
   */
  private static class StockExchangeBuilder implements StockExchangeOperationBuilder {

    private int portfolio = 10;

    @Override
    public StockExchangeOperationBuilder portfolio(int portfolioSize)
            throws IllegalArgumentException {
      if (portfolioSize <= 0) {
        throw new IllegalArgumentException("There cannot be less than 1 portfolio");
      }
      this.portfolio = portfolioSize;
      return this;
    }

    @Override
    public StockExchange<Stock> build() {
      return new StockExchangeImpl(portfolio);
    }
  }

}

package addstock;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is the add stock view. It will add the stock to portfolio.
 */
public class AddStockView extends JFrame implements ViewTextInterface {
  private final String HEADING = "Add Stock To Portfolio";
  private JButton back;
  private JButton add;
  private JButton addOneMore;
  private JPanel buyPanelButton;
  private JPanel mainPanel = new JPanel();
  private JTextField[] textField = new JTextField[100];
  private JPanel addStockPanel;
  private int countfinal = 0;

  /**
   * This is the constructor of Buy Stock view.
   */
  public AddStockView() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void initButton() {
    buyPanelButton = new JPanel();
    add = new JButton("Add");
    add.setActionCommand("AddStockSym");
    add.setFont(new Font("Courier New", Font.ITALIC, 10));
    add.setForeground(Color.BLACK);
    buyPanelButton.add(add);

    back = new JButton("Back");
    back.setActionCommand("ExitAddStockPanel");
    back.setFont(new Font("Courier New", Font.ITALIC, 11));
    back.setForeground(Color.BLACK);
    buyPanelButton.add(back);

    addStockPanel.add(buyPanelButton, BorderLayout.SOUTH);
  }

  private void configureLayout() {
    String[] str = {"PortfolioName", "Stock1"};
    addStockPanel = new JPanel();
    mainPanel.setPreferredSize(new Dimension(500, 300));
    addStockPanel.add(createContent(str, true));
    addOneMore = new JButton("AddStock");
    addOneMore.setActionCommand("AddOneMore");
    addOneMore.setFont(new Font("Courier New", Font.ITALIC, 10));
    addOneMore.setForeground(Color.BLACK);
    ActionListener ad = new ActionHandler();
    addOneMore.addActionListener(ad);
    addStockPanel.add(addOneMore, BorderLayout.SOUTH);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    addStockPanel.setLayout(new BoxLayout(addStockPanel, BoxLayout.Y_AXIS));
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
    JScrollPane pane = new JScrollPane(addStockPanel);
    mainPanel.add(pane);
    this.add(mainPanel, BorderLayout.CENTER);
    this.pack();
    this.setVisible(true);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    add.addActionListener(listener);
    back.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    int count = 0;
    StringBuilder finalText = new StringBuilder();
    finalText.append(countfinal);
    finalText.append(";");
    for (JTextField text : textField) {
      if (null != text) {
        if (null != text.getText() && !"".equals(text.getText())) {
          finalText.append(text.getText());
          finalText.append(";");
          count++;
        } else {
          if (count != countfinal) {
            JOptionPane.showMessageDialog(addStockPanel, "All the fields are mandatory, " +
                    "please check and retry", "Failure", JOptionPane.ERROR_MESSAGE);
            break;
          }
        }
      }
    }
    return finalText.toString();
  }

  private JPanel createContent(String[] str) {
    JPanel cp = new JPanel(new GridBagLayout());
    GridBagConstraints g = new GridBagConstraints();
    g.fill = GridBagConstraints.NORTH;
    g.insets = new Insets(1, 1, 2, 1);
    int length = str.length + countfinal;
    for (int i = countfinal; i < length; ++i) {
      countfinal++;
      g.gridx = 0;
      g.gridy = i;
      System.out.println("chandu check" + length + "  " + i);
      JLabel label = new JLabel(str[length - i - 1], JLabel.RIGHT);
      textField[i] = new JTextField(20);
      label.setLabelFor(textField[i]);
      cp.add(label, g);
      g.gridx = 1;
      cp.add(textField[i], g);
    }
    return cp;
  }

  private JPanel createContent(String[] str, boolean x) {
    JPanel cp = new JPanel(new GridBagLayout());
    GridBagConstraints g = new GridBagConstraints();
    g.fill = GridBagConstraints.NORTH;
    g.insets = new Insets(1, 1, 2, 1);
    for (int i = 0; i < str.length; ++i) {
      countfinal++;
      g.gridx = 0;
      g.gridy = i;
      JLabel label = new JLabel(str[i], JLabel.RIGHT);
      textField[i] = new JTextField(20);
      label.setLabelFor(textField[i]);
      cp.add(label, g);
      g.gridx = 1;
      cp.add(textField[i], g);
    }
    return cp;
  }

  private class ActionHandler implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent event) {
      int count = countfinal;
      String[] str = {"Stock" + count};
      addStockPanel.add(createContent(str), BorderLayout.NORTH);
      addStockPanel.remove(buyPanelButton);
      addStockPanel.remove(addOneMore);
      addStockPanel.add(addOneMore);
      addStockPanel.add(buyPanelButton, BorderLayout.SOUTH);
      addStockPanel.setLayout(new BoxLayout(addStockPanel, BoxLayout.PAGE_AXIS));
      addStockPanel.updateUI();
    }
  }
}

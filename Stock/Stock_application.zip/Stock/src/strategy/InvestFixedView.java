package strategy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is the invest fixed view. This will invest with fixed ratio among the stock.
 */
public class InvestFixedView extends JFrame implements ViewTextInterface {
  private JButton invest;
  private JButton exit;
  private final String HEADING = "Invest Fixed View";
  private JPanel mainPanel;
  private JTextField[] textField = new JTextField[6];
  private JPanel commissionPanel;


  /**
   * This is invest fixed view.
   */
  public InvestFixedView() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void initButton() {
    JPanel buyPanelButton = new JPanel();
    invest = new JButton("Invest");
    invest.setActionCommand("InvestFixedBuy");
    invest.setFont(new Font("Courier New", Font.ITALIC, 10));
    invest.setForeground(Color.BLACK);
    buyPanelButton.add(invest);

    exit = new JButton("Exit");
    exit.setActionCommand("ExitInvestFix");
    exit.setFont(new Font("Courier New", Font.ITALIC, 11));
    exit.setForeground(Color.BLACK);
    buyPanelButton.add(exit);
    mainPanel.add(buyPanelButton);
  }

  private void configureLayout() {
    mainPanel = new JPanel();
    JCheckBox checkbox;
    mainPanel.setPreferredSize(new Dimension(400, 300));
    mainPanel.add(createContent());
    mainPanel.add(getDatePanel());
    checkbox = new JCheckBox("Add commission for this Buy");
    checkbox.setSelected(false);
    ActionListener actionListener = new ActionHandler();
    checkbox.addActionListener(actionListener);
    mainPanel.add(checkbox);
    mainPanel.add(getCommisionPanel());
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.add(mainPanel, BorderLayout.CENTER);
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
    this.pack();
    this.setVisible(true);
  }

  private Component getCommisionPanel() {
    commissionPanel = new JPanel();
    JLabel commission = new JLabel("Enter commission Amount:");
    textField[5] = new JTextField(5);
    commissionPanel.add(commission);
    commissionPanel.add(textField[5]);
    commission.setLabelFor(textField[5]);
    commissionPanel.setVisible(false);
    return commissionPanel;
  }

  @Override
  public void setActionListener(ActionListener listener) {
    invest.addActionListener(listener);
    exit.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    int count = 0;
    StringBuilder finalText = new StringBuilder();
    if (textField[5].getText() == null || "".equals(textField[5].getText())) {
      textField[5].setText("0");
    }
    for (JTextField text : textField) {
      if (null != text.getText() && !"".equals(text.getText())) {
        finalText.append(text.getText());
        finalText.append(";");
        count++;
      } else {
        if (count != 5) {
          JOptionPane.showMessageDialog(mainPanel, "All the fields are mandatory, " +
                  "please check and retry", "Failure", JOptionPane.ERROR_MESSAGE);
          break;
        }
      }
    }
    return finalText.toString();
  }

  private JPanel createContent() {
    JPanel cp = new JPanel(new GridBagLayout());
    String[] text = {"PortfolioName:", "Amount:"};
    GridBagConstraints g = new GridBagConstraints();
    g.fill = GridBagConstraints.NORTH;
    g.insets = new Insets(1, 1, 2, 1);
    for (int i = 0; i < text.length; ++i) {
      g.gridx = 0;
      g.gridy = i;
      JLabel label = new JLabel(text[i], JLabel.RIGHT);
      textField[i] = new JTextField(20);
      label.setLabelFor(textField[i]);
      cp.add(label, g);
      g.gridx = 1;
      cp.add(textField[i], g);
    }
    return cp;
  }

  /**
   * This method gives the date panel.
   *
   * @return the date panel to be added to main panel.
   */
  private JPanel getDatePanel() {

    JPanel datePanel = new JPanel();
    datePanel.setBorder(BorderFactory.createTitledBorder("Enter the Date to Buy Stock:"));
    datePanel.setBackground(Color.lightGray);
    datePanel.setLayout(new FlowLayout());

    JLabel month = new JLabel("Month(MM):");
    datePanel.add(month);
    textField[2] = new JTextField(2);
    month.setLabelFor(textField[2]);

    datePanel.add(textField[2]);

    JLabel day = new JLabel("Day(DD):");
    datePanel.add(day);
    textField[3] = new JTextField(2);
    datePanel.add(textField[3]);
    day.setLabelFor(textField[3]);

    JLabel year = new JLabel("Year(YYYY):");
    datePanel.add(year);
    textField[4] = new JTextField(4);
    datePanel.add(textField[4]);
    year.setLabelFor(textField[4]);

    return datePanel;
  }

  private class ActionHandler implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent event) {
      JCheckBox checkbox = (JCheckBox) event.getSource();
      if (checkbox == checkbox) {
        if (checkbox.isSelected()) {
          commissionPanel.setVisible(true);
        } else {
          commissionPanel.setVisible(false);
          textField[5].setText("0");
        }
      }
    }
  }
}

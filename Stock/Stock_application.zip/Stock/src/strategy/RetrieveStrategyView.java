package strategy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is the retrieve strategy view. This will retrieve the strategy.
 */
public class RetrieveStrategyView extends JFrame implements ViewTextInterface {
  private final String HEADING = "Retrieve Strategy";
  private JTextField[] textField = new JTextField[2];
  private JButton retrieve;
  private JButton exit;
  private JPanel createPanel;

  /**
   * This is the constructor class of retrieve strategy. This help to retrieve strategy.
   */
  public RetrieveStrategyView() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void configureLayout() {
    createPanel = new JPanel();
    createPanel.setPreferredSize(new Dimension(400, 200));
    JLabel head = new JLabel();
    head.setText("Enter Retrieve Strategy Information :");
    createPanel.add(createContent());
    head.setForeground(Color.BLACK);
    head.setHorizontalTextPosition(JLabel.CENTER);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

  private JPanel createContent() {
    JPanel cp = new JPanel(new GridBagLayout());
    String[] test = {"Enter PortFolio Name:", "Enter Strategy Name:"};
    GridBagConstraints g = new GridBagConstraints();
    g.fill = GridBagConstraints.NORTH;
    g.insets = new Insets(1, 1, 2, 1);
    for (int i = 0; i < test.length; ++i) {
      g.gridx = 0;
      g.gridy = i;
      JLabel label = new JLabel(test[i], JLabel.RIGHT);
      textField[i] = new JTextField(20);
      label.setLabelFor(textField[i]);
      cp.add(label, g);
      g.gridx = 1;
      cp.add(textField[i], g);
    }
    return cp;
  }

  private void initButton() {

    JPanel button = new JPanel();
    retrieve = new JButton("Retrieve");
    retrieve.setActionCommand("RetrievePortfolioInfo");
    retrieve.setFont(new Font("Courier New", Font.ITALIC, 10));
    retrieve.setForeground(Color.green);
    button.add(retrieve);

    exit = new JButton("Exit");
    exit.setActionCommand("ExitRetrievePortfolioInfo");
    exit.setFont(new Font("Courier New", Font.ITALIC, 10));
    exit.setForeground(Color.green);
    button.add(exit);

    createPanel.add(button);

    this.add(createPanel, BorderLayout.CENTER);
    createPanel.setLayout(new BoxLayout(createPanel, BoxLayout.Y_AXIS));
    this.pack();
    this.setVisible(true);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    retrieve.addActionListener(listener);
    exit.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    StringBuilder finalText = new StringBuilder();
    int count = 0;
    for (JTextField text : textField) {
      if (null != text.getText() && !"".equals(text.getText())) {
        finalText.append(text.getText());
        finalText.append(";");
        count++;
      } else {
        if (count != 2) {
          JOptionPane.showMessageDialog(createPanel, "All the fields are mandatory, " +
                  "please check and retry", "Failure", JOptionPane.ERROR_MESSAGE);
          break;
        }
      }
    }
    return finalText.toString();
  }
}

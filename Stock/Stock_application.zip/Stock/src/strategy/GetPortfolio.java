package strategy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is the get portfolio class.
 */
public class GetPortfolio extends JFrame implements ViewTextInterface {
  private final String HEADING = "Enter Portfolio Information";
  private JTextField textField;
  private JButton create;
  private JPanel createPanel;

  /**
   * This is the constructor class of create View. This class help in creating the create portfolio
   * view and panel settings.
   */
  public GetPortfolio() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void configureLayout() {
    createPanel = new JPanel();
    createPanel.setPreferredSize(new Dimension(400, 200));
    JLabel head = new JLabel();
    head.setText("Enter Portfolio Information :");
    head.setForeground(Color.BLACK);
    head.setHorizontalTextPosition(JLabel.CENTER);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

  private void initButton() {

    JPanel entry = new JPanel();
    JLabel label = new JLabel("Portfolio Name:");
    textField = new JTextField(20);
    entry.add(label);
    entry.add(textField);
    createPanel.add(entry);

    JPanel button = new JPanel();
    create = new JButton("Fetch");
    create.setActionCommand("FetchPortfolioInfo");
    create.setFont(new Font("Courier New", Font.ITALIC, 10));
    create.setForeground(Color.green);
    button.add(create);

    createPanel.add(button);

    this.add(createPanel, BorderLayout.CENTER);
    createPanel.setLayout(new BoxLayout(createPanel, BoxLayout.Y_AXIS));
    this.pack();
    this.setVisible(true);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    create.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    return textField.getText();
  }
}

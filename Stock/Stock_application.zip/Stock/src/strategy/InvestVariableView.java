package strategy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is the variable invest view file. This provide variable view.
 */
public class InvestVariableView extends JFrame implements ViewTextInterface {
  private JButton invest;
  private JButton exit;
  private final String HEADING = "Invest Variable View";
  private JPanel mainPanel;
  private JTextField[] textField;
  private JPanel commissionPanel;
  private List<String> stocklist;
  private int length;
  private String portName;

  /**
   * This is invest fixed view.
   */
  public InvestVariableView(List<String> stock, String port) {
    super();
    setTitle(HEADING);
    length = stock.size();
    stocklist = stock;
    portName = port;
    textField = new JTextField[length + 5];
    configureLayout();
    initButton();
  }

  private void configureLayout() {
    JCheckBox checkbox;
    mainPanel = new JPanel();
    mainPanel.setPreferredSize(new Dimension(600, 300));
    mainPanel.add(createContent());
    mainPanel.add(getDatePanel());
    checkbox = new JCheckBox("Add commission for this Buy");
    checkbox.setSelected(false);
    ActionListener actionListener = new ActionHandler();
    checkbox.addActionListener(actionListener);
    mainPanel.add(checkbox);
    mainPanel.add(getCommisionPanel());
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.add(mainPanel, BorderLayout.CENTER);
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
    this.pack();
    this.setVisible(true);
  }

  private JPanel createContent() {
    JPanel cp = new JPanel(new GridBagLayout());
    String[] test = new String[stocklist.size() + 1];
    test[0] = "Amount:";
    for (int i = 0; i < stocklist.size(); i++) {
      test[i + 1] = stocklist.get(i) + " Weight 10 for 10%";
    }
    GridBagConstraints g = new GridBagConstraints();
    g.fill = GridBagConstraints.NORTH;
    g.insets = new Insets(1, 1, 2, 1);
    for (int i = 0; i < test.length; ++i) {
      g.gridx = 0;
      g.gridy = i;
      JLabel label = new JLabel(test[i], JLabel.RIGHT);
      textField[i] = new JTextField(20);
      label.setLabelFor(textField[i]);
      cp.add(label, g);
      g.gridx = 1;
      cp.add(textField[i], g);
    }
    return cp;
  }

  private void initButton() {
    JPanel buyPanelButton = new JPanel();
    invest = new JButton("Invest");
    invest.setActionCommand("InvestStockVariable");
    invest.setFont(new Font("Courier New", Font.ITALIC, 10));
    invest.setForeground(Color.BLACK);
    buyPanelButton.add(invest);

    exit = new JButton("Back");
    exit.setActionCommand("ExitInvestVariPanel");
    exit.setFont(new Font("Courier New", Font.ITALIC, 11));
    exit.setForeground(Color.BLACK);
    buyPanelButton.add(exit);

    mainPanel.add(buyPanelButton);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    invest.addActionListener(listener);
    exit.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    int count = 1;
    StringBuilder finalText = new StringBuilder();
    finalText.append(length + 7);
    finalText.append(";");
    if (textField[4 + length].getText() == null || "".equals(textField[4 + length].getText())) {
      textField[4 + length].setText("0");
    }
    if (Double.parseDouble(textField[1].getText()) <= 0) {
      JOptionPane.showMessageDialog(mainPanel, "Please provide valid input " +
              "for Money", "Failure", JOptionPane.ERROR_MESSAGE);
    }
    for (JTextField text : textField) {
      if (null != text.getText() && !"".equals(text.getText())) {
        finalText.append(text.getText());
        finalText.append(";");
        count++;
      } else {
        if (count != 5 + length) {
          JOptionPane.showMessageDialog(mainPanel, "All the fields are mandatory, " +
                  "please check and retry", "Failure", JOptionPane.ERROR_MESSAGE);
          break;
        }
      }
    }
    finalText.append(portName);
    finalText.append(";");
    return finalText.toString();
  }

  /**
   * This method gives the date panel.
   *
   * @return the date panel to be added to main panel.
   */
  private JPanel getDatePanel() {

    JPanel datePanel = new JPanel();
    datePanel.setBorder(BorderFactory.createTitledBorder("Enter the Date to Buy Stock:"));
    datePanel.setBackground(Color.lightGray);
    datePanel.setLayout(new FlowLayout());

    JLabel month = new JLabel("Month(MM):");
    datePanel.add(month);
    textField[1 + length] = new JTextField(2);
    month.setLabelFor(textField[1 + length]);

    datePanel.add(textField[1 + length]);

    JLabel day = new JLabel("Day(DD):");
    datePanel.add(day);
    textField[2 + length] = new JTextField(2);
    datePanel.add(textField[2 + length]);
    day.setLabelFor(textField[2 + length]);

    JLabel year = new JLabel("Year(YYYY):");
    datePanel.add(year);
    textField[3 + length] = new JTextField(4);
    datePanel.add(textField[3 + length]);
    year.setLabelFor(textField[3 + length]);

    return datePanel;
  }

  private JPanel getCommisionPanel() {
    commissionPanel = new JPanel();
    JLabel commission = new JLabel("Enter commission Amount:");
    textField[4 + length] = new JTextField(5);
    commissionPanel.add(commission);
    commissionPanel.add(textField[4 + length]);
    commission.setLabelFor(textField[4 + length]);
    commissionPanel.setVisible(false);
    return commissionPanel;
  }

  private class ActionHandler implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent event) {
      JCheckBox checkbox = (JCheckBox) event.getSource();
      if (checkbox == checkbox) {
        if (checkbox.isSelected()) {
          commissionPanel.setVisible(true);
        } else {
          commissionPanel.setVisible(false);
          textField[4 + length].setText("0");
        }
      }
    }
  }
}

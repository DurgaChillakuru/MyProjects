package strategy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is the save strategy view class. This will save the strategy.
 */
public class SaveStrategy extends JFrame implements ViewTextInterface {
  private JButton exit;
  private JButton save;
  private JPanel mainPanel;
  private JPanel commissionPanel;
  private final String HEADING = "Invest Variable View";
  private JTextField[] textField = new JTextField[16];

  /**
   * This is invest fixed view.
   */
  public SaveStrategy() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void configureLayout() {
    JCheckBox checkbox;
    mainPanel = new JPanel();
    mainPanel.setPreferredSize(new Dimension(600, 600));
    mainPanel.add(createContent());
    mainPanel.add(getDatePanel());
    mainPanel.add(getDatePanel2());
    mainPanel.add(createContent2());
    checkbox = new JCheckBox("Add commission for this Buy");
    checkbox.setSelected(false);
    ActionListener actionListener = new ActionHandler();
    checkbox.addActionListener(actionListener);
    mainPanel.add(checkbox);
    mainPanel.add(getCommisionPanel());
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.add(mainPanel, BorderLayout.CENTER);
    mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
    this.pack();
    this.setVisible(true);
  }

  private JPanel createContent() {
    JPanel cp = new JPanel(new GridBagLayout());
    String[] test = {"Strategy Name:", "Money:", "Interval(Days):"};
    GridBagConstraints g = new GridBagConstraints();
    g.fill = GridBagConstraints.NORTH;
    g.insets = new Insets(1, 1, 2, 1);
    for (int i = 0; i < test.length; ++i) {
      g.gridx = 0;
      g.gridy = i;
      JLabel label = new JLabel(test[i], JLabel.RIGHT);
      textField[i] = new JTextField(20);
      label.setLabelFor(textField[i]);
      cp.add(label, g);
      g.gridx = 1;
      cp.add(textField[i], g);
    }
    return cp;
  }

  private JPanel createContent2() {
    JPanel cp = new JPanel(new GridBagLayout());
    String[] test = {"Stock1:", "Ratio1:", "Stock2:", "Ratio2:", "Stock3:", "Ratio3:"};
    GridBagConstraints g = new GridBagConstraints();
    g.fill = GridBagConstraints.NORTH;
    g.insets = new Insets(1, 1, 2, 1);
    for (int i = 10; i < test.length + 10; ++i) {
      g.gridx = 0;
      g.gridy = i;
      JLabel label = new JLabel(test[i - 10], JLabel.RIGHT);
      textField[i] = new JTextField(20);
      label.setLabelFor(textField[i]);
      cp.add(label, g);
      g.gridx = 1;
      cp.add(textField[i], g);
    }
    return cp;
  }

  private void initButton() {
    JPanel buyPanelButton = new JPanel();
    save = new JButton("Save");
    save.setActionCommand("SaveStrategyButton");
    save.setFont(new Font("Courier New", Font.ITALIC, 10));
    save.setForeground(Color.BLACK);
    buyPanelButton.add(save);

    exit = new JButton("Back");
    exit.setActionCommand("SaveStrategyButExit");
    exit.setFont(new Font("Courier New", Font.ITALIC, 11));
    exit.setForeground(Color.BLACK);
    buyPanelButton.add(exit);

    mainPanel.add(buyPanelButton);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    save.addActionListener(listener);
    exit.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    StringBuilder finalText = new StringBuilder();
    if (null == textField[9].getText() || "".equals(textField[9].getText())) {
      textField[9].setText("0");
    }
    int count = 0;
    for (JTextField text : textField) {
      if (null != text.getText() && !"".equals(text.getText())) {
        finalText.append(text.getText());
        finalText.append(";");
        count++;
      } else {
        if (count != 15) {
          JOptionPane.showMessageDialog(mainPanel, "All the fields are mandatory, " +
                  "please check and retry", "Failure", JOptionPane.ERROR_MESSAGE);
          break;
        }
      }
    }
    return finalText.toString();
  }

  /**
   * This method gives the date panel.
   *
   * @return the date panel to be added to main panel.
   */
  private JPanel getDatePanel() {
    JPanel datePanel = new JPanel();
    datePanel.setBorder(BorderFactory.createTitledBorder("Enter start period:"));
    datePanel.setBackground(Color.lightGray);
    datePanel.setLayout(new FlowLayout());

    JLabel month = new JLabel("Month(MM):");
    datePanel.add(month);
    textField[3] = new JTextField(2);
    month.setLabelFor(textField[3]);

    datePanel.add(textField[3]);

    JLabel day = new JLabel("Day(DD):");
    datePanel.add(day);
    textField[4] = new JTextField(2);
    datePanel.add(textField[4]);
    day.setLabelFor(textField[4]);

    JLabel year = new JLabel("Year(YYYY):");
    datePanel.add(year);
    textField[5] = new JTextField(4);
    datePanel.add(textField[5]);
    year.setLabelFor(textField[5]);

    return datePanel;
  }

  /**
   * This method gives the date panel.
   *
   * @return the date panel to be added to main panel.
   */
  private JPanel getDatePanel2() {
    JPanel datePanel = new JPanel();
    datePanel.setBorder(BorderFactory.createTitledBorder("Enter end period:"));
    datePanel.setBackground(Color.lightGray);
    datePanel.setLayout(new FlowLayout());

    JLabel endmonth = new JLabel("Month(MM):");
    datePanel.add(endmonth);
    textField[6] = new JTextField(2);
    endmonth.setLabelFor(textField[6]);

    datePanel.add(textField[6]);

    JLabel endday = new JLabel("Day(DD):");
    datePanel.add(endday);
    textField[7] = new JTextField(2);
    datePanel.add(textField[7]);
    endday.setLabelFor(textField[7]);

    JLabel endyear = new JLabel("Year(YYYY):");
    datePanel.add(endyear);
    textField[8] = new JTextField(4);
    datePanel.add(textField[8]);
    endyear.setLabelFor(textField[8]);

    return datePanel;
  }

  private JPanel getCommisionPanel() {
    commissionPanel = new JPanel();
    JLabel commission = new JLabel("Enter commission Amount:");
    textField[9] = new JTextField(5);
    commissionPanel.add(commission);
    commissionPanel.add(textField[9]);
    commission.setLabelFor(textField[9]);
    commissionPanel.setVisible(false);
    return commissionPanel;
  }

  private class ActionHandler implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent event) {
      JCheckBox checkbox = (JCheckBox) event.getSource();
      if (checkbox == checkbox) {
        if (checkbox.isSelected()) {
          commissionPanel.setVisible(true);
        } else {
          commissionPanel.setVisible(false);
          textField[9].setText("0");
        }
      }
    }
  }
}

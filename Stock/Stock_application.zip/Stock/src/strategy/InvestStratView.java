package strategy;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import view.ViewInterface;

/**
 * This is the invest strategic view.
 */
public class InvestStratView extends JFrame implements ViewInterface {
  private JButton investFixed;
  private JButton investVariable;
  private JButton investperiodic;
  private JPanel investstratview;
  private final String HEADING = "Invest Amount View";

  /**
   * This is the constructor of strategic view. This will initializes the values.
   */
  public InvestStratView() {
    super();
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void initButton() {
    GridLayout gridLayout = new GridLayout(3, 1);
    gridLayout.setHgap(50);
    gridLayout.setVgap(50);
    investstratview.setLayout(gridLayout);
    investstratview.setBorder(new EmptyBorder(new Insets(50, 50, 50, 50)));

    investFixed = new JButton("InvestFixed");
    investFixed.setActionCommand("InvestFixed");
    investFixed.setFont(new Font("Courier New", Font.ITALIC, 16));
    investFixed.setForeground(Color.BLUE);
    investstratview.add(investFixed);

    investperiodic = new JButton("InvestPeriodic");
    investperiodic.setActionCommand("InvestPeriodic");
    investperiodic.setFont(new Font("Courier New", Font.ITALIC, 16));
    investperiodic.setForeground(Color.BLUE);
    investstratview.add(investperiodic);

    investVariable = new JButton("InvestVariable");
    investVariable.setActionCommand("InvestVariable");
    investVariable.setFont(new Font("Courier New", Font.ITALIC, 16));
    investVariable.setForeground(Color.BLUE);
    investstratview.add(investVariable);

    this.add(investstratview, BorderLayout.CENTER);
    this.pack();
    this.setVisible(true);

  }

  private void configureLayout() {
    investstratview = new JPanel();
    investstratview.setPreferredSize(new Dimension(400, 300));
    JLabel head = new JLabel();
    head.setText("Please select one of the option below :");
    head.setForeground(Color.red);
    head.setHorizontalTextPosition(JLabel.CENTER);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    investFixed.addActionListener(listener);
    investperiodic.addActionListener(listener);
    investVariable.addActionListener(listener);
  }

}

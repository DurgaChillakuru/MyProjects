package saveportfolio;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import view.ViewTextInterface;

/**
 * This is the save view portfolio class. This provide Ui for save.
 */
public class SaveView extends JFrame implements ViewTextInterface {
  private final String HEADING = "Save Portfolio Menu";
  private JTextField textField;
  private JButton save;
  private JButton exit;
  private JPanel createPanel;
  private String buttonName;

  /**
   * This is the constructor class of create View. This class help in creating the create portfolio
   * view and panel settings.
   */
  public SaveView(String buttonN) {
    super();
    this.buttonName = buttonN;
    setTitle(HEADING);
    configureLayout();
    initButton();
  }

  private void configureLayout() {
    createPanel = new JPanel();
    createPanel.setPreferredSize(new Dimension(400, 200));
    JLabel head = new JLabel();
    head.setText("Save/Retrieve Portfolio :");
    head.setForeground(Color.BLACK);
    head.setHorizontalTextPosition(JLabel.CENTER);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }

  private void initButton() {

    JPanel entry = new JPanel();
    JLabel label = new JLabel("Portfolio Name:");
    textField = new JTextField(20);
    entry.add(label);
    entry.add(textField);
    createPanel.add(entry);

    JPanel button = new JPanel();
    save = new JButton(this.buttonName);
    save.setActionCommand(buttonName + "Portfolio");
    save.setFont(new Font("Courier New", Font.ITALIC, 10));
    save.setForeground(Color.BLUE);
    button.add(save);

    exit = new JButton("Exit");
    exit.setActionCommand("ExitSavePortfolio");
    exit.setFont(new Font("Courier New", Font.ITALIC, 10));
    exit.setForeground(Color.BLUE);
    button.add(exit);

    createPanel.add(button);

    this.add(createPanel, BorderLayout.CENTER);
    createPanel.setLayout(new BoxLayout(createPanel, BoxLayout.Y_AXIS));
    this.pack();
    this.setVisible(true);
  }

  @Override
  public void setActionListener(ActionListener listener) {
    save.addActionListener(listener);
    exit.addActionListener(listener);
  }

  @Override
  public String getInputText() {
    return textField.getText();
  }
}
